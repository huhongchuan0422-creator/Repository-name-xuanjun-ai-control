# P3 Owner reminder increment — OFFLINE / DEFAULT OFF

Additive code for the SAME P3 ledger/loop, not a new service. Accepted baseline ZIP
`34fda99283a3593daff6810f4c70b3d1b9d6afcee9c491a7030f6195e2ae0252` and its
48-test source/manifest are unchanged. No P2/SaaS/community/production edit, actual
call/message/API request, signup, credential or server operation was performed.

## Five-minute confirmation reminder

Trusted events carry exact event_id/request_id/task_id/blocker_id and occurred_at.
Creation persists deadline_at = creation + 300 seconds. An authenticated response
or withdrawal closes only that request. ack_seen means seen, not answered and
never approved. Restart preserves deadlines; event replay is idempotent. A later
NOT_SENT provider proof cannot revive a closed episode: every send boundary
rechecks that the exact episode is OPEN and due.

Real ChatGPT/native conversation creation/reply/withdrawal input is NOT CONNECTED.
`event_reader(ref)` must independently authenticate and return exactly:
`{kind,event_id,request_id,task_id,blocker_id,occurred_at,verified:true}`.
Kinds: confirmation_created, confirmation_responded, confirmation_cancelled,
ack_seen. The fixture verified flag is NOT a real signature/feed. Future/nonfinite
times, bad IDs, cross-request/task/blocker replies and replay conflicts fail closed.

## Twenty-minute dynamic ratio

Owner requested an extensible decreasing ratio, not a wait for every task to stop.
The following configurable INITIAL DEFAULTS came from root's implementation
proposal, not numbers independently specified by Owner:

| Eligible task count N | Percent | Required stalled tasks |
|---|---:|---:|
| 1–2 | 100% | ceil(N × 100/100) |
| 3–5 | 60% | ceil(N × 60/100) |
| 6–10 | 40% | ceil(N × 40/100) |
| 11+ | 30% | ceil(N × 30/100) |

`ratio_bands` is a sorted sequence `(inclusive_max_tasks, integer_percent)` with
one final `(None, percent)` band. Percent is 1..100, non-increasing. Reject bool,
float/NaN/infinity, zero, gaps via invalid ordering, duplicate/descending bounds,
missing unbounded final band and excessive band count. Integer arithmetic computes
ceil; N=0 never triggers. Exact policy and mapping fingerprints are persisted;
restart cannot silently replace them. Reconfiguration needs reviewed reconciliation,
not editing a live policy behind pending episodes.

### Who belongs to N

- N includes admitted, spec-bound RUNNING and READY/PENDING tasks whose original
  DAG dependencies are DONE. Thus queued internal work can reach N=3/5/6/10/11
  without increasing the existing two-heavy-job or seven-role execution caps.
- Completed/failed/cancelled/frozen tasks, explicit resource/human external waits
  and unknown eligibility are excluded. No priority/execution permission is changed.
- Original watchdog's WAITING_HUMAN caused specifically by P3_NO_REAL_PROGRESS
  remains expected work ONLY with known native effect classification. A generic
  WAITING_HUMAN, UNKNOWN effect or uncertain exit is not falsely called stalled.
- Optional trusted `eligibility_reader(task_id)` returns exactly
  `{task_id,fence,state,verified:true}`, with state EXPECTED / EXTERNAL_WAIT /
  FROZEN / UNKNOWN and the current fence. Missing/invalid input is UNKNOWN, not an
  execution grant. Terminal/frozen canonical states cannot be overridden here.
- READY work with no execution origin is in the denominator but has UNKNOWN
  progress, not fabricated 20-minute stopped-work evidence. These unknowns are
  independently visible in canonical P3_PROGRESS_OBSERVABILITY events and scan
  diagnostics; they do not cause a false telephone 'work stopped' claim.

### Real progress and membership changes

Each task keeps its original execution origin and first-seen independently
verified work-product identities (SOURCE_COMMIT, TEST_RUN, ARTIFACT). Reports,
heartbeats, reacquiring a lease, repeated evidence hashes or changing N do not
reset last real progress. A normal long test with genuine new verified output
continues its progress clock; merely saying 'testing' does not.

Membership and threshold snapshots persist. If a changed population makes the
ratio newly qualify, observation is bounded to 60 seconds, rather than ringing
instantaneously after a threshold drop. Once qualified, the unchanged stalled
cohort and its required count are latched. Unrelated new/completed tasks cannot
restart this deadline or dilute the already qualified cohort indefinitely. Actual
progress, freeze/external-wait or removal of enough cohort members clears it.
Diagnostics distinguish current N/threshold from n_at_qualification and the latched
cohort. The 20-minute per-task clock is never reset by this 60-second sensitivity
window. Confirmation's 5-minute deadline is completely independent.

## Non-overlapping episodes and cancellation

All due reasons for this Owner/scope are coalesced into one generic Owner-attention
episode: local blockers and portfolio detection cannot generate overlapping calls.
An episode persists across scans/restarts and concurrent senders. A new genuinely
resolved-then-stalled episode may remind again; the same unchanged blocker does
not create repeated calls. Nothing here writes Owner approvals or treats an ACK,
call connection, answer, reply receipt or notification receipt as approval.

Reply/withdrawal plus cancellation of PENDING/CLAIMED notices is one original DB
transaction. Send eligibility and persisted SENDING are another pinned transaction.
After SENDING is durable a concurrent response cannot prove whether a call already
happened; SENDING/UNCERTAIN/ACKED are not falsely recalled or made safe to retry.
Actual provider call cancellation/refunds are not implemented or verified.

## Transport / reconciliation contract — NOT CONNECTED

No transport implementation or credential is bundled. enabled=False by default.
A trusted admitted host adapter provides bounded operations:

1. `route()` -> exactly `{route,provider_binding,destination_binding,verified:true}`.
   route is PHONE or FALLBACK; the two bindings are 64-hex fingerprints of opaque
   configured account/endpoint handles (not raw numbers/customer IDs; do not use a
   reversible phone-number dictionary hash). PHONE is preferred, with an existing
   verified +86 destination intended; actual provider/number/cost/terms/consent and
   fallback channel remain UNVERIFIED and unconfigured here.
2. `send(opaque_notification_id, fixed_generic_message, binding, attempt_nonce)` ->
   `{notification_id,receipt_id,binding,attempt_nonce,accepted:true}`.
   Only opaque stable ID, opaque per-attempt nonce, fixed generic notice and route
   bindings cross this interface. Raw original task/request/outbox IDs never do.
   The exact route/provider/destination and nonce derivation are durable in
   P3_REMINDER_ATTEMPT in the SAME transaction as SENDING, before send is called.
3. `reconcile_unknown(internal_event_key, lookup)` calls
   `lookup(original_binding, opaque_notification_id, original_attempt_nonce)`.
   Verified return must echo all three and supply SENT + receipt_id, or NOT_SENT +
   proof_id. Wrong channel/endpoint/attempt or UNKNOWN cannot unlock a retry.
   Stable business notification ID does not make a stale earlier-attempt absence
   proof valid for a later send. A durable matching absence marker is required
   before any retry, even if someone invokes the underlying original outbox API.

API timeout or malformed ACK becomes SENDING_UNCERTAIN with no automatic redial or
fallback. A crash in SENDING is unclaimable. Only exact original-attempt NOT_SENT
proof may permit a subsequently verified fallback; another channel's absence may
not. Provider ACK does not prove a human heard/answered. Returned dial_attempted
is true ONLY for PHONE; external_delivery_attempted is separate for all channels.

Fixed message: “您有待确认或停滞事项，请查看原工作入口。电话接通不代表批准。”
No customer/task/approval details are sent. No real conversation input, audible
ring, provider lookup, phone/fallback delivery or user response was tested here.

## Existing-ledger integration and rollback

Uses ONLY original events, supervision_events and supervision_delivery; no new
schema/table, ledger, queue, daemon or second Writer. Optional ReminderIntegratedLoop
subclasses the accepted original loop and runs the hook after original task work.
Reminder errors do not erase durable results or stop independent authorized work.
Readers/adapters must enforce bounded I/O. No live hook or provider has been enabled.

Extract the preserved baseline ZIP (embedded under baseline/ in the new artifact),
then overlay p3_lifecycle/reminder_increment. Put original candidate/runtime and
this increment on the Python module path, compose with the SAME admitted P3Ledger,
fixed mapping/policy and trusted reader/adapter. Only the existing host loop may own
this hook. Real provider/response-interface connection and field enablement remain
separate pending dependencies, not accomplished by setting a fixture boolean.

Rollback disables this optional hook/adapter through the original admitted host.
Never delete/reset deadlines, population/cohort snapshots, events, claims,
uncertain attempts or original ledger/WAL. Do not redial as a rollback action.

## Local evidence

52 NEW tests pass on Python 3.12.14 and 3.6.8. They exercise real temporary original
SQLite/ledger/outbox APIs with synthetic provider/input proofs: exact deadlines,
response/cancel races and original NOT_SENT reconciliation, opaque IDs, attempt
and channel binding, stale absence replay, portfolio overlap, real N snapshots at
1/2/3/5/6/10/11, ceil/config negatives, population churn/threshold-drop observation,
original 600-second watchdog interaction, true long-test progress, independent
execution, default-off/no tables, restart and concurrent scanners/senders.

Run only this increment:
```
PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s local-candidate/p3_lifecycle/reminder_increment/tests -v
```
An initial test-discovery mistake also collected 48 baseline tests once; imports
were corrected. That accidental rerun is not new independent baseline acceptance.
The first cancellation defect and subsequent independent-review findings have
specific regression tests. Independent same-version review of this freeze is
pending; simulated provider tests are NOT actual calls or field acceptance.

## Reviewed corrections (same increment)

Native supervised effects UNKNOWN OR native_state UNKNOWN is a hard exclusion before any EXPECTED eligibility intent. Each send durably binds the exact overdue `covered_requests` at its atomic send boundary. After a provider ACK, a newly overdue request creates a new coalesced episode; an old unanswered request cannot swallow it. Same-round requests still share one notification. Unknown previous delivery remains non-redialable: new reminders are deferred while that shared attempt is unresolved, rather than silently represented as delivered. Telephone ACK is not a confirmation response.

Coverage is reason-based: queue episodes persist exact `reason_ids`; sends freeze `covered_reasons` plus request IDs. Confirmation request identity and progress cohort identity are separate reasons. A reply cancelling the only new queued reason cancels that reminder even if an older already-covered request remains overdue. Durable attempted coverage prevents population churn from repeating the same reason, while a genuinely new progress cohort or confirmation can create a subsequent episode.

Coverage distinguishes delivery evidence: ACKED covers, UNKNOWN reserves without redial, and a channel/attempt-bound verified NOT_SENT removes that attempt from coverage. A temporarily ineligible then eligible unchanged reason can therefore be notified after proven non-delivery; raw unbound absence proofs still cannot unlock it.
