import concurrent.futures
import copy
import hashlib
import json
import sqlite3
from pathlib import Path
import sys
import threading
import time
import unittest

ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'reminder_increment'),str(ROOT/'tests')]
import test_p3_lifecycle as baseline
from p3_owner_reminders import OwnerReminders,ReminderIntegratedLoop,DESTINATION,MESSAGE

class Adapter:
    def __init__(self,route='PHONE',fail=False):self.calls=[];self.selected=route;self.fail=fail
    def route(self):return {'route':self.selected,'provider_binding':hashlib.sha256(('provider-'+self.selected).encode()).hexdigest(),
        'destination_binding':hashlib.sha256(b'opaque-destination-fixture').hexdigest(),'verified':True}
    def send(self,key,message,route,attempt_nonce):
        self.calls.append((key,message,route,attempt_nonce))
        if self.fail:raise TimeoutError('private diagnostic must not persist')
        return {'notification_id':key,'receipt_id':'provider-fixture-receipt','binding':route,'attempt_nonce':attempt_nonce,'accepted':True}

class ReminderTests(unittest.TestCase):
    def setUp(self):
        self.base=baseline.Fixture();self.base.setUp();self.addCleanup(self.base.doCleanups)
        self.events={};self.adapter=Adapter();self.service=self.open()
    def open(self,enabled=False,adapter=None,mapping=None,ratio_bands=None,eligibility_reader=None):
        return OwnerReminders(self.base.ledger,mapping or {t:'block' for t in self.base.pins},
            event_reader=self.events.get,adapter=adapter or self.adapter,enabled=enabled,ratio_bands=ratio_bands,eligibility_reader=eligibility_reader)
    def event(self,kind='confirmation_created',request='req1',task='a',blocker='block',event=None):
        eid=event or kind+'-'+request
        self.events[eid]={'kind':kind,'event_id':eid,'request_id':request,'task_id':task,
                         'blocker_id':blocker,'occurred_at':self.base.clock(),'verified':True}
        return self.service.ingest(eid)
    def advance(self,seconds):self.base.clock.now+=seconds
    def deliveries(self):return self.base.query('SELECT state FROM supervision_delivery WHERE destination=?',(DESTINATION,))
    def due(self):self.event();self.advance(300);self.service.scan()
    def two_tasks(self):
        claims=self.base.ledger.claim('w1',ttl=3600),self.base.ledger.claim('w2',ttl=3600)
        self.service.scan()
        return claims

    def test_native_unknown_overrides_expected_eligibility_intent(self):
        claims=self.two_tasks()
        for c in claims:
            self.base.proof(c)
            t=self.base.ledger.observation(c['task_id'])
            self.base.supervisor.observe(c['task_id'],'RUNNING','UNKNOWN',t['lease_owner'],t['lease_until'],self.base.clock(),effects='UNKNOWN')
        def eligibility(task):
            return {'task_id':task,'fence':self.base.ledger.observation(task)['fence'],'state':'EXPECTED','verified':True}
        self.service=self.open(eligibility_reader=eligibility);self.service.scan();self.advance(1200)
        observed=self.service.scan()
        self.assertEqual(observed['progress_observation']['stalled_count'],0)
        self.assertEqual(observed['queued'],[])
        self.assertEqual(observed['progress_observation']['excluded']['a'],'UNKNOWN')

    def test_native_unknown_with_known_effects_is_not_certain_stall(self):
        for c in self.two_tasks():
            self.base.proof(c);t=self.base.ledger.observation(c['task_id'])
            self.base.supervisor.observe(c['task_id'],'RUNNING','UNKNOWN',t['lease_owner'],t['lease_until'],self.base.clock(),effects='KNOWN')
        self.service.scan();self.advance(1200);observed=self.service.scan()
        self.assertEqual(observed['progress_observation']['stalled_count'],0)
        self.assertEqual(observed['queued'],[])
        self.assertEqual(observed['progress_observation']['excluded']['a'],'UNKNOWN')

    def test_new_request_after_ack_gets_own_deadline_and_durable_coverage(self):
        self.due();service=self.open(True);service.send_one();self.advance(10)
        self.event(request='req2',task='independent');self.advance(299);service.scan()
        self.assertEqual(service.send_one()['state'],'NO_PENDING_REMINDER')
        self.advance(1);service.scan();service=self.open(True)
        self.assertEqual(service.send_one()['state'],'PROVIDER_ACKED_NOT_APPROVAL')
        self.assertEqual(len(self.adapter.calls),2)
        for unused in range(3):service.scan();service.send_one()
        self.assertEqual(len(self.adapter.calls),2)
        attempts=self.base.query("SELECT details FROM events WHERE event='P3_REMINDER_ATTEMPT' ORDER BY id")
        self.assertEqual(json.loads(attempts[-1][0])['covered_requests'],['req1','req2'])

    def test_new_request_does_not_redial_uncertain_previous_attempt(self):
        self.due();adapter=Adapter(fail=True);service=self.open(True,adapter);service.send_one()
        self.event(request='req2',task='independent');self.advance(300);service.scan();service.send_one()
        self.assertEqual(len(adapter.calls),1)

    def test_cancel_only_new_queued_request_cannot_redial_old_covered_request(self):
        self.due();sender=self.open(True);sender.send_one();self.advance(10)
        self.event(request='req2',task='independent');self.advance(300);sender.scan()
        self.event('confirmation_responded',request='req2',task='independent')
        sender.send_one();self.assertEqual(len(self.adapter.calls),1)
        self.assertEqual(self.deliveries(),[('ACKED',),('CANCELLED',)])

    def test_new_progress_reason_not_swallowed_by_old_acknowledged_confirmation(self):
        self.two_tasks();self.due();sender=self.open(True);sender.send_one()
        self.advance(900);sender.scan();sender.send_one()
        self.assertEqual(len(self.adapter.calls),2)
        sender.scan();sender.send_one();self.assertEqual(len(self.adapter.calls),2)
        attempts=self.base.query("SELECT details FROM events WHERE event='P3_REMINDER_ATTEMPT' ORDER BY id")
        self.assertTrue(any(r.startswith('progress:') for r in json.loads(attempts[-1][0])['covered_reasons']))

    def test_proven_absent_closed_progress_episode_can_notify_when_eligible_again(self):
        state=['EXPECTED']
        def reader(task):return {'task_id':task,'fence':self.base.ledger.observation(task)['fence'],'state':state[0],'verified':True}
        adapter=Adapter(fail=True)
        self.service=self.open(True,adapter,mapping={'a':'block'},eligibility_reader=reader)
        self.base.ledger.claim('w',ttl=3600);self.service.scan();self.advance(1200);self.service.scan()
        self.service.send_one();key=self.delivery_key();state[0]='EXTERNAL_WAIT';self.service.scan();self.advance(31)
        def absent(binding,notification_id,attempt_nonce):
            return dict(binding=binding,notification_id=notification_id,attempt_nonce=attempt_nonce,status='NOT_SENT',proof_id='verified-absence',verified=True)
        self.assertEqual(self.service.reconcile_unknown(key,absent),'RETRY_AUTHORIZED')
        state[0]='EXPECTED';self.service.scan();self.advance(60);self.service.scan();adapter.fail=False
        for unused in range(3):self.service.send_one()
        self.assertEqual(len(adapter.calls),2)

    def test_five_minute_deadline_exact_and_persisted(self):
        self.event();self.advance(299);self.service.scan();self.assertEqual(self.deliveries(),[])
        self.advance(1);self.open().scan();self.assertEqual(self.deliveries(),[('PENDING',)])
        e=self.base.query("SELECT details FROM events WHERE event='P3_CONFIRMATION_INPUT'")[0][0]
        self.assertEqual(json.loads(e)['deadline_at'],1300)

    def test_default_off_never_calls_adapter(self):
        self.due();result=self.service.send_one()
        self.assertEqual(result['state'],'CAPABILITY_UNAVAILABLE');self.assertEqual(self.adapter.calls,[])

    def test_exact_response_cancels_pending(self):
        self.due();self.event('confirmation_responded')
        self.assertEqual(self.deliveries(),[('CANCELLED',)])
        self.assertEqual(self.open(True).send_one()['state'],'NO_PENDING_REMINDER')

    def test_cancel_before_due_and_wrong_request_no_effect(self):
        self.event()
        with self.assertRaises(ValueError):self.event('confirmation_responded',request='wrong')
        self.event('confirmation_cancelled');self.advance(400);self.service.scan();self.assertEqual(self.deliveries(),[])

    def test_ack_seen_is_not_response_or_approval(self):
        self.event();self.event('ack_seen');self.advance(300);self.service.scan()
        self.assertEqual(self.deliveries(),[('PENDING',)])
        self.assertEqual(self.base.query('SELECT * FROM approvals'),[])

    def test_duplicate_event_id_and_conflict(self):
        self.event();self.assertTrue(self.service.ingest('confirmation_created-req1')['duplicate'])
        self.events['confirmation_created-req1']['request_id']='different'
        with self.assertRaises(ValueError):self.service.ingest('confirmation_created-req1')

    def test_same_blocker_multiple_confirmation_requests_one_reminder(self):
        self.event();self.event(request='req2',task='independent');self.advance(300)
        for unused in range(5):self.open().scan()
        self.assertEqual(self.deliveries(),[('PENDING',)])
        self.event('confirmation_responded',request='req1');self.assertEqual(self.deliveries(),[('PENDING',)])
        self.event('confirmation_responded',request='req2',task='independent')
        self.assertEqual(self.deliveries(),[('CANCELLED',)])

    def test_reply_does_not_send_old_notice_for_later_not_due_request(self):
        self.event();self.advance(290);self.event(request='req2');self.advance(10);self.service.scan()
        self.event('confirmation_responded',request='req1');self.assertEqual(self.deliveries(),[('CANCELLED',)])
        self.advance(290);self.service.scan();self.assertEqual(self.deliveries(),[('CANCELLED',),('PENDING',)])

    def test_twenty_minutes_two_real_active_tasks(self):
        self.two_tasks();self.advance(1199);self.service.scan();self.assertEqual(self.deliveries(),[])
        self.advance(1);self.service.scan();self.assertEqual(self.deliveries(),[('PENDING',)])

    def test_one_expected_active_task_requires_one_stalled(self):
        self.service=self.open(mapping={'a':'block'})
        self.base.ledger.claim('w',ttl=3600);self.service.scan();self.advance(1200);self.service.scan();self.assertEqual(self.deliveries(),[('PENDING',)])

    def test_unstarted_pending_tasks_not_claimed_real_stall(self):
        self.advance(1200);self.service.scan();self.assertEqual(self.deliveries(),[])

    def test_heartbeat_does_not_hide_stall(self):
        a,b=self.two_tasks();self.advance(1199)
        for c in (a,b):self.base.ledger.heartbeat(c['task_id'],c['worker_id'],c['fence'],ttl=3600)
        self.advance(1);self.service.scan();self.assertEqual(self.deliveries(),[('PENDING',)])

    def test_real_long_test_evidence_prevents_false_stall(self):
        a,b=self.two_tasks();self.advance(1000)
        for c in (a,b):
            ref='test-'+c['task_id'];self.base.progress_proofs[ref]={'task_id':c['task_id'],'spec_hash':c['spec_hash'],
                'fence':c['fence'],'kind':'TEST_RUN','sha256':hashlib.sha256(ref.encode()).hexdigest(),'verified':True}
            self.base.ledger.progress(c['task_id'],c['worker_id'],c['fence'],ref)
        self.advance(300);self.service.scan();self.assertEqual(self.deliveries(),[])
        self.advance(900);self.service.scan();self.assertEqual(self.deliveries(),[('PENDING',)])

    def test_independent_blockers_group_portfolio_stall(self):
        self.service=self.open(mapping={'a':'first','b':'first','independent':'second'})
        self.two_tasks();self.advance(1200);self.service.scan();self.assertEqual(self.deliveries(),[('PENDING',)])

    def test_queued_reminder_and_stall_same_blocker_merge(self):
        self.two_tasks();self.event();self.advance(300);self.service.scan();self.advance(900);self.service.scan()
        self.assertEqual(self.deliveries(),[('PENDING',)])

    def test_restart_reuses_episode_and_does_not_reset_deadline(self):
        self.event();self.advance(200);self.service=self.open();self.advance(100);self.service.scan()
        self.service=self.open();self.service.scan();self.assertEqual(self.deliveries(),[('PENDING',)])

    def test_timeout_unknown_never_redials_or_uses_fallback(self):
        self.due();adapter=Adapter(fail=True);service=self.open(True,adapter)
        self.assertEqual(service.send_one()['state'],'UNKNOWN_NO_REDIAL')
        self.assertEqual(self.deliveries(),[('SENDING_UNCERTAIN',)])
        self.advance(9999);service=self.open(True,adapter)
        self.assertEqual(service.send_one()['state'],'NO_PENDING_REMINDER');self.assertEqual(len(adapter.calls),1)
        self.assertNotIn('private diagnostic',repr(self.base.query('SELECT last_error FROM supervision_delivery')))

    def test_send_ack_is_not_owner_approval(self):
        self.due();service=self.open(True)
        self.assertEqual(service.send_one()['state'],'PROVIDER_ACKED_NOT_APPROVAL')
        self.assertEqual(self.deliveries(),[('ACKED',)]);self.assertEqual(self.base.query('SELECT * FROM approvals'),[])
        self.assertEqual(self.adapter.calls[0][1],MESSAGE)
        self.assertNotIn('req1',self.adapter.calls[0][1])

    def test_verified_fallback_route_no_fake_phone(self):
        self.due();adapter=Adapter('FALLBACK');self.open(True,adapter).send_one()
        self.assertEqual(adapter.calls[0][2]['route'],'FALLBACK')

    def test_response_after_claim_before_send_cancels(self):
        self.due();claim=self.base.supervisor.claim_delivery('worker',DESTINATION)
        self.event('confirmation_responded');self.assertIsNone(self.service._begin_send(claim,self.adapter.route()))
        self.assertEqual(self.adapter.calls,[])

    def test_response_after_sending_does_not_forge_recall_or_retry(self):
        self.due();claim=self.base.supervisor.claim_delivery('worker',DESTINATION)
        self.service._begin_send(claim,self.adapter.route());self.event('confirmation_responded')
        self.assertEqual(self.deliveries(),[('SENDING',)])
        self.assertEqual(self.open(True).send_one()['state'],'NO_PENDING_REMINDER')

    def test_multiple_scanners_and_senders_one_external_attempt(self):
        self.due();barrier=threading.Barrier(2)
        def send():
            service=self.open(True);barrier.wait();service.scan();return service.send_one()
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            a=pool.submit(send);b=pool.submit(send);a.result();b.result()
        self.assertEqual(len(self.adapter.calls),1);self.assertEqual(self.deliveries(),[('ACKED',)])

    def test_unconnected_input_and_unverified_event_rejected(self):
        with self.assertRaises(ValueError):OwnerReminders(self.base.ledger,{'a':'block'}).ingest('ref')
        self.event();self.events['confirmation_created-req1']['verified']=False
        with self.assertRaises(ValueError):self.service.ingest('confirmation_created-req1')

    def test_lease_reacquisition_without_work_product_does_not_reset_twenty_minutes(self):
        a,b=self.two_tasks();self.advance(1000)
        self.base.ledger.finish('a',a['worker_id'],a['fence'],'PAUSED_RESOURCE',effects='none')
        self.base.ledger.resume_resource('a','trusted-fixture-owner',True)
        resumed=self.base.ledger.claim('resumed',ttl=3600);self.assertEqual(resumed['task_id'],'a')
        self.advance(200);self.service.scan();self.assertEqual(self.deliveries(),[('PENDING',)])

    def test_malformed_provider_ack_is_unknown_not_approval(self):
        self.due()
        class Bad(Adapter):
            def send(self,*args):self.calls.append(args);return {'accepted':True}
        adapter=Bad();service=self.open(True,adapter)
        self.assertEqual(service.send_one()['state'],'UNKNOWN_NO_REDIAL')
        self.assertEqual(self.deliveries(),[('SENDING_UNCERTAIN',)])
        self.assertEqual(self.base.query('SELECT * FROM approvals'),[])

    def test_unavailable_route_does_not_claim_or_attempt(self):
        self.due();adapter=Adapter('UNAVAILABLE')
        self.assertEqual(self.open(True,adapter).send_one()['state'],'CAPABILITY_UNAVAILABLE')
        self.assertEqual(self.deliveries(),[('PENDING',)]);self.assertEqual(adapter.calls,[])

    def test_concurrent_confirmation_input_is_idempotent(self):
        e={'kind':'confirmation_created','event_id':'create1','request_id':'req1','task_id':'a',
           'blocker_id':'block','occurred_at':self.base.clock(),'verified':True}
        self.events['receipt']=e;barrier=threading.Barrier(2)
        def ingest():barrier.wait();return self.open().ingest('receipt')
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            a=pool.submit(ingest);b=pool.submit(ingest);results=[a.result(),b.result()]
        self.assertEqual(sorted(r['duplicate'] for r in results),[False,True])
        self.assertEqual(len(self.base.query("SELECT * FROM events WHERE event='P3_CONFIRMATION_INPUT'")),1)

    def test_restart_mapping_drift_fails_closed(self):
        self.service.scan()
        changed=self.open(mapping={'a':'changed','b':'block','independent':'block'})
        with self.assertRaises(ValueError):changed.scan()
        self.assertEqual(self.deliveries(),[])

    def test_existing_loop_hook_keeps_independent_execution_and_default_off(self):
        self.due();base=self.base
        class Pipeline:
            def run(self,c):base.finish(c);return {'state':'DONE'}
        loop=ReminderIntegratedLoop(base.ledger,lambda c:Pipeline(),'p3',reminders=self.service,poll_seconds=.01)
        self.addCleanup(loop.close);deadline=time.monotonic()+2
        while time.monotonic()<deadline:
            result=loop.tick()
            if base.ledger.observation('b')['state']=='DONE':break
            time.sleep(.01)
        self.assertEqual(base.ledger.observation('b')['state'],'DONE')
        self.assertEqual(result['owner_reminder']['delivery']['state'],'CAPABILITY_UNAVAILABLE')
        self.assertEqual(self.adapter.calls,[])

    def test_original_not_sent_reconcile_cannot_revive_answered_or_cancelled_episode(self):
        for index,kind in enumerate(('confirmation_responded','confirmation_cancelled')):
            rid='request'+str(index);self.event(request=rid);self.advance(300);self.service.scan()
            adapter=Adapter(fail=True);service=self.open(True,adapter)
            self.assertEqual(service.send_one()['state'],'UNKNOWN_NO_REDIAL')
            self.event(kind,request=rid);self.advance(31)
            with sqlite3.connect(self.base.path) as db:
                db.row_factory=sqlite3.Row
                row=dict(db.execute("SELECT * FROM supervision_delivery WHERE destination=? AND state='SENDING_UNCERTAIN' ORDER BY sent_at DESC LIMIT 1",(DESTINATION,)).fetchone())
            proof={'status':'NOT_SENT','proof_id':'fixture-provider-absence',
                   'delivery_identity':row['event_key']}
            for key in ('claim_token','claim_attempt','claim_epoch','authority_fence','authority_epoch'):proof[key]=row[key]
            self.assertEqual(self.base.supervisor.reconcile_delivery(row['event_key'],DESTINATION,'reconciler',lambda *a:proof),'RETRY_AUTHORIZED')
            self.advance(3);adapter.fail=False
            self.assertEqual(service.send_one()['state'],'CANCELLED')
            self.assertEqual(len(adapter.calls),1)

    def delivery_key(self):
        return self.base.query('SELECT event_key FROM supervision_delivery WHERE destination=? ORDER BY sent_at DESC LIMIT 1',(DESTINATION,))[0][0]

    def test_external_id_opaque_and_attempt_binding_durable_before_send(self):
        self.due();base=self.base
        class Inspect(Adapter):
            def send(self,key,message,binding,attempt_nonce):
                rows=base.query("SELECT details FROM events WHERE event='P3_REMINDER_ATTEMPT'")
                self.persisted=json.loads(rows[-1][0])
                return super().send(key,message,binding,attempt_nonce)
        adapter=Inspect();self.open(True,adapter).send_one()
        external_id=adapter.calls[0][0]
        self.assertRegex(external_id,'^[0-9a-f]{64}$')
        self.assertNotEqual(external_id,self.delivery_key());self.assertNotIn(':inventory:',external_id)
        self.assertEqual(adapter.persisted['external_notification_id'],external_id)
        self.assertEqual(adapter.persisted['binding'],adapter.route())

    def test_restart_wrong_channel_not_sent_cannot_unlock_unknown_phone(self):
        self.due();phone=Adapter(fail=True);self.open(True,phone).send_one();key=self.delivery_key()
        self.advance(31);fallback=Adapter('FALLBACK');service=self.open(True,fallback);lookups=[]
        def wrong_lookup(binding,external_id,attempt_nonce):
            lookups.append((binding,external_id))
            return {'status':'NOT_SENT','proof_id':'absence','notification_id':external_id,
                    'binding':fallback.route(),'attempt_nonce':attempt_nonce,'verified':True}
        self.assertEqual(service.reconcile_unknown(key,wrong_lookup),'HELD')
        self.assertEqual(lookups[0][0],phone.route())
        self.assertEqual(lookups[0][1],phone.calls[0][0])
        self.assertEqual(service.send_one()['state'],'NO_PENDING_REMINDER');self.assertEqual(fallback.calls,[])

    def test_bound_original_phone_absence_allows_verified_fallback(self):
        self.due();phone=Adapter(fail=True);self.open(True,phone).send_one();key=self.delivery_key()
        self.advance(31);fallback=Adapter('FALLBACK');service=self.open(True,fallback)
        def lookup(binding,external_id,attempt_nonce):
            return {'status':'NOT_SENT','proof_id':'phone-absence','notification_id':external_id,
                    'binding':binding,'attempt_nonce':attempt_nonce,'verified':True}
        self.assertEqual(service.reconcile_unknown(key,lookup),'RETRY_AUTHORIZED')
        self.advance(3);self.assertEqual(service.send_one()['state'],'PROVIDER_ACKED_NOT_APPROVAL')
        self.assertEqual(fallback.calls[0][2]['route'],'FALLBACK')
        self.assertEqual(fallback.calls[0][0],phone.calls[0][0])

    def test_unwrapped_absence_without_bound_proof_cannot_redial(self):
        self.due();adapter=Adapter(fail=True);service=self.open(True,adapter);service.send_one();self.advance(31)
        with sqlite3.connect(self.base.path) as db:
            db.row_factory=sqlite3.Row;row=dict(db.execute('SELECT * FROM supervision_delivery WHERE destination=?',(DESTINATION,)).fetchone())
        proof={'status':'NOT_SENT','proof_id':'unbound-absence','delivery_identity':row['event_key']}
        for key in ('claim_token','claim_attempt','claim_epoch','authority_fence','authority_epoch'):proof[key]=row[key]
        self.base.supervisor.reconcile_delivery(row['event_key'],DESTINATION,'reconciler',lambda *a:proof)
        self.advance(3);adapter.fail=False
        self.assertEqual(service.send_one()['state'],'BOUND_NOT_SENT_PROOF_REQUIRED')
        self.assertEqual(len(adapter.calls),1)

    def test_portfolio_replaces_overlapping_local_stall_not_two_calls(self):
        self.service=self.open(mapping={'a':'first','b':'first','independent':'second'})
        a,independent=self.two_tasks()
        self.base.ledger.finish('a',a['worker_id'],a['fence'],'PAUSED_RESOURCE',effects='none')
        self.base.write("UPDATE tasks SET depends='[]' WHERE id='b'")
        self.assertEqual(self.base.ledger.claim('third',ttl=3600)['task_id'],'b')
        self.service.scan();self.advance(1200);self.service.scan()
        service=self.open(True,mapping={'a':'first','b':'first','independent':'second'})
        service.send_one();service.send_one()
        self.assertEqual(len(self.adapter.calls),1)

    def population(self,n,bands=None):
        f=baseline.Fixture();f.setUp();self.addCleanup(f.doCleanups)
        names=['a','independent','b']+['task'+str(i) for i in range(max(0,n-3))]
        names=names[:n];pins={}
        original=baseline.ExecutionLedger(f.path,[baseline.REPO],clock=f.clock)
        for name in names:
            if name not in ('a','b','independent'):
                f.write('INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?,?)',(name,'CODEX_EXEC','PENDING','[]',None,None,0,'{}',f.clock()))
                pins[name]=original.register_spec(name,baseline.SPEC,'fixture-owner',True)['hash']
            else:pins[name]=f.pins[name]
            f.write("UPDATE tasks SET depends='[]' WHERE id=?",(name,))
        f.pins=pins;f.supervisor=baseline.P3Supervisor(f.path,f.clock,task_spec_pins=pins,p3_admitted=True)
        f.ledger=f.open()
        service=OwnerReminders(f.ledger,{t:'block' for t in pins},ratio_bands=bands)
        return f,service

    def give_origins(self,f):
        seen=set()
        for unused in f.pins:
            c=f.ledger.claim('origin',ttl=3600);self.assertIsNotNone(c);seen.add(c['task_id'])
            f.clock.now+=1
            f.ledger.finish(c['task_id'],c['worker_id'],c['fence'],'PAUSED_RESOURCE',effects='none')
            f.ledger.resume_resource(c['task_id'],'fixture-owner',True)
        self.assertEqual(seen,set(f.pins))

    def test_real_population_snapshots_cover_all_default_ratio_boundaries(self):
        for n,expected in [(1,1),(2,2),(3,2),(5,3),(6,3),(10,4),(11,4)]:
            with self.subTest(n=n):
                f,s=self.population(n);observed=s.scan()['progress_observation']
                self.assertEqual((observed['eligible_count'],observed['required_count']),(n,expected))
                f.clock.now+=1200
                self.assertEqual(s.scan()['queued'],[])  # READY has no invented execution progress
                self.give_origins(f);f.clock.now+=1200
                result=s.scan();self.assertEqual(result['progress_observation']['stalled_count'],n)
                self.assertEqual(len(result['queued']),1)
                self.assertLessEqual(f.query("SELECT COUNT(*) FROM tasks WHERE state='RUNNING'")[0][0],2)

    def test_ratio_configuration_strict_validation_and_restart_pin(self):
        invalid=[[],[(None,0)],[(None,float('nan'))],[(None,0.6)],[(2,100),(1,60),(None,30)],
                 [(None,100),(2,60)],[(2,100)],[(2,30),(None,60)],[(True,100),(None,30)]]
        for bands in invalid:
            with self.assertRaises(ValueError):self.open(ratio_bands=bands)
        self.service.scan()
        changed=self.open(ratio_bands=[(2,100),(None,50)])
        with self.assertRaises(ValueError):changed.scan()

    def test_membership_churn_cannot_reset_qualified_stalled_cohort(self):
        f,s=self.population(3);self.give_origins(f)
        f.write("UPDATE tasks SET state='FROZEN' WHERE id='b'");s.scan();f.clock.now+=1200
        f.write("UPDATE tasks SET state='PENDING' WHERE id='b'")
        first=s.scan();self.assertEqual(first['queued'],[])
        candidate=first['progress_observation']['latched_qualification'];self.assertIsNotNone(candidate)
        for state in ('FROZEN','PENDING','FROZEN'):
            f.clock.now+=20;f.write('UPDATE tasks SET state=? WHERE id=?',(state,'b'));last=s.scan()
        self.assertEqual(len(last['queued']),1)
        self.assertEqual(last['progress_observation']['latched_qualification']['qualified_at'],candidate['qualified_at'])

    def test_known_watchdog_hold_survives_original_loop_until_twenty_minute_ratio(self):
        a,b=self.two_tasks();self.base.proof(a);self.base.proof(b)
        self.advance(601);self.base.ledger.watchdog()
        self.assertEqual(self.base.ledger.observation('a')['state'],'WAITING_HUMAN')
        loop=ReminderIntegratedLoop(self.base.ledger,lambda c:None,'p3',reminders=self.service)
        self.addCleanup(loop.close);loop.tick();self.advance(599);result=loop.tick()
        observed=result['owner_reminder']['scan']['progress_observation']
        self.assertEqual(observed['eligible_count'],2);self.assertEqual(observed['stalled_count'],2)
        self.assertEqual(self.deliveries(),[('PENDING',)])

    def test_explicit_wait_freeze_unknown_excluded_but_five_minute_confirmation_independent(self):
        states={'a':'EXTERNAL_WAIT','b':'FROZEN','independent':'UNKNOWN'}
        def eligibility(task):
            return {'task_id':task,'fence':self.base.ledger.observation(task)['fence'],'state':states[task],'verified':True}
        self.service=self.open(eligibility_reader=eligibility)
        self.event();self.advance(300);result=self.service.scan()
        self.assertEqual(result['progress_observation']['eligible_count'],0)
        self.assertEqual(len(result['queued']),1)

    def test_old_absence_proof_cannot_unlock_second_attempt_same_business_id(self):
        self.due();adapter=Adapter(fail=True);service=self.open(True,adapter);service.send_one();key=self.delivery_key()
        self.advance(31);saved=[]
        def first(binding,external_id,attempt_nonce):
            proof={'status':'NOT_SENT','proof_id':'first-absence','notification_id':external_id,
                   'binding':binding,'attempt_nonce':attempt_nonce,'verified':True};saved.append(proof);return proof
        self.assertEqual(service.reconcile_unknown(key,first),'RETRY_AUTHORIZED')
        self.advance(3);self.assertEqual(service.send_one()['state'],'UNKNOWN_NO_REDIAL')
        self.assertEqual(adapter.calls[0][0],adapter.calls[1][0])
        self.assertNotEqual(adapter.calls[0][3],adapter.calls[1][3])
        self.advance(31)
        self.assertEqual(service.reconcile_unknown(key,lambda *a:saved[0]),'HELD')
        service.send_one();self.assertEqual(len(adapter.calls),2)

    def test_fallback_state_never_claims_a_phone_attempt(self):
        self.due();adapter=Adapter('FALLBACK')
        result=self.open(True,adapter).send_one()
        self.assertFalse(result['dial_attempted']);self.assertTrue(result['external_delivery_attempted'])
        self.assertEqual(result['route'],'FALLBACK')

    def test_threshold_drop_on_membership_change_has_bounded_not_immediate_trigger(self):
        f,s=self.population(3,[(2,100),(None,30)]);self.give_origins(f)
        f.write("UPDATE tasks SET state='FROZEN' WHERE id='b'");s.scan();f.clock.now+=1000
        c=f.ledger.claim('fresh',ttl=3600)
        f.progress_proofs['fresh']={'task_id':c['task_id'],'spec_hash':c['spec_hash'],'fence':c['fence'],
            'kind':'TEST_RUN','sha256':'d'*64,'verified':True}
        f.ledger.progress(c['task_id'],c['worker_id'],c['fence'],'fresh')
        f.ledger.finish(c['task_id'],c['worker_id'],c['fence'],'PAUSED_RESOURCE',effects='none')
        f.ledger.resume_resource(c['task_id'],'fixture-owner',True)
        f.clock.now+=200;self.assertEqual(s.scan()['queued'],[])
        f.write("UPDATE tasks SET state='PENDING' WHERE id='b'")
        result=s.scan();self.assertEqual(result['progress_observation']['required_count'],1)
        self.assertEqual(result['queued'],[])
        f.clock.now+=59;self.assertEqual(s.scan()['queued'],[])
        f.clock.now+=1;self.assertEqual(len(s.scan()['queued']),1)

    def test_fallback_timeout_reports_channel_effect_not_phone_dial(self):
        self.due();result=self.open(True,Adapter('FALLBACK',fail=True)).send_one()
        self.assertEqual(result['state'],'UNKNOWN_NO_REDIAL');self.assertFalse(result['dial_attempted'])
        self.assertTrue(result['external_delivery_attempted']);self.assertEqual(result['route'],'FALLBACK')

    def test_reminder_does_not_change_task_or_create_tables(self):
        before=self.base.query('SELECT * FROM tasks');tables=self.base.query("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        self.due();self.open(True).send_one()
        self.assertEqual(before,self.base.query('SELECT * FROM tasks'))
        self.assertEqual(tables,self.base.query("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"))
        self.assertEqual(self.base.ledger.claim('free')['task_id'],'a')

if __name__=='__main__':unittest.main()
