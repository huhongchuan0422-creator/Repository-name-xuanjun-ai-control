import concurrent.futures
import copy
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'candidate/stage1'),str(ROOT/'reference/runtime/stage1')]
from execution_ledger import ExecutionLedger, LeaseLost
from p3_lifecycle import P3Ledger,P3Supervisor,P3ContinuousLoop,digest

REPO='fixture/local'
SPEC={'repo':REPO,'type':'CODEX_EXEC','prompt':'local deterministic fixture only',
      'heavy':True,'timeout_seconds':30,'base_sha':'a'*40}

class Clock:
    def __init__(self):self.now=1000
    def __call__(self):return self.now

class Fixture(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.path=str(Path(self.tmp.name)/'original.sqlite');self.clock=Clock()
        db=sqlite3.connect(self.path)
        db.executescript('''CREATE TABLE tasks(id TEXT PRIMARY KEY,kind TEXT,state TEXT,depends TEXT,lease_owner TEXT,lease_until REAL,fence INTEGER,checkpoint TEXT,updated REAL);
CREATE TABLE approvals(task_id TEXT PRIMARY KEY,decision TEXT,requested_at REAL,decided_at REAL);
CREATE TABLE events(id INTEGER PRIMARY KEY,task_id TEXT,event TEXT,created REAL,details TEXT);''')
        for name,deps in [('a',[]),('b',['a']),('independent',[]),('p2',[])]:
            db.execute('INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?,?)',(name,'CODEX_EXEC','PENDING',json.dumps(deps),None,None,0,'{}',1000))
        db.commit();db.close()
        base=ExecutionLedger(self.path,[REPO],clock=self.clock)
        self.pins={}
        for name in ('a','b','independent','p2'):
            h=base.register_spec(name,SPEC,'fixture-owner',True)['hash']
            if name!='p2':self.pins[name]=h
        self.supervisor=P3Supervisor(self.path,self.clock,task_spec_pins=self.pins,p3_admitted=True)
        self.progress_proofs={};self.acceptances={};self.stops={}
        self.ledger=self.open()

    def open(self,**kwargs):
        return P3Ledger(self.path,[REPO],clock=self.clock,task_spec_pins=self.pins,
                        progress_reader=self.progress_proofs.get,acceptance_reader=self.acceptances.get,
                        stop_reader=self.stops.get,supervisor=self.supervisor,p3_admitted=kwargs.get('enabled',True))

    def query(self,sql,args=()):
        with sqlite3.connect(self.path) as db:return db.execute(sql,args).fetchall()

    def write(self,sql,args=()):
        with sqlite3.connect(self.path) as db:db.execute(sql,args)

    def owner_approve(self,task_id,decision='APPROVE',update=123):
        # Only callback request registration is a fixture; decision mutation uses
        # the REAL original API, including request consumption/replay/state CAS.
        with sqlite3.connect(self.path) as db:
            db.execute('CREATE TABLE IF NOT EXISTS owner_callback_requests(request_id TEXT PRIMARY KEY,task_id TEXT,fence INTEGER,owner_id TEXT,owner_chat TEXT,expires_at REAL,consumed INTEGER)')
            db.execute('CREATE TABLE IF NOT EXISTS owner_callback_replays(update_id INTEGER PRIMARY KEY,request_id TEXT)')
            fence=self.ledger.observation(task_id)['fence']
            request='fixture-request-'+str(update)
            db.execute('INSERT INTO owner_callback_requests VALUES(?,?,?,?,?,?,?)',
                       (request,task_id,fence,'owner','chat',self.clock()+100,0))
        return self.ledger.owner_decision(task_id,fence,decision,request,update,'owner','chat','trusted-owner-fixture',True)

    def proof(self,claim):
        cp=self.ledger.observation(claim['task_id'])['checkpoint'];commit='b'*40;artifact='c'*64
        # Exercise real original dispatch + bound STARTED receipt contract.
        task=self.ledger.observation(claim['task_id'])
        existing,unused=self.supervisor.snapshot(claim['task_id'])
        if existing is None:
            self.supervisor.dispatch(claim['task_id'],claim['spec_hash'],'LOCAL_FIXTURE','run-'+claim['task_id'],
                'session-'+claim['task_id'],self.tmp.name,artifact,self.clock()+10,self.clock()+20,self.clock()+30,cp,'fixture-budget',1)
            receipt={'task_id':claim['task_id'],'spec_hash':claim['spec_hash'],'artifact':artifact,
                'executor':'LOCAL_FIXTURE','run_id':'run-'+claim['task_id'],'session_id':'session-'+claim['task_id'],
                'lease_owner':claim['worker_id'],'lease_until':task['lease_until'],'fence':claim['fence'],
                'epoch':0,'generation':0,'resume_generation':0,'stop_requested':False,
                'checkpoint':cp,'checkpoint_version':0,'checkpoint_hash':digest(cp),
                'budget_key':'fixture-budget','budget_spent':1,'native_state':'RUNNING'}
            self.supervisor.accept_started(claim['task_id'],'RUNNING',claim['worker_id'],task['lease_until'],claim['fence'],cp,receipt)
        p={'task_id':claim['task_id'],'spec_hash':claim['spec_hash'],'fence':claim['fence'],
           'checkpoint_sha256':digest(cp),'commit':commit,'artifact_sha256':artifact,
           'terminal_receipt':'fixture-only-terminal','effects':'KNOWN','writer_stopped':True,
           'scope':'LOCAL_INTEGRATION','authority_verified':True,'author':'fixture-author'}
        for role in ('tests','ci','qa','security','business'):
            p[role]={'status':'PASS','commit':commit,'artifact_sha256':artifact,
                     'receipt_sha256':digest(role),'actor':'fixture-'+role}
        return p

    def finish(self,c):
        self.acceptances[c['task_id']]=self.proof(c)
        return self.ledger.finish(c['task_id'],c['worker_id'],c['fence'],'DONE')

    def test_default_closed_and_p2_unchanged(self):
        before=self.query("SELECT * FROM tasks WHERE id='p2'")
        with self.assertRaises(PermissionError):self.open(enabled=False).claim('w')
        c=self.ledger.claim('w');self.assertEqual(c['task_id'],'a')
        self.assertEqual(before,self.query("SELECT * FROM tasks WHERE id='p2'"))

    def test_two_successors_persist_before_progress(self):
        c=self.ledger.claim('w');self.finish(c)
        next_claim=self.open().claim('w2');self.assertEqual(next_claim['task_id'],'b')
        events=self.query("SELECT event FROM events WHERE task_id='a' ORDER BY id")
        self.assertLess(events.index(('P3_ACCEPTED_RESULT',)),events.index(('EXECUTION_FINISHED',)))
        self.finish(next_claim);self.assertEqual(self.open().observation('b')['state'],'DONE')

    def test_done_needs_exact_independent_acceptance(self):
        c=self.ledger.claim('w');p=self.proof(c)
        for bad in (None,{},dict(p,scope='PRODUCTION'),dict(p,fence=True),dict(p,checkpoint_sha256='e'*64),dict(p,extra='secret')):
            self.acceptances['a']=bad
            with self.assertRaises(ValueError):self.ledger.finish('a','w',c['fence'],'DONE')
        for role in ('tests','ci','qa','security','business'):
            bad=copy.deepcopy(p);bad[role]['commit']='d'*40;self.acceptances['a']=bad
            with self.assertRaises(ValueError):self.ledger.finish('a','w',c['fence'],'DONE')
        bad=copy.deepcopy(p);bad['qa']['actor']=p['author'];self.acceptances['a']=bad
        with self.assertRaises(ValueError):self.ledger.finish('a','w',c['fence'],'DONE')
        self.assertEqual(self.ledger.observation('a')['state'],'RUNNING')

    def test_heartbeat_does_not_count_progress(self):
        c=self.ledger.claim('w',ttl=1200);self.clock.now+=601
        self.ledger.heartbeat('a','w',c['fence'],ttl=1200)
        self.assertEqual(self.ledger.watchdog(),['a'])
        self.assertEqual(self.ledger.observation('a')['state'],'WAITING_HUMAN')
        with self.assertRaises(LeaseLost):self.ledger.heartbeat('a','w',c['fence'])
        other=self.ledger.claim('other');self.assertEqual(other['task_id'],'independent')
        self.assertIsNone(self.ledger.claim('third'))

    def test_unique_progress_not_replayed(self):
        c=self.ledger.claim('w',ttl=1200)
        p={'task_id':'a','spec_hash':c['spec_hash'],'fence':c['fence'],'kind':'SOURCE_COMMIT','sha256':'d'*64,'verified':True}
        self.progress_proofs['receipt']=p
        self.clock.now+=400;self.assertTrue(self.ledger.progress('a','w',c['fence'],'receipt'))
        self.clock.now+=400;self.assertFalse(self.ledger.progress('a','w',c['fence'],'receipt'))
        self.assertEqual(self.ledger.watchdog(),[])
        self.clock.now+=201;self.assertEqual(self.ledger.watchdog(),['a'])

    def test_unverified_or_heartbeat_evidence_rejected(self):
        c=self.ledger.claim('w')
        for kind in ('HEARTBEAT','REPORT','ACK'):
            self.progress_proofs['receipt']={'task_id':'a','spec_hash':c['spec_hash'],'fence':c['fence'],'kind':kind,'sha256':'d'*64,'verified':True}
            with self.assertRaises(ValueError):self.ledger.progress('a','w',c['fence'],'receipt')

    def test_expired_unknown_preserves_checkpoint_no_replay(self):
        c=self.ledger.claim('w');self.ledger.checkpoint('a','w',c['fence'],{'phase':'WRITE_UNKNOWN','done_steps':['one']})
        self.clock.now+=61;self.open().recover_expired()
        self.assertEqual(self.ledger.observation('a')['checkpoint']['done_steps'],['one'])
        self.assertEqual(self.ledger.claim('other')['task_id'],'independent')
        self.assertEqual(len(self.query("SELECT * FROM events WHERE task_id='a' AND event='EXECUTION_CLAIMED'")),1)

    def test_stop_reconcile_releases_capacity_not_approval(self):
        c=self.ledger.claim('w');self.clock.now+=61;self.ledger.recover_expired()
        proof={'task_id':'a','spec_hash':c['spec_hash'],'fence':c['fence'],'writer_stopped':True,
               'descendants_stopped':True,'effects':'UNKNOWN','epoch':0,'checkpoint_sha256':digest({}),'receipt_sha256':'e'*64,'authority_verified':True}
        self.stops['stop']=proof
        with self.assertRaises(ValueError):self.ledger.reconcile_stopped('a','stop')
        proof['effects']='KNOWN';self.assertTrue(self.ledger.reconcile_stopped('a','stop'))
        self.assertFalse(self.ledger.reconcile_stopped('a','stop'))
        with self.assertRaises(PermissionError):self.ledger.resume_human('a','reviewer')
        self.assertEqual(self.ledger.observation('a')['state'],'WAITING_HUMAN')

    def test_one_invalid_spec_does_not_stop_independent(self):
        self.write("UPDATE execution_specs SET hash=? WHERE task_id='a'",('f'*64,))
        self.assertEqual(self.ledger.claim('w')['task_id'],'independent')
        self.assertEqual(self.ledger.observation('a')['state'],'WAITING_HUMAN')
        self.assertEqual(self.ledger.observation('b')['state'],'PENDING')

    def test_p2_expired_not_recovered(self):
        self.write("UPDATE tasks SET state='RUNNING',lease_owner='p2writer',lease_until=1,fence=9 WHERE id='p2'")
        before=self.query("SELECT * FROM tasks WHERE id='p2'");self.ledger.recover_expired()
        self.assertEqual(before,self.query("SELECT * FROM tasks WHERE id='p2'"))

    def test_supervisor_heartbeat_without_completed_scan_stalls(self):
        self.assertEqual(self.ledger.health()['state'],'SUPERVISOR_STALLED')
        self.ledger.pulse('START');self.assertEqual(self.ledger.health()['state'],'SUPERVISOR_STALLED')
        self.ledger.pulse('COMPLETE');self.assertEqual(self.ledger.health()['state'],'HEALTHY')
        self.clock.now+=31;self.ledger.pulse('START')
        self.assertEqual(self.open().health()['state'],'SUPERVISOR_STALLED')

    def test_concurrent_claims_keep_one_writer_and_two_heavy_limit(self):
        barrier=threading.Barrier(3)
        def claim(i):
            ledger=self.open();barrier.wait();return ledger.claim('w'+str(i))
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            results=list(pool.map(claim,range(3)))
        claims=[r for r in results if r]
        self.assertEqual({c['task_id'] for c in claims},{'a','independent'})
        self.assertEqual(len(claims),2)

    def test_failure_notice_does_not_erase_accepted_result(self):
        c=self.ledger.claim('w');self.finish(c)
        # Notification callback failing AFTER committed result is deliberately external.
        try:raise ConnectionError('lost notification')
        except ConnectionError:pass
        self.assertEqual(self.open().observation('a')['state'],'DONE')
        self.assertEqual(self.open().claim('next')['task_id'],'b')

    def test_verified_approved_resume_preserves_native_checkpoint_budget(self):
        c=self.ledger.claim('w',ttl=1200)
        self.ledger.checkpoint('a','w',c['fence'],{'done_steps':['already-done'],'patch_attempts':2})
        self.proof(c)
        self.clock.now+=601;self.ledger.watchdog()
        cp=self.ledger.observation('a')['checkpoint']
        self.stops['stop']={'task_id':'a','spec_hash':c['spec_hash'],'fence':c['fence'],
            'writer_stopped':True,'descendants_stopped':True,'effects':'KNOWN','epoch':0,
            'checkpoint_sha256':digest(cp),'receipt_sha256':'e'*64,'authority_verified':True}
        self.ledger.reconcile_stopped('a','stop')
        self.owner_approve('a')
        result=self.ledger.resume_human('a','fixture-reviewer')
        self.assertEqual(result,'RESUME_SAME_TASK_BUDGET')
        run,unused=self.supervisor.snapshot('a')
        self.assertEqual(run['budget_spent'],1)
        self.assertEqual(json.loads(run['checkpoint']),cp)
        self.assertEqual(run['status'],'RESUMABLE')
        # Existing native run cannot be relaunched as a fresh generic pipeline.
        self.assertEqual(self.ledger.claim('new')['task_id'],'independent')
        self.assertEqual(self.ledger.observation('a')['state'],'PENDING')

    def test_stopped_receipt_wrong_checkpoint_or_epoch_rejected(self):
        c=self.ledger.claim('w');self.clock.now+=61;self.ledger.recover_expired()
        proof={'task_id':'a','spec_hash':c['spec_hash'],'fence':c['fence'],'writer_stopped':True,
            'descendants_stopped':True,'effects':'KNOWN','epoch':0,'checkpoint_sha256':digest({}),
            'receipt_sha256':'e'*64,'authority_verified':True}
        for key,value in [('checkpoint_sha256','e'*64),('epoch',1),('fence',True),('descendants_stopped',False)]:
            self.stops['stop']=dict(proof,**{key:value})
            with self.assertRaises(ValueError):self.ledger.reconcile_stopped('a','stop')

    def test_accepted_result_and_original_outbox_rollback_together(self):
        c=self.ledger.claim('w');self.acceptances['a']=self.proof(c)
        original=self.supervisor._event
        def fail(*a,**kw):raise RuntimeError('injected outbox failure')
        self.supervisor._event=fail
        try:
            with self.assertRaises(RuntimeError):self.ledger.finish('a','w',c['fence'],'DONE')
        finally:self.supervisor._event=original
        self.assertEqual(self.ledger.observation('a')['state'],'RUNNING')
        self.assertEqual(self.query("SELECT * FROM events WHERE event='P3_ACCEPTED_RESULT'"),[])
        run,unused=self.supervisor.snapshot('a');self.assertEqual(run['status'],'STARTED')
        self.ledger.finish('a','w',c['fence'],'DONE')
        self.assertEqual(len(self.query("SELECT * FROM supervision_events WHERE kind='P3_ACCEPTED_RESULT'")),1)
        self.assertEqual(len(self.query("SELECT * FROM supervision_delivery WHERE event_key LIKE '%P3_ACCEPTED_RESULT'")),2)

    def test_no_started_native_receipt_cannot_complete(self):
        c=self.ledger.claim('w');self.acceptances['a']=self.proof(c)
        self.write("UPDATE supervised_runs SET status='DISPATCHED' WHERE task_id='a'")
        with self.assertRaises(ValueError):self.ledger.finish('a','w',c['fence'],'DONE')

    def test_p2_mutation_apis_rejected(self):
        before=self.query("SELECT * FROM tasks WHERE id='p2'")
        with self.assertRaises(PermissionError):self.ledger.register_spec('p2',SPEC,'fixture',True)
        with self.assertRaises(PermissionError):self.ledger.resume_resource('p2','fixture',True)
        self.assertEqual(before,self.query("SELECT * FROM tasks WHERE id='p2'"))

    def test_spec_drift_running_writer_still_consumes_slot(self):
        c=self.ledger.claim('w')
        self.write("UPDATE execution_specs SET hash=? WHERE task_id='a'",('f'*64,))
        self.assertEqual(self.ledger.claim('other')['task_id'],'independent')
        self.assertIsNone(self.ledger.claim('third'))
        self.assertEqual(len(self.query("SELECT * FROM events WHERE task_id='a' AND event='P3_UNRESOLVED_WRITER'")),1)

    def test_pipeline_error_isolates_chain_and_repeated_ticks_no_replay(self):
        fixture=self;calls=[]
        class Pipeline:
            def run(self,c):
                calls.append(c['task_id'])
                if c['task_id']=='a':raise RuntimeError('fixture crash')
                fixture.finish(c);return {'state':'DONE'}
        loop=P3ContinuousLoop(self.ledger,lambda c:Pipeline(),'p3',poll_seconds=.01)
        self.addCleanup(loop.close);deadline=time.monotonic()+2
        while time.monotonic()<deadline:
            loop.tick()
            if self.ledger.observation('independent')['state']=='DONE':break
            time.sleep(.01)
        for unused in range(4):loop.tick()
        self.assertEqual(calls.count('a'),1);self.assertEqual(calls.count('independent'),1)
        self.assertEqual(self.ledger.observation('b')['state'],'PENDING')
        self.assertEqual(self.ledger.observation('a')['state'],'WAITING_HUMAN')

    def prepare_native_resume(self):
        c=self.ledger.claim('old',ttl=1200);self.proof(c)
        self.clock.now+=601;self.ledger.watchdog()
        approved=self.owner_approve('a')
        self.assertEqual(approved['state'],'PENDING')
        cp=self.ledger.observation('a')['checkpoint']
        self.stops['stop']={'task_id':'a','spec_hash':c['spec_hash'],'fence':c['fence'],
            'writer_stopped':True,'descendants_stopped':True,'effects':'KNOWN','epoch':0,
            'checkpoint_sha256':digest(cp),'receipt_sha256':'e'*64,'authority_verified':True}
        self.ledger.reconcile_stopped('a','stop')
        self.assertEqual(self.ledger.resume_human('a','reviewer'),'RESUME_SAME_TASK_BUDGET')
        return c

    def dispatch_resume(self,supervisor=None):
        t=self.ledger.observation('a');now=self.clock()
        return (supervisor or self.supervisor).resume_dispatch('a','resume-run','resume-session',
            now+10,now+20,now+30,'resume-writer',now+1200,t['fence']+1,0,0)

    def accept_resume(self,admission):
        self.assertTrue(self.supervisor.validate_launch(admission))
        run,unused=self.supervisor.snapshot('a');task=self.ledger.observation('a')
        receipt={'task_id':'a','spec_hash':self.pins['a'],'artifact':run['artifact'],
            'executor':run['executor'],'run_id':run['run_id'],'session_id':run['session_id'],
            'lease_owner':task['lease_owner'],'lease_until':task['lease_until'],'fence':task['fence'],
            'epoch':0,'generation':0,'resume_generation':run['resume_generation'],'stop_requested':False,
            'checkpoint':task['checkpoint'],'checkpoint_version':run['checkpoint_version'],
            'checkpoint_hash':run['checkpoint_hash'],'budget_key':run['budget_key'],
            'budget_spent':run['budget_spent'],'native_state':'RUNNING'}
        self.supervisor.accept_started('a','RUNNING',task['lease_owner'],task['lease_until'],task['fence'],task['checkpoint'],receipt)
        return task

    def test_real_owner_api_resume_dispatch_started_watchdog_chain(self):
        self.prepare_native_resume()
        # Reconciliation retries do not advance fence or append another resume marker.
        fence=self.ledger.observation('a')['fence']
        self.ledger.resume_human('a','reviewer')
        self.assertEqual(self.ledger.observation('a')['fence'],fence)
        self.assertEqual(len(self.query("SELECT * FROM events WHERE event='HUMAN_REVIEW_RESUMED'")),1)
        task=self.accept_resume(self.dispatch_resume())
        self.assertEqual(self.ledger.watchdog(),[])
        self.assertEqual(self.ledger.observation('a')['state'],'RUNNING')
        self.clock.now+=599
        self.assertEqual(self.ledger.watchdog(),[])
        self.ledger.heartbeat('a','resume-writer',task['fence'],ttl=1200)
        self.clock.now+=1
        self.assertEqual(self.ledger.watchdog(),['a'])

    def test_real_owner_reject_and_replay_remain_denied(self):
        c=self.ledger.claim('old');self.clock.now+=61;self.ledger.recover_expired()
        receipt=self.owner_approve('a',decision='REJECT')
        self.assertEqual(receipt['state'],'FAILED')
        with self.assertRaises(PermissionError):self.ledger.resume_human('a','reviewer')
        with self.assertRaises(PermissionError):
            self.ledger.owner_decision('a',receipt['fence'],'APPROVE','fixture-request-123',123,'owner','chat','trusted',True)

    def test_loop_first_spec_drift_keeps_independent_progress(self):
        self.write("UPDATE execution_specs SET hash=? WHERE task_id='a'",('f'*64,))
        fixture=self
        class Pipeline:
            def run(self,c):fixture.finish(c);return {'state':'DONE'}
        loop=P3ContinuousLoop(self.ledger,lambda c:Pipeline(),'p3',poll_seconds=.01)
        self.addCleanup(loop.close);deadline=time.monotonic()+2
        while time.monotonic()<deadline:
            loop.tick()
            if self.ledger.observation('independent')['state']=='DONE':break
            time.sleep(.01)
        self.assertEqual(self.ledger.observation('independent')['state'],'DONE')
        self.assertEqual(self.ledger.health()['state'],'HEALTHY')
        self.assertEqual(self.ledger.observation('b')['state'],'PENDING')

    def test_original_resume_capacity_rejects_third_heavy(self):
        self.prepare_native_resume()
        self.write("UPDATE tasks SET depends='[]' WHERE id='b'")
        self.assertEqual(self.ledger.claim('second')['task_id'],'b')
        self.assertEqual(self.ledger.claim('third')['task_id'],'independent')
        before=self.supervisor.snapshot('a')[0]
        with self.assertRaisesRegex(ValueError,'P3_RESUME_CAPACITY_WAIT'):self.dispatch_resume()
        self.assertEqual(self.supervisor.snapshot('a')[0],before)
        self.assertEqual(self.query("SELECT COUNT(*) FROM tasks WHERE state='RUNNING'")[0][0],2)

    def test_concurrent_original_resume_and_claim_one_remaining_slot(self):
        self.prepare_native_resume()
        self.assertEqual(self.ledger.claim('occupied')['task_id'],'independent')
        self.write("UPDATE tasks SET depends='[]' WHERE id='b'")
        barrier=threading.Barrier(2)
        def resume():
            other=P3Supervisor(self.path,self.clock,task_spec_pins=self.pins,p3_admitted=True)
            barrier.wait()
            try:return self.dispatch_resume(other)
            except ValueError as e:
                self.assertEqual(str(e),'P3_RESUME_CAPACITY_WAIT');return None
        def claim():
            other=self.open();barrier.wait();return other.claim('competing')
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            x=pool.submit(resume);y=pool.submit(claim);results=[x.result(),y.result()]
        self.assertEqual(sum(r is not None for r in results),1)
        self.assertEqual(self.query("SELECT COUNT(*) FROM tasks WHERE state='RUNNING'")[0][0],2)

    def test_started_public_checkpoint_survives_verified_native_resume(self):
        c=self.ledger.claim('old',ttl=1200);self.proof(c)
        cp={'done_steps':['already-done'],'patch_attempts':2}
        self.ledger.checkpoint('a','old',c['fence'],cp)
        run,unused=self.supervisor.snapshot('a')
        self.assertEqual(json.loads(run['checkpoint']),cp)
        self.assertEqual(run['checkpoint_hash'],digest(cp))
        self.clock.now+=601;self.ledger.watchdog();self.owner_approve('a')
        self.stops['stop']={'task_id':'a','spec_hash':c['spec_hash'],'fence':c['fence'],
            'writer_stopped':True,'descendants_stopped':True,'effects':'KNOWN','epoch':0,
            'checkpoint_sha256':digest(cp),'receipt_sha256':'e'*64,'authority_verified':True}
        self.ledger.reconcile_stopped('a','stop')
        self.assertEqual(self.ledger.resume_human('a','reviewer'),'RESUME_SAME_TASK_BUDGET')
        self.accept_resume(self.dispatch_resume())
        self.assertEqual(self.ledger.observation('a')['checkpoint'],cp)
        self.assertEqual(json.loads(self.supervisor.snapshot('a')[0]['checkpoint']),cp)
        self.assertEqual(self.ledger.watchdog(),[])

    def test_original_loop_blocked_checkpoint_stays_synchronized(self):
        c=self.ledger.claim('old',ttl=1200);self.proof(c)
        loop=P3ContinuousLoop(self.ledger,lambda c:None,'p3');self.addCleanup(loop.close)
        loop._blocked(c,'PIPELINE_RESULT_UNCONFIRMED')
        cp=self.ledger.observation('a')['checkpoint']
        self.assertEqual(cp['error_code'],'PIPELINE_RESULT_UNCONFIRMED')
        run,unused=self.supervisor.snapshot('a')
        self.assertEqual(json.loads(run['checkpoint']),cp)
        self.assertEqual(run['checkpoint_hash'],digest(cp))
        self.assertEqual(self.ledger.observation('a')['state'],'WAITING_HUMAN')

    def test_started_checkpoint_expired_writer_and_native_override_denied(self):
        c=self.ledger.claim('old');self.proof(c)
        before=self.supervisor.snapshot('a')[0]
        with self.assertRaises(ValueError):self.ledger.checkpoint('a','old',c['fence'],{'native_execution':{'fake':True}})
        self.clock.now+=61
        with self.assertRaises(LeaseLost):self.ledger.checkpoint('a','old',c['fence'],{'step':'new'})
        self.assertEqual(self.supervisor.snapshot('a')[0],before)
        self.assertEqual(self.ledger.observation('a')['checkpoint'],{})

    def test_trusted_stop_atomically_reconciles_original_unknown_effects(self):
        c=self.ledger.claim('old',ttl=1200);self.proof(c)
        t=self.ledger.observation('a')
        self.supervisor.observe('a','RUNNING','UNKNOWN','old',t['lease_until'],self.clock(),effects='UNKNOWN')
        self.clock.now+=601;self.ledger.watchdog();self.owner_approve('a')
        proof={'task_id':'a','spec_hash':c['spec_hash'],'fence':c['fence'],'writer_stopped':True,
            'descendants_stopped':True,'effects':'KNOWN','epoch':0,'checkpoint_sha256':digest({}),
            'receipt_sha256':'e'*64,'authority_verified':True}
        self.stops['stop']=dict(proof,authority_verified=False)
        with self.assertRaises(ValueError):self.ledger.reconcile_stopped('a','stop')
        self.assertEqual(self.supervisor.snapshot('a')[0]['effects'],'UNKNOWN')
        self.stops['stop']=proof
        self.assertTrue(self.ledger.reconcile_stopped('a','stop'))
        self.assertEqual(self.supervisor.snapshot('a')[0]['effects'],'KNOWN')
        self.assertEqual(self.ledger.resume_human('a','reviewer'),'RESUME_SAME_TASK_BUDGET')
        self.accept_resume(self.dispatch_resume())
        self.assertEqual(self.ledger.watchdog(),[])

    def test_watchdog_between_original_resume_dispatch_and_started(self):
        self.prepare_native_resume();admission=self.dispatch_resume()
        self.assertEqual(self.ledger.watchdog(),[])
        self.assertEqual(self.ledger.observation('a')['state'],'RUNNING')
        self.clock.now+=9
        self.assertEqual(self.ledger.watchdog(),[])
        self.accept_resume(admission)
        self.assertEqual(self.ledger.watchdog(),[])

    def test_unacked_original_resume_expires_at_bound_start_deadline(self):
        self.prepare_native_resume();admission=self.dispatch_resume()
        self.clock.now+=10
        self.assertEqual(self.ledger.watchdog(),['a'])
        self.assertEqual(self.ledger.observation('a')['state'],'WAITING_HUMAN')
        self.assertEqual(len(self.query("SELECT * FROM events WHERE task_id='a' AND event='P3_START_ACK_TIMEOUT'")),1)
        with self.assertRaises(ValueError):self.supervisor.validate_launch(admission)

    def test_stale_reconcile_retry_cannot_hold_new_started_generation(self):
        self.prepare_native_resume()
        paused=threading.Event();proceed=threading.Event()
        original=self.supervisor.reconcile_verified
        def delayed(task_id,expected):
            paused.set();self.assertTrue(proceed.wait(3))
            return original(task_id,expected)
        self.supervisor.reconcile_verified=delayed
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                retry=pool.submit(self.ledger.resume_human,'a','retry')
                self.assertTrue(paused.wait(3))
                admission=self.dispatch_resume();self.accept_resume(admission)
                proceed.set()
                with self.assertRaises(LeaseLost):retry.result()
        finally:
            proceed.set();self.supervisor.reconcile_verified=original
        self.assertEqual(self.supervisor.snapshot('a')[0]['status'],'STARTED')
        self.assertEqual(self.ledger.observation('a')['state'],'RUNNING')
        self.assertEqual(self.ledger.watchdog(),[])

    def test_unacked_timeout_stop_proof_allows_next_generation_not_fake_started(self):
        self.prepare_native_resume();ad=self.dispatch_resume()
        self.clock.now+=10;self.ledger.watchdog()
        proof={'task_id':'a','spec_hash':ad['spec_hash'],'fence':ad['fence'],'writer_stopped':True,
            'descendants_stopped':True,'effects':'KNOWN','epoch':0,'checkpoint_sha256':ad['checkpoint_hash'],
            'receipt_sha256':'d'*64,'authority_verified':True,'run_id':ad['run_id'],
            'session_id':ad['session_id'],'resume_generation':ad['resume_generation']}
        self.stops['stop2']=dict(proof,resume_generation=0)
        with self.assertRaises(ValueError):self.ledger.reconcile_stopped('a','stop2')
        self.stops['stop2']=dict(proof,run_id='old-run')
        with self.assertRaises(ValueError):self.ledger.reconcile_stopped('a','stop2')
        self.stops['stop2']=proof;self.ledger.reconcile_stopped('a','stop2')
        run,unused=self.supervisor.snapshot('a')
        self.assertIsNone(run['started_at']);self.assertIsNone(run['start_receipt'])
        self.assertEqual(run['native_state'],'STOPPED')
        self.owner_approve('a',update=124)
        self.assertEqual(self.ledger.resume_human('a','reviewer'),'RESUME_SAME_TASK_BUDGET')
        now=self.clock();task=self.ledger.observation('a')
        second=self.supervisor.resume_dispatch('a','second-resume','second-session',now+10,now+20,now+30,
            'second-writer',now+1200,task['fence']+1,0,0)
        self.assertEqual(second['resume_generation'],ad['resume_generation']+1)
        self.assertEqual(second['checkpoint'],ad['checkpoint'])
        self.assertEqual(second['budget_spent'],ad['budget_spent'])
        self.assertEqual(self.ledger.watchdog(),[])
        self.accept_resume(second)
        self.assertEqual(self.supervisor.snapshot('a')[0]['status'],'STARTED')

    def test_first_dispatch_ack_loss_deadline_stop_and_safe_resume(self):
        c=self.ledger.claim('initial',ttl=1200);now=self.clock()
        self.supervisor.dispatch('a',c['spec_hash'],'LOCAL_FIXTURE','first-run','first-session',
            self.tmp.name,'c'*64,now+10,now+20,now+30,{},'fixture-budget',1)
        self.assertEqual(self.ledger.watchdog(),[])
        self.clock.now+=9;self.assertEqual(self.ledger.watchdog(),[])
        self.clock.now+=1;self.assertEqual(self.ledger.watchdog(),['a'])
        proof={'task_id':'a','spec_hash':c['spec_hash'],'fence':c['fence'],'writer_stopped':True,
            'descendants_stopped':True,'effects':'KNOWN','epoch':0,'checkpoint_sha256':digest({}),
            'receipt_sha256':'d'*64,'authority_verified':True,'run_id':'first-run',
            'session_id':'first-session','resume_generation':0}
        for key,bad in [('run_id','wrong'),('resume_generation',1),('fence',c['fence']+1)]:
            self.stops['first-stop']=dict(proof,**{key:bad})
            with self.assertRaises(ValueError):self.ledger.reconcile_stopped('a','first-stop')
        self.stops['first-stop']=proof;self.ledger.reconcile_stopped('a','first-stop')
        run,unused=self.supervisor.snapshot('a')
        self.assertIsNone(run['started_at']);self.assertIsNone(run['start_receipt'])
        self.owner_approve('a');self.assertEqual(self.ledger.resume_human('a','reviewer'),'RESUME_SAME_TASK_BUDGET')
        admission=self.dispatch_resume();self.assertEqual(admission['resume_generation'],1)
        self.assertEqual(self.ledger.watchdog(),[])
        self.accept_resume(admission);self.assertEqual(self.ledger.watchdog(),[])

    def test_first_dispatch_wrong_spec_rejected_atomically(self):
        c=self.ledger.claim('initial');now=self.clock()
        with self.assertRaises(ValueError):
            self.supervisor.dispatch('a','f'*64,'LOCAL_FIXTURE','first-run','first-session',
                self.tmp.name,'c'*64,now+10,now+20,now+30,{},'fixture-budget',1)
        self.assertIsNone(self.supervisor.snapshot('a')[0])
        self.assertEqual(self.query("SELECT * FROM supervision_events WHERE task_id='a'"),[])

    def test_unstarted_original_observe_stalled_still_reconciles_exact_admission(self):
        c=self.ledger.claim('initial',ttl=1200);now=self.clock()
        self.supervisor.dispatch('a',c['spec_hash'],'LOCAL_FIXTURE','first-run','first-session',
            self.tmp.name,'c'*64,now+10,now+20,now+30,{},'fixture-budget',1)
        self.clock.now+=10
        self.supervisor.observe('a','RUNNING','UNKNOWN','initial',now+1200,None,effects='UNKNOWN')
        self.assertEqual(self.supervisor.snapshot('a')[0]['status'],'STALLED')
        self.assertEqual(self.ledger.watchdog(),['a'])
        self.stops['stop']={'task_id':'a','spec_hash':c['spec_hash'],'fence':c['fence'],'writer_stopped':True,
            'descendants_stopped':True,'effects':'KNOWN','epoch':0,'checkpoint_sha256':digest({}),
            'receipt_sha256':'d'*64,'authority_verified':True,'run_id':'first-run',
            'session_id':'first-session','resume_generation':0}
        self.ledger.reconcile_stopped('a','stop');self.owner_approve('a')
        self.assertEqual(self.ledger.resume_human('a','reviewer'),'RESUME_SAME_TASK_BUDGET')
        self.accept_resume(self.dispatch_resume())
        self.assertEqual(self.ledger.watchdog(),[])

    def test_original_terminal_observation_before_acceptance_commits_exact_result(self):
        c=self.ledger.claim('w');proof=self.proof(c);self.acceptances['a']=proof
        t=self.ledger.observation('a')
        self.supervisor.observe('a','RUNNING','EXITED','w',t['lease_until'],self.clock(),
            terminal_receipt=proof['terminal_receipt'],effects=proof['effects'])
        self.assertEqual(self.supervisor.snapshot('a')[0]['status'],'COMPLETED')
        self.ledger.finish('a','w',c['fence'],'DONE')
        self.assertEqual(self.ledger.observation('a')['state'],'DONE')

    def test_original_terminal_mismatch_does_not_become_accepted(self):
        c=self.ledger.claim('w');proof=self.proof(c);self.acceptances['a']=proof
        t=self.ledger.observation('a')
        self.supervisor.observe('a','RUNNING','EXITED','w',t['lease_until'],self.clock(),
            terminal_receipt='different-result',effects='KNOWN')
        with self.assertRaises(ValueError):self.ledger.finish('a','w',c['fence'],'DONE')
        self.assertEqual(self.ledger.observation('a')['state'],'RUNNING')

    def completed_crash(self):
        c=self.ledger.claim('old');proof=self.proof(c)
        t=self.ledger.observation('a')
        self.supervisor.observe('a','RUNNING','EXITED','old',t['lease_until'],self.clock(),
            terminal_receipt=proof['terminal_receipt'],effects=proof['effects'])
        self.clock.now+=61;self.ledger.watchdog()
        run,unused=self.supervisor.snapshot('a')
        proof['recovery']={'current_fence':self.ledger.observation('a')['fence'],
            'run_id':run['run_id'],'session_id':run['session_id'],'resume_generation':run['resume_generation'],
            'epoch':0,'generation':0}
        return proof

    def test_completed_crash_reconciles_acceptance_and_next_task_without_reexecution(self):
        proof=self.completed_crash();self.acceptances['a']=proof
        self.assertEqual(self.ledger.observation('a')['state'],'WAITING_HUMAN')
        result=self.ledger.reconcile_completed('a');self.assertEqual(result,{'state':'DONE','duplicate':False,'execution_replayed':False})
        again=self.open().reconcile_completed('a');self.assertTrue(again['duplicate'])
        self.assertEqual(self.ledger.claim('next')['task_id'],'b')
        self.assertEqual(len(self.query("SELECT * FROM events WHERE task_id='a' AND event='EXECUTION_CLAIMED'")),1)
        self.assertEqual(len(self.query("SELECT * FROM events WHERE task_id='a' AND event='P3_ACCEPTED_RESULT'")),1)
        self.assertEqual(len(self.query("SELECT * FROM supervision_events WHERE task_id='a' AND kind='P3_ACCEPTED_RESULT'")),1)

    def test_completed_crash_bad_proof_cannot_grant_done(self):
        proof=self.completed_crash()
        bads=[{},dict(proof,authority_verified=False),dict(proof,terminal_receipt='wrong')]
        for key,value in [('current_fence',999),('run_id','other'),('epoch',1),('resume_generation',99)]:
            bad=copy.deepcopy(proof);bad['recovery'][key]=value;bads.append(bad)
        bad=copy.deepcopy(proof);bad['qa']['status']='FAIL';bads.append(bad)
        bad=copy.deepcopy(proof);bad.pop('recovery');bads.append(bad)
        for bad in bads:
            self.acceptances['a']=bad
            with self.assertRaises(ValueError):self.ledger.reconcile_completed('a')
        self.assertEqual(self.ledger.observation('a')['state'],'WAITING_HUMAN')
        self.assertEqual(self.query("SELECT * FROM events WHERE event='P3_ACCEPTED_RESULT'"),[])

    def test_completed_crash_outbox_failure_rolls_back_all_acceptance(self):
        self.acceptances['a']=self.completed_crash()
        original=self.supervisor._event
        def fail(*a,**kw):raise RuntimeError('fixture outbox crash')
        self.supervisor._event=fail
        try:
            with self.assertRaises(RuntimeError):self.ledger.reconcile_completed('a')
        finally:self.supervisor._event=original
        self.assertEqual(self.ledger.observation('a')['state'],'WAITING_HUMAN')
        self.assertEqual(self.query("SELECT * FROM events WHERE event='P3_ACCEPTED_RESULT'"),[])
        self.assertEqual(self.ledger.reconcile_completed('a')['state'],'DONE')

    def test_completed_recovery_cannot_replace_live_writer(self):
        c=self.ledger.claim('live');proof=self.proof(c)
        proof['recovery']={'current_fence':c['fence'],'run_id':'run-a','session_id':'session-a',
            'resume_generation':0,'epoch':0,'generation':0};self.acceptances['a']=proof
        with self.assertRaises(ValueError):self.ledger.reconcile_completed('a')
        self.assertEqual(self.ledger.observation('a')['state'],'RUNNING')

    def test_concurrent_completed_reconciliation_one_commit_one_duplicate(self):
        self.acceptances['a']=self.completed_crash();barrier=threading.Barrier(2)
        def recover():
            ledger=self.open();barrier.wait();return ledger.reconcile_completed('a')
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            a=pool.submit(recover);b=pool.submit(recover);results=[a.result(),b.result()]
        self.assertEqual(sorted(r['duplicate'] for r in results),[False,True])
        self.assertEqual(len(self.query("SELECT * FROM events WHERE task_id='a' AND event='P3_ACCEPTED_RESULT'")),1)
        self.assertEqual(len(self.query("SELECT * FROM supervision_events WHERE task_id='a' AND kind='P3_ACCEPTED_RESULT'")),1)

    def test_loop_automatically_reconciles_completed_exit_then_successor(self):
        self.acceptances['a']=self.completed_crash();fixture=self;called=[]
        class Pipeline:
            def run(self,c):called.append(c['task_id']);fixture.finish(c);return {'state':'DONE'}
        loop=P3ContinuousLoop(self.ledger,lambda c:Pipeline(),'p3',poll_seconds=.01);self.addCleanup(loop.close)
        deadline=time.monotonic()+2
        while time.monotonic()<deadline:
            loop.tick()
            if self.ledger.observation('b')['state']=='DONE':break
            time.sleep(.01)
        self.assertEqual(self.ledger.observation('b')['state'],'DONE')
        self.assertNotIn('a',called)

    def test_completed_missing_proof_holds_only_its_chain(self):
        self.completed_crash();fixture=self
        class Pipeline:
            def run(self,c):fixture.finish(c);return {'state':'DONE'}
        loop=P3ContinuousLoop(self.ledger,lambda c:Pipeline(),'p3',poll_seconds=.01);self.addCleanup(loop.close)
        deadline=time.monotonic()+2
        while time.monotonic()<deadline:
            loop.tick()
            if self.ledger.observation('independent')['state']=='DONE':break
            time.sleep(.01)
        self.assertEqual(self.ledger.observation('a')['state'],'WAITING_HUMAN')
        self.assertEqual(self.ledger.observation('b')['state'],'PENDING')
        self.assertEqual(self.ledger.observation('independent')['state'],'DONE')

    def test_completed_reader_outage_does_not_abort_other_claim(self):
        self.completed_crash()
        def unavailable(task_id):raise ConnectionError('fixture unavailable reader')
        self.ledger.acceptance_reader=unavailable
        result=self.ledger.recover_completions()
        self.assertEqual(result[0]['result']['state'],'HOLD_ACCEPTANCE_EVIDENCE_REQUIRED')
        self.assertEqual(self.ledger.claim('independent-writer')['task_id'],'independent')

    def test_original_loop_continues_without_owner_reply(self):
        fixture=self
        class Pipeline:
            def run(self,c):
                fixture.finish(c);return {'state':'DONE'}
        loop=P3ContinuousLoop(self.ledger,lambda c:Pipeline(),'p3',clock=time.monotonic,poll_seconds=.01)
        self.addCleanup(loop.close)
        deadline=time.monotonic()+3
        while time.monotonic()<deadline:
            loop.tick()
            if self.ledger.observation('b')['state']=='DONE':break
            time.sleep(.01)
        self.assertEqual(self.ledger.observation('b')['state'],'DONE')
        self.assertEqual(self.ledger.health()['state'],'HEALTHY')

    def test_continuous_two_real_local_commits_and_subprocess_tests(self):
        # Actual local git + interpreter effects; review/CI attestations below remain
        # explicitly synthetic. This is not UK/provider/business acceptance.
        work=Path(self.tmp.name)/'work';work.mkdir()
        def run(*args):return subprocess.run(args,cwd=work,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,universal_newlines=True).stdout
        run('git','init','-q');run('git','config','user.email','fixture@example.invalid');run('git','config','user.name','P3 fixture')
        (work/'value.py').write_text('VALUE=0\n');run('git','add','.');run('git','commit','-qm','fixture base')
        fixture=self;completed=[]
        class Pipeline:
            def run(self,c):
                if c['task_id']=='independent':
                    fixture.ledger.finish(c['task_id'],c['worker_id'],c['fence'],'WAITING_HUMAN');return {'state':'WAITING_HUMAN'}
                n=1 if c['task_id']=='a' else 2
                (work/'value.py').write_text('VALUE=%d\n'%n)
                result=run(sys.executable,'-c','from value import VALUE; assert VALUE==%d'%n)
                run('git','add','.');run('git','commit','-qm','task '+c['task_id'])
                commit=run('git','rev-parse','HEAD').strip();artifact=hashlib.sha256((work/'value.py').read_bytes()).hexdigest()
                fixture.ledger.checkpoint(c['task_id'],c['worker_id'],c['fence'],{'phase':'VERIFIED_LOCAL','commit':commit,'done_steps':[str(i) for i in range(1,n+1)]})
                proof=fixture.proof(c);proof['commit']=commit;proof['artifact_sha256']=artifact
                for role in ('tests','ci','qa','security','business'):
                    proof[role].update(commit=commit,artifact_sha256=artifact)
                fixture.acceptances[c['task_id']]=proof
                fixture.ledger.finish(c['task_id'],c['worker_id'],c['fence'],'DONE')
                completed.append(commit);return {'state':'DONE'}
        loop=P3ContinuousLoop(self.ledger,lambda c:Pipeline(),'local',max_workers=1,poll_seconds=.01)
        self.addCleanup(loop.close);deadline=time.monotonic()+5
        while time.monotonic()<deadline:
            loop.tick()
            if self.ledger.observation('b')['state']=='DONE':break
            time.sleep(.01)
        self.assertEqual(self.ledger.observation('b')['state'],'DONE')
        self.assertEqual(len(set(completed)),2)
        self.assertEqual(run('git','rev-list','--count','HEAD').strip(),'3')
        self.assertEqual(self.open().observation('b')['checkpoint']['done_steps'],['1','2'])

if __name__=='__main__':unittest.main()
