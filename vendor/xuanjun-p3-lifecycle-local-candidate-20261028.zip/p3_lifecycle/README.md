# P3 lifecycle overlay — local code candidate, not field acceptance

## Result

New `candidate/stage1/p3_lifecycle.py` extends the **original** ExecutionLedger and
DevelopmentLoop; it uses original tasks/execution_specs/approvals/events,
ExecutionSupervisor (through the P3Supervisor subclass) and supervision_delivery. No new database, queue, service,
worker launcher, credentials, installation or model channel is supplied. P2 source
and its seven installation batches are unchanged. Default `p3_admitted=False`.

48 targeted tests PASS on Python 3.12.14 and exact locally available Python 3.6.8.
One test actually creates two successive local Git commits and executes Python
subprocess assertions through the original loop and a temporary original-schema
SQLite database. CI, independent QA/security and business acceptance attestations
in these tests are **synthetic fixtures**. This is not real provider/UK/production
P3 acceptance, not hosted CI, and not independent review of this candidate.

## Verified source / ownership

Repository: huhongchuan0422-creator/Repository-name-xuanjun-ai-control.
PR17 observed HEAD: `210d35dd003f3f345b4c6a2616aeada8c3e4db31`, draft/open.
Runtime source branch: `repair/p2-resumable-install-20261020`, observed HEAD
`0469483d6bb82dbe89f000976572307eeb8eed7e`.
Original runtime path: `evidence/p2-epoch7-access-repair-20261014/runtime/stage1/`.
Exact reference bytes and Git blobs are included; see source-anchors and SHA256SUMS.
The root stage1 directory of the repair branch is absent; it was not fabricated.

Historical contract: `plans/WORK_STAGED_EXECUTION_CONTRACT_20261011.json`
at `8ccd4d08a1fae7afdf65d5a376a6c3960ba0c8a7`, verified SHA256
`055d3ad1f41a3f8b64f8096e1f1e115b9cb07cc9e1669ab1be0963c47f43ee33`.
PR17 comments 6281242944 / 6281273351 establish P3-only boundary; 6458014611
contains the five current acceptance requirements. Their exact texts are included.
Document-only ec6693487e390f953821972cc521a9d8bcbf6b61 is NOT a runtime baseline.

Author: root-assigned sole P3 candidate author build_saas_ecosystem_framework.
No other live P3 writer was known to root at assignment. Remote working-tree /
inflight native-writer state is UNKNOWN, not inferred from Git HEAD. Workspace
root is not a Git checkout. Only this candidate directory is authored; SaaS Writer
was transferred to another agent and was not resumed. No GitHub push/Actions,
server, cloud commands, Work/Codex wake, community or P2 edits were performed.

## Five requirements mapped to implementation

1. **Continue without Owner reply:** original `DevelopmentLoop.tick/serve` is
   reused. The new loop scans watchdog then executes original bounded scheduling.
   A report/ACK is never DONE. Persistent completion unblocks the next original
   dependency without waiting for a chat reply. Original max 2 heavy jobs stays;
   no increase to the overall seven-role cap.
2. **Verified resume:** pinned task/spec; real progress event dedupe; unchanged
   checkpoints and counters. Expired uncertain tasks fence/HOLD, never fresh
   retry. `reconcile_stopped` requires trusted stop/descendant/effect proof bound
   to old fence, current checkpoint and epoch. `resume_human` additionally requires
   ORIGINAL approval, preserves checkpoint and budget, and calls original
   supervisor `reconcile`. Existing native attempts are deliberately excluded
   from fresh `claim`: only original `resume_dispatch`/`validate_launch` may
   admit their next native generation. No unavailable native API is invented.
3. **Independent blocker isolation:** only explicitly pinned P3 task IDs can be
   claimed/recovered/mutated. Failed/unknown chain remains HOLD, independent
   READY work progresses. Unresolved old processes still consume capacity;
   clearing a visible task state cannot conceal resource use or duplicate a writer.
4. **Watchdog:** only trusted SOURCE_COMMIT/TEST_RUN/ARTIFACT receipts count,
   once per immutable evidence identity; heartbeat/report/ACK do not. Persisted
   completed-pass events provide supervisor liveness; incomplete/stale passes
   report SUPERVISOR_STALLED. Tasks still have a separate real-progress timeout.
   Host service restart remains the ORIGINAL host's responsibility, not this
   Python object pretending it can restart itself after process death.
5. **Acceptance before successor:** DONE requires bound STARTED, same task/spec/
   fence/checkpoint plus commit/artifact-bound tests, CI, distinct author/QA/
   security and business evidence from a trusted reader. Accepted result,
   supervised terminal receipt, original notification outbox and DONE commit
   atomically; an outbox insertion failure rolls everything back. Lost delivery
   does not erase DONE or repeat the task. Original outbox send/reconcile/ACK
   protocol remains in ExecutionSupervisor; this candidate never sends externally.

## Assembly / integration contract (not performed on a server)

- Add ONLY `candidate/stage1/p3_lifecycle.py` alongside the exact original runtime
  files listed in `reference/runtime/stage1`. Do not replace P2 core files or
  point it at a new ledger. Verify every SHA and actual native writer first.
- Existing admitted host composition supplies the original active ExecutionLedger
  DB path/ActivationStore and repository whitelist. Construct P3Supervisor over
  the SAME DB/generation with identical task_spec_pins, max_heavy and explicit
  host admission; this subclasses original ExecutionSupervisor without replacing
  P2 core source. P3Ledger rejects an unguarded supervisor or mismatched limits. No database bootstrap is supported.
- After P2 actual acceptance plus explicit P3 release admission, host can compose
  `P3Ledger(..., task_spec_pins={existing_task: exact_spec_sha}, supervisor=existing,
  progress_reader=trusted_reader, acceptance_reader=trusted_reader,
  stop_reader=trusted_reader, p3_admitted=True)` and replace ONLY its P3 loop
  instance with `P3ContinuousLoop(p3_ledger, existing_pipeline_factory, prefix)`.
  This is a Python host API, not an HTTP/user-body authorization flag. The host
  must authenticate/resolve authority before setting it. Do not admit P2 task IDs.
- Readers must independently retrieve/verify receipts; boolean fields in fixture
  dicts are not field evidence or signatures. Never expose these callbacks or
  `p3_admitted` to submitted task bodies. Their absence fails closed.
- Original approved pipeline persists canonical checkpoint and bound native
  STARTED via original supervisor; it invokes `ledger.progress` for independently
  verified output, and `ledger.finish(...,'DONE')` only after trusted acceptance.
- On takeover: original Owner decision -> verified stopped/effects receipt ->
  `reconcile_stopped` -> original `owner_decision(APPROVE)` (already PENDING) ->
  `resume_human` (no extra fence/state transition) -> original supervisor reports RESUMABLE.
  Original admitted native provider must then call `P3Supervisor.resume_dispatch`,
  which checks capacity inside the SAME original BEGIN IMMEDIATE transaction,
  revalidate with `validate_launch`, obtain real ACK/STARTED and continue the
  preserved checkpoint. The generic loop cannot turn RESUMABLE into a fresh run.
- Supervisor monitoring uses `health()` from the existing independently running
  host supervisor/timer. Self-loss cannot be observed by a dead Python process.

Rollback: stop only the P3 loop through original stop/lease/cgroup controls;
prove workers/descendants stopped and reconcile unknown effects before any
replacement. Remove/revert this one additive module and its P3 composition hook.
Do NOT delete/reset original tasks, checkpoints, events, outbox, approvals,
fences or ledger/WAL. No automatic rollback, install or DB migration is shipped.

## Exact external gaps / pending field work

- Original `mechanical_wake_service.InstalledAdapter` still returns native
  resume/takeover UNAVAILABLE; neither ordinary chat wake nor real provider
  STARTED is verified. Need exact original approved launch/resume/inspect/stop
  binding, real available WRITE/WAKE/quota-pool evidence. UNKNOWN is not exhausted.
- Real P2 acceptance and explicit P3 host composition/release admission are
  pending; no field configuration/installation was attempted or authorized here.
- Real trusted progress/stop/CI/QA/security/business evidence readers and outer
  service watchdog must be bound to the host identities. This candidate defines
  and tests consumption, not a made-up remote signer or permission grant.
- Two real provider tasks, actual CI, independent review, notification-loss/
  restart/UNKNOWN fault injections, authenticated dashboard and business outcome
  remain pending field acceptance. Local fixture passes do not close these gates.

## Run only the new local tests

```
PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s local-candidate/p3_lifecycle/tests -v
```

Tests use temporary directories only; no external network or server is started.
Reference runtime bytes are unchanged. `candidate.diff` is the single additive
module overlay. No old P2 suite was rerun or credited to this candidate.

## Independent-review repair revision

The first 22-test freeze was rejected by independent review and is superseded.
The original-API compatibility regressions are now explicit:
- original owner_decision consumes registered request/replay and changes PENDING;
  no direct SQL approval shortcut is used for the positive resume test;
- resume_dispatch -> validate_launch -> accept_started supplies a single current-
  fence STARTED grace origin; heartbeats still cannot extend progress deadlines;
- first-task spec drift does not stop the complete loop or its health pulse;
- resume and ordinary claim share serialized capacity admission, including a
  two-connection race for one remaining heavy slot; no third heavy task;
- public ledger.checkpoint after STARTED uses original advance_checkpoint CAS
  with live-lease guard, preserving both canonical and supervision copies;
  original DevelopmentLoop._blocked follows this same synchronized path;
- verified stop/effect evidence is atomically recorded with the original
  supervised effect classification. UNKNOWN is not cleared by bare booleans,
  an invalid reader proof or mismatched task/fence/checkpoint/epoch.

48 tests pass on both interpreters; independent re-review remains pending until
its separate reviewer returns a verdict bound to this revision. Field gaps above
are unchanged. Do not install or deliver the superseded 22-test ZIP.

Async re-review corrections: current-generation RESUMED_DISPATCH has only a
bounded wait through original start_deadline before ACK/STARTED; it is not
counted as real progress, and a missing ACK times out to fenced HOLD. A delayed
resume reconciliation retries with expected fence/run/session/checkpoint/resume
generation rechecked inside the SAME original supervisor transaction; it cannot
overwrite a concurrently STARTED new generation. Both interleavings are tests.

Unacknowledged-resume recovery is also exercised end to end: exact current
RESUMED_DISPATCH identity + independently verified stopped/effects receipt may
restore the known admitted writer fence/epoch for original reconciliation,
without creating STARTED evidence (started_at/start_receipt remain NULL;
native_state STOPPED, explicit UNSTARTED_STOP_RECONCILED event). Old run/session/
resume_generation proofs are rejected; next original admission preserves budget
and checkpoint and requires a new real STARTED receipt.

First/resumed dispatch share the same ACK-loss matrix. P3Supervisor adds an
initial lease/spec/checkpoint admission event in the SAME original dispatch
transaction; it does not mark STARTED. Both generations enforce start_deadline.
An original observe() changing an unstarted run to STALLED/RESULT_MISSING/HOLD
does not discard its exact admission or prevent trusted stop reconciliation.
A previously observed COMPLETED receipt can be accepted only with bound STARTED,
matching terminal receipt/effects and full independent acceptance evidence; a
stop proof cannot overwrite an already completed result.

Completion-after-exit is implemented, not deferred to an external adapter:
`reconcile_completed(task_id)` requires the trusted acceptance reader to return
full ordinary acceptance plus `recovery={current_fence,run_id,session_id,
resume_generation,epoch,generation}`. Inside the pinned original DB transaction
it checks exact current fenced lineage, original bound STARTED and durable
COMPLETED terminal/effects, checkpoint/spec and independent acceptance. It
atomically records acceptance, original outbox, stopped-capacity reconciliation
and DONE; duplicate calls read back the same result, not reexecute the task.
The original loop invokes bounded per-task completion recovery each tick after
watchdog recovery, so verified completed work can unblock its successor without
an Owner reply. Missing/unavailable/invalid proof leaves only that chain HOLD.
Real-original-API crash/reopen, two-connection races, wrong proof, live-writer
rejection, outbox rollback and automatic next-task tests are included.
