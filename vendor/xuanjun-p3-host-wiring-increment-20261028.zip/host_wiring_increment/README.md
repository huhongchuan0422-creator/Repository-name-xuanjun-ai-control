# P3 original-host composition entry — LOCAL, DEFAULT OFF

Additive constructor/event entrypoints, not another daemon, ledger, transport,
permission grant or live installation. It uses the frozen P3Ledger and
ReminderIntegratedLoop. Prior P348 / reminder52+18 acceptance is reused, not rerun.
This increment has only isolated composition tests and no simulated SENT/ACK.
The timeout fixture never contacts a provider or reports successful delivery.

## Original-source evidence

- P3 candidate/stage1/p3_lifecycle.py:163 constructor/308 progress/660 loop.
- reminder_increment/p3_owner_reminders.py:80 ingest/393 same-ledger hook.
- reference/runtime/stage1/mechanical_wake_service.py:20 InstalledAdapter,
  46 plain ExecutionLedger, 61–64 RelayController owner_cycle call (line offsets
  refer to frozen files; inspect source-sha256.json for exact pinned bytes).
- Historical reviews/integration-11786072168/xuanjun-p2-package/stage1/
  native_gateway_controller.py:98 RelayController, 142–151 method set lacks
  owner_cycle. That reviewed historical package is not a current-host attestation.
- Same historical package owner_notification_outbox.py only has TELEGRAM
  task/fence PENDING/ACKED, not P3 exact request/attempt/binding UNKNOWN semantics.
- MCP task_supervisor has a different schema, and target_record_increment is
  historical registry metadata, not a P3 execution source or permission.

## Exact assembly (host code, NOT request data)

Place this module beside the original host Python imports after verifying pins.
Replace the ONE existing loop-construction expression with
`compose_existing_host(existing_p3_ledger, original_pipeline_factory, config,
admission_reader, executor=original_host_executor, event_reader=trusted_reader,
eligibility_reader=trusted_eligibility, adapter=authorized_existing_provider)`.
Do not retain the old loop in parallel. This function does not open/create a DB,
spawn a process/thread pool, run a tick or call route/send. It requires the
original host executor; loop.close retains original executor shutdown semantics.
The host's normal stop/close/restart path remains responsible for leases/cgroups.
Do not create a fresh P3Ledger merely to bypass already-composed detection.

`validate_config` exact keys: execution_enabled(bool), notifications_enabled(bool),
task_to_blocker(existing admitted task IDs -> fixed blocker IDs),
ratio_bands(original integer-percent schema), worker_prefix(original host prefix).
Both flags must remain false until real admission. Disabled compose returns None
and writes nothing. The mapping and ratio still persist through original reminder
configuration pinning on actual admitted scans. No live example identity is
invented; the host supplies the existing values.

Trusted admission_reader returns EXACT keys:
`p2_accepted,p3_release_accepted,unique_writer,db_path,activation_binding,
task_spec_pins,notification_authorized,verified,valid_from,valid_until`.
All three gates and verified must be True; DB real path, activation binding and
spec pins must exactly match the existing P3Ledger. notification_authorized is
independently required for notification enablement. The host reader MUST resolve
actual original admission/activation/unique-Writer authority, not return config
booleans or test fixtures. Missing/UNKNOWN raises before composition/tick/event.
The guard is rechecked before every tick and event, plus directly before provider
route/send. It does not terminate already-running workers on revocation: the
original host supervisor must stop/reconcile them with original fence protocols.
The process-local locked DB-path duplicate-construction guard (retained until
process exit, including after close) is additional protection, not a
replacement for the original durable unique-Writer authority.

Returned loop entrypoints:
- tick(): original P3 execution first, then original reminder scan/send.
- confirmation_event(evidence_ref): exact original ingest; no fabricated callback.
- verified_progress(task,worker,fence,evidence_ref): original evidence-bound API.
- reconcile_notification(event_key, trusted_lookup): original bound-attempt lookup.
The source callbacks and lookup are trusted host dependencies, never user/request
callbacks. Telephone answer/provider ACK is NOT approval.

Real notification adapter is NOT supplied: it must implement the reviewed
route/send protocol and bounded I/O. Lookup is the reviewed binding+opaque ID+
attempt nonce contract. Existing real single-send UNKNOWN must be reconciled
against its exact original attempt before any repeat; this constructor neither
imports an unrelated receipt nor retries on startup. It does not call old
RelayController.owner_cycle or silently map TELEGRAM ACK to a phone receipt.

## Remaining field dependencies and rollback

Original P2 acceptance, P3 release admission, exact active host source/activation,
unique Writer proof, verified progress/confirmation source, authorized phone /
fallback provider and exact lookup are PENDING/UNKNOWN externally. The old relay
source-generation mismatch needs actual active-host blob evidence, not a new
channel. Without those dependencies compose fails closed, not falsely installed.

Rollback reverts only the original host construction hook/module using its
existing stop path. Never delete deadlines/events/UNKNOWN attempts/checkpoints or
ledger/WAL; never dial as a rollback action. No migration, service install,
permission change, endpoint creation or real call is included.

## Independent review fixes in this successor only

Enablement requires the ORIGINAL ActivationStore type, nonempty complete binding,
actual protected descriptor+journal read with state ACTIVE, exact original
supervisor binding/store, and original ledger activation check. Admission time
must be finite and valid_from <= original ledger clock < valid_until. None==None
is never activation proof. At composition the immutable serialized snapshot pins
DB path/device/inode, activation descriptor head and identity, original store
paths/owner, and task/spec pins; later ledger+reader synchronized drift is refused.
Tests use real original ActivationStore APIs against isolated temporary protected
files; no actual host activation is created or changed.

The provider wrapper records an exact pre-invocation denial (opaque notification
ID + attempt nonce). If original send_one conservatively marks SENDING_UNCERTAIN,
the successor reports NOT_SENT_ADMISSION_REVOKED_HOLD with BOTH attempted flags
false, and persists P3_HOST_PROVIDER_NOT_INVOKED when original activation still
allows an audit transaction. If activation is revoked, no audit write bypass is
attempted. Conservative outbox uncertainty is retained: this is NOT automatic
retry authorization or a forged external NOT_SENT receipt. Actual provider call
followed by timeout still reports UNKNOWN_NO_REDIAL / attempted true. The send
wrapper is serialized; denial evidence cannot leak across concurrent attempts.

source-sha256.json checks delivery/reference bytes only, NOT runtime imported
module provenance. The original host deployment/admission authority must verify
actual loaded modules; matching dictionaries do not prove correct code loading.
