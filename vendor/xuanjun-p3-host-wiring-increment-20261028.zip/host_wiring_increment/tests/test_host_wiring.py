import pathlib,sys,unittest,os,concurrent.futures,uuid,copy
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'host_wiring_increment'),str(ROOT/'reminder_increment'),str(ROOT/'tests')]
import test_p3_lifecycle as baseline
from p3_host_wiring import compose_existing_host,validate_config
from activation_control import ActivationStore
from p3_lifecycle import P3Ledger,P3Supervisor

class Executor:
    def __init__(self):self.submitted=0
    def submit(self,*a,**k):self.submitted+=1;return concurrent.futures.Future()
    def shutdown(self,**kw):pass

class Pipeline:
    def run(self,claim):raise AssertionError('fixture executor never executes work')

class TimeoutProvider:
    def __init__(self):self.calls=0
    def route(self):return dict(route='PHONE',provider_binding='a'*64,destination_binding='b'*64,verified=True)
    def send(self,*args):self.calls+=1;raise TimeoutError('fixture unknown; never SENT/ACK')

class Tests(unittest.TestCase):
    def setUp(self):
        self.f=baseline.Fixture();self.f.setUp();self.addCleanup(self.f.doCleanups);self.executor=Executor();self.events={}
        root=pathlib.Path(self.f.tmp.name)
        self.store=ActivationStore(str(root/'active.json'),str(root/'epochs.jsonl'),str(root/'activation.lock'),owner_uid=os.getuid())
        active=self.store.prepare('a'*64,'b'*64,'c'*64,str(uuid.uuid4()),1,str(uuid.uuid4()),self.f.path,str(root/'ledger.sock'))
        self.store.transition('PREPARED','QUIESCED',active['epoch'],active['instance'],dict(identity_verified=True,coordinator_inactive=True,parent_unit_inactive=True,cgroups_empty=True,restart_inhibited=True))
        self.store.transition('QUIESCED','ACTIVE',active['epoch'],active['instance'],dict(database_reopened=True))
        self.f.supervisor=P3Supervisor(self.f.path,self.f.clock,task_spec_pins=self.f.pins,p3_admitted=True,activation_store=self.store)
        self.f.ledger=self.active_ledger()
        self.config=dict(execution_enabled=False,notifications_enabled=False,task_to_blocker={k:'block' for k in self.f.pins},ratio_bands=[(2,100),(5,60),(10,40),(None,30)],worker_prefix='original-host')
        self.proof=dict(p2_accepted=True,p3_release_accepted=True,unique_writer=True,db_path=os.path.realpath(self.f.path),activation_binding=self.f.ledger.activation_binding,task_spec_pins=self.f.pins,notification_authorized=False,verified=True,valid_from=900,valid_until=10000)
    def active_ledger(self):
        return P3Ledger(self.f.path,[baseline.REPO],clock=self.f.clock,task_spec_pins=self.f.pins,progress_reader=self.f.progress_proofs.get,
            acceptance_reader=self.f.acceptances.get,stop_reader=self.f.stops.get,supervisor=self.f.supervisor,p3_admitted=True,activation_store=self.store)
    def build(self,**kw):
        return compose_existing_host(self.f.ledger,lambda c:Pipeline(),self.config,admission_reader=lambda:self.proof,executor=self.executor,event_reader=self.events.get,**kw)
    def test_default_off_constructs_no_loop_or_db_writes(self):
        before=self.f.query('SELECT * FROM events');self.assertIsNone(self.build());self.assertEqual(before,self.f.query('SELECT * FROM events'));self.assertEqual(self.executor.submitted,0)
    def test_wrong_schema_and_enable_type_rejected(self):
        with self.assertRaises(TypeError):compose_existing_host(object(),None,self.config)
        self.config['execution_enabled']='true'
        with self.assertRaises(ValueError):self.build()
    def test_exact_host_gates_required(self):
        self.config['execution_enabled']=True
        for key,value in [('p2_accepted',False),('p3_release_accepted',False),('unique_writer',False),('verified',False),('db_path','/other.db'),('activation_binding',{'wrong':True}),('task_spec_pins',{})]:
            original=self.proof[key];self.proof[key]=value
            with self.assertRaises(PermissionError):self.build()
            self.proof[key]=original
    def test_same_ledger_existing_executor_single_composition(self):
        self.config['execution_enabled']=True;loop=self.build();self.addCleanup(loop.close)
        self.assertIs(loop.ledger,self.f.ledger);self.assertIs(loop.pool,self.executor);self.assertIs(loop.reminders.ledger,self.f.ledger)
        with self.assertRaises(ValueError):self.build()
        loop.tick();self.assertGreater(self.executor.submitted,0)
    def test_gate_rechecked_before_tick_and_event(self):
        self.config['execution_enabled']=True;loop=self.build();self.addCleanup(loop.close);self.proof['unique_writer']=False
        with self.assertRaises(PermissionError):loop.tick()
        with self.assertRaises(PermissionError):loop.serve()
        with self.assertRaises(PermissionError):loop.confirmation_event('event')
        self.assertEqual(self.executor.submitted,0)
    def test_notification_requires_source_provider_and_distinct_permission(self):
        self.config.update(execution_enabled=True,notifications_enabled=True)
        with self.assertRaises(PermissionError):self.build()
        self.proof['notification_authorized']=True
        with self.assertRaises(ValueError):self.build()
    def test_confirmation_deadline_and_unknown_no_redial_through_host(self):
        self.config.update(execution_enabled=True,notifications_enabled=True);self.proof['notification_authorized']=True;provider=TimeoutProvider()
        loop=self.build(adapter=provider);self.addCleanup(loop.close)
        self.events['created']=dict(kind='confirmation_created',event_id='created',request_id='request',task_id='a',blocker_id='block',occurred_at=self.f.clock(),verified=True)
        loop.confirmation_event('created');self.f.clock.now+=300;result=loop.tick()
        self.assertEqual(result['owner_reminder']['delivery']['state'],'UNKNOWN_NO_REDIAL');self.assertEqual(provider.calls,1)
        self.f.clock.now+=300;loop.tick();self.assertEqual(provider.calls,1)
        self.assertEqual(self.f.query("SELECT * FROM approvals WHERE decision='APPROVE'"),[])
    def test_provider_permission_rechecked_after_route_before_send(self):
        self.config.update(execution_enabled=True,notifications_enabled=True);self.proof['notification_authorized']=True
        provider=TimeoutProvider();route=provider.route
        def revoke():
            binding=route();self.proof['notification_authorized']=False;return binding
        provider.route=revoke;loop=self.build(adapter=provider);self.addCleanup(loop.close)
        self.events['created']=dict(kind='confirmation_created',event_id='created',request_id='request',task_id='a',blocker_id='block',occurred_at=self.f.clock(),verified=True)
        loop.confirmation_event('created');self.f.clock.now+=300;result=loop.tick()['owner_reminder']['delivery'];self.assertEqual(provider.calls,0)
        self.assertEqual(result['state'],'NOT_SENT_ADMISSION_REVOKED_HOLD');self.assertFalse(result['dial_attempted']);self.assertFalse(result['external_delivery_attempted'])
        self.assertTrue(result['not_invoked_evidence_persisted'])
    def test_same_db_second_ledger_is_not_second_host_loop(self):
        self.config['execution_enabled']=True;loop=self.build();self.addCleanup(loop.close)
        second=self.active_ledger()
        with self.assertRaises(ValueError):compose_existing_host(second,lambda c:Pipeline(),self.config,admission_reader=lambda:self.proof,executor=self.executor)

    def test_missing_activation_and_expired_admission_rejected(self):
        self.config['execution_enabled']=True;old=self.f.ledger.activation_store;self.f.ledger.activation_store=None
        with self.assertRaises(PermissionError):self.build()
        self.f.ledger.activation_store=old;self.proof['valid_until']=1000
        with self.assertRaises(PermissionError):self.build()
    def test_real_activation_fence_revocation_rejected(self):
        self.config['execution_enabled']=True;loop=self.build();self.addCleanup(loop.close)
        active=self.store.read(require_active=True);self.store.fence(active['epoch'],active['instance'])
        with self.assertRaises(Exception):loop.tick()
        self.assertEqual(self.executor.submitted,0)
    def test_synchronized_mutable_ledger_and_reader_scope_drift_rejected(self):
        self.config['execution_enabled']=True;loop=self.build();self.addCleanup(loop.close)
        self.f.ledger.p3_pins=dict(self.f.pins,a='e'*64);self.f.supervisor.p3_pins=dict(self.f.ledger.p3_pins);self.proof['task_spec_pins']=dict(self.f.ledger.p3_pins)
        with self.assertRaises(PermissionError):loop.tick()
        self.assertEqual(self.executor.submitted,0)

    def test_real_progress_requires_original_reader_proof(self):
        self.config['execution_enabled']=True;loop=self.build();self.addCleanup(loop.close);claim=self.f.ledger.claim('w')
        with self.assertRaises(ValueError):loop.verified_progress(claim['task_id'],'w',claim['fence'],'missing')
        self.assertEqual(self.f.query("SELECT * FROM events WHERE event='P3_REAL_PROGRESS'"),[])

if __name__=='__main__':unittest.main()
