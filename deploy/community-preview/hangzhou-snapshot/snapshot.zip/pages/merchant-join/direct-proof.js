'use strict';
const {ACTION}=require('./direct-ocr');
// Portable SHA-256 over exact original ArrayBuffer. No WebCrypto, Node, or I/O.
const K=new Uint32Array([0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]);
const r=(v,n)=>(v>>>n)|(v<<(32-n));
function sha256(original){
 if(!(original instanceof ArrayBuffer)||original.byteLength>10_000_000)throw Error('DIRECT_OCR_INPUT_INVALID');
 const bytes=new Uint8Array(original),length=bytes.length,total=(length+72)&~63;
 const h=new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);
 const w=new Uint32Array(64);
 function octet(i){return i<length?bytes[i]:i===length?0x80:i>=total-4?(length*8)>>>((total-1-i)*8)&255:0;}
 for(let offset=0;offset<total;offset+=64){
  for(let j=0;j<16;j++){const i=offset+j*4;w[j]=(octet(i)<<24)|(octet(i+1)<<16)|(octet(i+2)<<8)|octet(i+3);}
  for(let j=16;j<64;j++){
   const a=w[j-15],b=w[j-2];w[j]=w[j-16]+(r(a,7)^r(a,18)^(a>>>3))+w[j-7]+(r(b,17)^r(b,19)^(b>>>10));
  }
  let [a,b,c,d,e,f,g,z]=h;
  for(let j=0;j<64;j++){
   const t=(z+(r(e,6)^r(e,11)^r(e,25))+((e&f)^(~e&g))+K[j]+w[j])|0;
   const u=((r(a,2)^r(a,13)^r(a,22))+((a&b)^(a&c)^(b&c)))|0;
   z=g;g=f;f=e;e=(d+t)|0;d=c;c=b;b=a;a=(t+u)|0;
  }
  h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;h[5]+=f;h[6]+=g;h[7]+=z;
 }
 return Array.from(h,v=>('00000000'+v.toString(16)).slice(-8)).join('');
}
let serial=0;
const intent=()=> 'mini-ocr-direct-'+Date.now().toString(36)+'-'+(++serial).toString(36)+'-'+Math.random().toString(36).slice(2);
function directProof(request,application,revision){
 if(typeof request!=='function'||typeof application!=='string'||!application||
    !Number.isSafeInteger(revision)||revision<0)throw Error('DIRECT_OCR_BINDING_INVALID');
 const intent_key=intent();
 let taken=false;
 return {sha256,async signDigest({kind,digest,size}){
  if(taken||!Object.prototype.hasOwnProperty.call(ACTION,kind)||
     typeof digest!=='string'||!/^[0-9a-f]{64}$/.test(digest)||!Number.isSafeInteger(size)||size<1||size>10_000_000)
   throw Error('DIRECT_OCR_BINDING_INVALID');
  taken=true;
  const result=await request('direct_ocr_sign',{application,revision,kind,digest,size,intent_key});
  if(!result||Object.keys(result).join(',')!=='headers'||!result.headers||typeof result.headers!=='object'||Array.isArray(result.headers))
   throw Error('DIRECT_OCR_PROOF_UNAVAILABLE');
  return result.headers;
 }};
}
module.exports={sha256,directProof};
