const {makeClient} = require('../../client');
const {createPaymentFlow}=require('../../payment');
const {parseScene,getSharedSession,customerError} = require('../../session');
const auth=require('../../customer-auth');
// Purpose-made non-sensitive local artwork only; root must bind this exact bundled asset.
const DEMO_PHOTO_ASSET='/assets/community-demo-storefront-v1.jpg';
const yuanAmount=minor=>Number.isSafeInteger(minor)?(minor/100).toFixed(2):'—';
const minorAmount=value=>{if(typeof value!=='string'||!/^\d+(?:\.\d{1,2})?$/.test(value))return null;const [whole,fraction='']=value.split('.'),minor=Number(whole)*100+Number((fraction+'00').slice(0,2));return Number.isSafeInteger(minor)&&minor>0?minor:null;};
const LOCAL_CATEGORIES=[
  {id:'local:dining',name:'餐饮',keywords:['餐饮','美食','餐厅','饭店','小吃','饮品','咖啡']},
  {id:'local:grocery',name:'副食',keywords:['副食','便利','超市','粮油','食品']},
  {id:'local:fresh',name:'生鲜',keywords:['生鲜','水果','蔬菜','肉','蛋','水产']},
  {id:'local:service',name:'生活服务',keywords:['生活服务','家政','维修','洗衣','美容','理发']},
  {id:'local:health',name:'健康',keywords:['健康','药店','医疗','健身','养生']}
];
const ORDER_STATE_LABELS={CREATED:'待付款',PENDING:'待付款',SUCCESS:'待发货',PAID:'待发货',FULFILLING:'待发货',SHIPPED:'已发货',COMPLETED:'已完成',CANCELLED:'已取消',FAILED:'付款失败',REFUNDED:'已退款',REFUNDING:'退款中',AFTER_SALE:'售后中'};
const orderStateLabel=state=>ORDER_STATE_LABELS[state]||'处理中';
const displayOrder=(record,filter='all')=>{const state=record.order.state;return {...record,visible:filter==='all',order:{...record.order,state_label:orderStateLabel(state),amount_yuan:yuanAmount(record.order.amount_minor)}};};
Page({
  openMerchantJoin(){return auth.navigate(this,'join',wx,getApp(),typeof getCurrentPages==='function'?getCurrentPages():[]);},
  scanStore(){return auth.scanStore(this,wx,getApp(),typeof getCurrentPages==='function'?getCurrentPages():[]);},
  goBack(){return auth.back(this,wx,getApp(),typeof getCurrentPages==='function'?getCurrentPages():[]);},
  data: {nativeCollectionEntry:false,sceneStorefront:null,demoStore:null,demoImagePath:DEMO_PHOTO_ASSET,demoPhotoFailed:false,demoState:'UNKNOWN',directory:[],categories:LOCAL_CATEGORIES,categoryId:'',visibleDirectoryCount:0,directoryState:'NOT_QUERIED',directoryError:'',directoryMore:false,directoryCursor:null,contexts:[],contextsState:'NOT_QUERIED',contextsError:'',ordersState:'NOT_QUERIED',ordersError:'',detailState:'NOT_QUERIED',detailError:'',serviceView:'home',serviceTitles:{home:'更多门店服务',community:'我的社区','community-list':'发现社区','community-detail':'社区详情','community-code':'通过推广码加入',referral:'推荐关系',products:'门店商品与服务',checkout:'核对订单',payment:'支付与订单恢复',refund:'申请售后','refund-detail':'售后进度','legacy-profile':'个人资料','legacy-notices':'我的通知'},selectedCommunity:null,communityRelation:null,orderFilter:'all',visibleOrderCount:0,needsScene:true,viewMode:'recommendations',activeSection:'recommendations',sessionReady:false,detailsCollapsed:false,selectedRecommendation:null,communities:[],communityCursor:null,communitiesMore:false,communityId:'',promotionCode:'',amount:'', reference:'', merchant:'', beforeAd:'',beforeAdImage:'', afterAd:'',afterAdImage:'',afterAdVerified:false, status:'', pending:false,paymentsEnabled:false,commerceEnabled:false,profileVersion:null,nickname:'',profileContact:'',ownReferralCode:'',referralCode:'',projectCustomerId:'',userId:'',notices:[],noticeCursor:null,noticesMore:false,noticesLoaded:false,noticePending:false,noticeStatus:'',products:[],productCursor:null,productsMore:false,productsPending:false,productsStatus:'',orders:[],orderCursor:null,ordersMore:false,orderDetails:null,orderDetailsPending:false,orderDetailsStatus:'',refundCurrent:null,refundRecoveryLoaded:false,refundRecoveryPending:false,refundRecoveryStatus:'',refundApplication:"",refundAmount:"",refundReason:"",projectTitle:"",projectRole:"",projectChecklist:[],projectMessages:[],projectMessagesCursor:null,projectMessagesMore:false,projectMessagesLoaded:false,projectMessagesStatus:'',projectFeedback:"",projectReference:"",projectReferenceKind:"SECRETREF",projectReferenceItem:"",projectReferenceRevision:0,projectState:""},
  openMerchant(){return auth.navigate(this,'merchant',wx,getApp(),typeof getCurrentPages==='function'?getCurrentPages():[]);},
  navigateSection(e){return auth.navigate(this,e.currentTarget.dataset.section,wx,getApp(),typeof getCurrentPages==='function'?getCurrentPages():[]);},
  onShow(){const activeScene=getApp().globalData.scene;if(this.scene&&activeScene&&this.scene!==activeScene&&!this._sceneStale){this._sceneStale=true;this.customerSessionRevoked('授权场景已切换，当前订单和客户资料已清除，请重新进入对应门店',false);return;}if(this._sceneStale)return;const mode=getApp().globalData.checkoutMode;getApp().globalData.checkoutMode='';const view=mode||this.data.viewMode||'recommendations';const selectedRecommendation=view==='store-detail'?this.data.selectedRecommendation:null;this.setData({viewMode:view,activeSection:view==='orders'?'orders':view==='services'||view==='profile'?'profile':'recommendations',selectedRecommendation,sceneStorefront:view==='store-detail'?this.data.sceneStorefront:null});if((mode||this.data.demoStore)&&this.data.sessionReady){if(view==='recommendations')this.loadDirectory();else if(view==='orders')this.loadOrders();else if(view==='services'&&!this.scene)this.loadContexts();}if(!mode&&this.data.sessionReady&&this.data.selectedRecommendation&&this.data.selectedRecommendation.is_demo)this.openRecommendation({currentTarget:{dataset:{id:this.data.selectedRecommendation.id}}});if(this.session&&typeof this.session.isAuthenticated==='function'&&!this.session.isAuthenticated()&&!this.data.pending&&!this._sceneStale){this.onLoad({scene:this.scene,view:this.data.viewMode});}},
  async openRecommendation(e){
    const id=e&&e.currentTarget.dataset.id,listed=this.data.directory.find(r=>r.id===id);if(!listed&&!(this.data.demoStore&&this.data.demoStore.id===id))return;
    if(listed&&listed.platform_self_operated===true&&listed.platform_showcase!==true)return this.openPlatformMall(listed);
    const request={...this.customerReadToken(),id};this._detailRequest=request;
    this.setData({viewMode:'store-detail',selectedRecommendation:null,sceneStorefront:null,detailState:'LOADING',detailError:'',activeSection:'recommendations'});
    try{const r=await request.session.customer('store',{id});if(!this.customerReadCurrent(request)||this._detailRequest!==request)return;
      if(!(id.startsWith('demo_')?this.validDemoStore(r):this.validPublicStore(r))||r.id!==id)throw Error('门店资料返回未确认');
      if(r.platform_showcase===true){
        const item=r.showcase_item;
        if(!item||item.display_only!==true||item.available!==false||typeof item.name!=='string'||typeof item.description!=='string'||!Number.isSafeInteger(item.unit_minor)||item.unit_minor<1||typeof item.image_data!=='string')throw Error('展示商品资料返回未确认');
        if(item.gallery!==undefined&&(!Array.isArray(item.gallery)||![2,4].includes(item.gallery.length)||item.gallery.some(image=>!image||typeof image.image_data!=='string'||typeof image.credit!=='string'||typeof image.label!=='string')))throw Error('展示商品图片返回未确认');
        this.setData({selectedRecommendation:{...r,showcase_item:{...item,price_yuan:yuanAmount(item.unit_minor),quantity_label:Number.isSafeInteger(item.quantity)&&item.quantity>=0?String(item.quantity):'待同步'}},detailState:'READY'});
      }else this.setData({selectedRecommendation:r,detailState:'READY',demoPhotoFailed:false});
    }catch(e){if(this.customerReadDenied(request,e))return;if(this.customerReadCurrent(request)&&this._detailRequest===request){if(id.startsWith('demo_'))this.clearDemoProjection('展示商家暂不可用');this.setData({detailState:'FAILED',directoryError:e.message});}}
  },
  async openPlatformMall(record){
    if(!record||record.platform_self_operated!==true||typeof record.scene!=='string'||!/^[A-Za-z0-9_-]{1,32}$/.test(record.scene))return;
    getApp().globalData.scene=record.scene;this.setData({viewMode:'services',activeSection:'profile',serviceView:'products',selectedRecommendation:null});
    await this.onLoad({scene:record.scene,view:'services'});if(!this._pageUnloaded&&this.scene===record.scene)this.setData({viewMode:'services',activeSection:'profile',serviceView:'products'});
  },
  async loadSceneStorefront(){
    if(!this.scene||!this.session||!this.client||!this.data.sessionReady)return;
    const request={...this.customerReadToken(),scene:this.scene,client:this.client};this._detailRequest=request;
    const current=()=>this.customerReadCurrent(request)&&this._detailRequest===request&&this.scene===request.scene&&this.client===request.client&&this.data.viewMode==='store-detail';
    this.setData({selectedRecommendation:null,sceneStorefront:null,detailState:'LOADING',detailError:'',directoryError:''});
    try{
      const result=await request.client.storefront();if(!current())return;
      const merchant=result&&result.merchant;
      if(!merchant||typeof merchant!=='object'||Array.isArray(merchant)||typeof merchant.name!=='string'||!merchant.name||typeof merchant.description!=='string')throw Error('原门店资料返回未确认');
      // Original scene-authorized storefront, not a public-directory record or approval.
      this.setData({sceneStorefront:{name:merchant.name,description:merchant.description},merchant:merchant.name,detailState:'READY'});
    }catch(error){if(this.customerReadDenied(request,error))return;if(current())this.setData({sceneStorefront:null,detailState:'FAILED',detailError:error.storefrontCode==='STOREFRONT_UNAVAILABLE'?customerError(error):'',directoryError:error.message});}
  },
  backRecommendations(){this._detailRequest=null;this.setData({viewMode:'recommendations',activeSection:'recommendations',selectedRecommendation:null,sceneStorefront:null,detailState:'NOT_QUERIED',detailError:''});if(['NOT_QUERIED','FAILED'].includes(this.data.directoryState))return this.loadDirectory();},
  async retryStoreDetail(){
    if(this.data.detailState==='LOADING'||this._pageUnloaded||this._sceneStale)return;
    const id=this._detailRequest&&this._detailRequest.id;
    if(!this.data.sessionReady)return this.onLoad({scene:this.scene,view:'recommendations'});
    if(id)return this.openRecommendation({currentTarget:{dataset:{id}}});
    if(this.scene)return this.loadSceneStorefront();
    return this.backRecommendations();
  },
  openOrders(){this.setData({viewMode:'orders',activeSection:'orders',selectedRecommendation:null});return this.loadOrders();},
  openService(e){
    if(this._pageUnloaded||this.data.pending||this.data.productsPending||this.data.refundRecoveryPending)return;
    const view=e.currentTarget.dataset.view;
    if(!['home','community','community-list','community-detail','community-code','referral','products','checkout','payment','refund','refund-detail','legacy-profile','legacy-notices'].includes(view))return;
    if(view==='community-detail'&&!this.data.selectedCommunity)return;
    this.setData({viewMode:'services',activeSection:'profile',serviceView:view});
  },
  backServices(){this.openService({currentTarget:{dataset:{view:'home'}}});},
  openCommunityDetails(e){
    if(this._pageUnloaded||this.data.pending||!this.data.sessionReady)return;
    const record=this.data.communities.find(x=>x.id===e.currentTarget.dataset.id);if(!record)return;
    this.setData({selectedCommunity:{id:record.id,name:record.name,description:record.description},serviceView:'community-detail'});
  },
  orderMatchesFilter(record,filter){const state=record&&record.order&&record.order.state;return filter==='all'||filter==='unpaid'&&['CREATED','PENDING'].includes(state)||filter==='unshipped'&&['SUCCESS','PAID','FULFILLING'].includes(state)||filter==='shipped'&&state==='SHIPPED'||filter==='completed'&&state==='COMPLETED'||filter==='after-sale'&&['CANCELLED','FAILED','REFUNDED','REFUNDING','AFTER_SALE'].includes(state);},
  withOrderVisibility(records,filter=this.data.orderFilter){return records.map(record=>({...record,visible:this.orderMatchesFilter(record,filter)}));},
  chooseOrderFilter(e){const value=e.currentTarget.dataset.filter;if(!this.data.pending&&['all','unpaid','unshipped','shipped','completed','after-sale'].includes(value)){const orders=this.withOrderVisibility(this.data.orders,value);this.setData({orderFilter:value,orders,visibleOrderCount:orders.filter(x=>x.visible).length});}},
  openRecommendations(){this.setData({viewMode:'recommendations',activeSection:'recommendations',selectedRecommendation:null});return this.loadDirectory();},
  hideOrderDetails(){this.setData({detailsCollapsed:true});},
  showOrderDetails(){this.setData({detailsCollapsed:false});},
  customerReadToken(){return {session:this.session,generation:this._pageGeneration,epoch:this._authEpoch,sessionGeneration:this.session&&this.session.getGeneration?this.session.getGeneration():undefined};},
  customerReadCurrent(r){return !!r.session&&!this._pageUnloaded&&this.session===r.session&&this._pageGeneration===r.generation&&auth.active(r.epoch)&&(!r.session.getGeneration||r.session.getGeneration()===r.sessionGeneration);},
  customerReadDenied(request,error){
    if(error.code!=='ACCESS_DENIED'||this._pageUnloaded||this.session!==request.session||this._pageGeneration!==request.generation||!auth.active(request.epoch)||!request.session.isAuthenticated||request.session.isAuthenticated())return false;
    this.customerSessionRevoked('登录或访问权限已失效，请返回首页重新进入',false);
    this.setData({directoryState:'FAILED',directoryError:'访问权限已失效',contextsState:'FAILED',contextsError:'访问权限已失效',ordersState:'FAILED',ordersError:'访问权限已失效',detailState:'FAILED'});return true;
  },
  clearDemoProjection(message){
    const demoDetail=this.data.selectedRecommendation&&this.data.selectedRecommendation.is_demo||this._detailRequest&&typeof this._detailRequest.id==='string'&&this._detailRequest.id.startsWith('demo_');
    if(demoDetail)this._detailRequest=null;
    this.setData({demoStore:null,demoState:'UNKNOWN',...(demoDetail?{selectedRecommendation:null,detailState:'FAILED',directoryError:message}:{})});
  },
  validDemoStore(r){return r&&typeof r.id==='string'&&/^demo_[a-f0-9]{64}$/.test(r.id)&&r.is_demo===true&&r.display_only===true&&r.payment_enabled===false&&r.purchasing_enabled===false&&r.include_in_real_statistics===false&&r.category_state==='DEMO'&&r.version===1&&r.profile_version===0&&r.photo_asset_id==='community-demo-storefront-v1'&&r.storefront_photo===null&&r.photo_state==='BUNDLED_DEMO_ASSET_PENDING'&&typeof r.name==='string'&&typeof r.description==='string';},
  demoImageError(){this.setData({demoPhotoFailed:true});},
  validPublicStore(r){return r&&r.is_demo!==true&&typeof r.id==='string'&&/^[a-f0-9]{64}$/.test(r.id)&&typeof r.name==='string'&&typeof r.description==='string'&&r.storefront_photo===null&&r.photo_state==='NOT_CONNECTED'&&(r.platform_self_operated===undefined&&r.scene===undefined||typeof r.platform_self_operated==='boolean'&&(r.platform_self_operated?typeof r.scene==='string'&&/^[A-Za-z0-9_-]{1,32}$/.test(r.scene):r.scene===null));},
  async cacheShowcaseCover(record,current){
    if(!record.platform_showcase||!record.showcase_cover)return record;
    const image=record.showcase_cover.image_data;
    if(typeof image!=='string'||image.length>550000||!/^data:image\/(?:jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(image)||!(image.startsWith('data:image/jpeg;base64,/9j/')||image.startsWith('data:image/png;base64,iVBORw0KGgo')))return {...record,coverFailed:true};
    const file=wx.env.USER_DATA_PATH+'/showcase-cover-'+record.id+'-'+Date.now()+'-'+Math.random().toString(16).slice(2)+(image.startsWith('data:image/png;')?'.png':'.jpg');
    try{
      await new Promise((resolve,reject)=>wx.getFileSystemManager().writeFile({filePath:file,data:image.split(',')[1],encoding:'base64',success:resolve,fail:reject}));
      if(!current()){this.deleteShowcaseCover(file);return record;}
      (this._coverFiles||(this._coverFiles=new Set())).add(file);
      return {...record,coverPath:file,coverFailed:false,coverLoaded:false};
    }catch(e){this.deleteShowcaseCover(file);return {...record,coverFailed:true};}
  },
  deleteShowcaseCover(file){if(file)try{wx.getFileSystemManager().unlink({filePath:file,fail(){}});}catch(e){}},
  clearShowcaseCovers(){for(const file of this._coverFiles||[])this.deleteShowcaseCover(file);this._coverFiles=new Set();},
  showcaseCoverLoad(e){const id=e.currentTarget.dataset.id,path=e.currentTarget.dataset.path;this.setData({directory:this.data.directory.map(r=>r.id===id&&r.coverPath===path?{...r,coverLoaded:true}:r)});},
  showcaseCoverError(e){const id=e.currentTarget.dataset.id,path=e.currentTarget.dataset.path;this.setData({directory:this.data.directory.map(r=>r.id===id&&r.coverPath===path?{...r,coverFailed:true,coverLoaded:false}:r)});},
  directoryVisible(record,category=this.data.categoryId){if(!category)return true;const local=LOCAL_CATEGORIES.find(c=>c.id===category);if(!local)return record.category_id===category;const text=[record.category_name,record.name,record.description].filter(v=>typeof v==='string').join('');return local.keywords.some(word=>text.includes(word));},
  async loadDirectory(e){
    if(!this.session||!this.data.sessionReady)return;
    const more=e?.currentTarget?.dataset?.more==='true';if(more&&!this.data.directoryMore)return;
    this.clearDemoProjection('正在重新核对展示商家状态');
    const request={...this.customerReadToken(),category:this.data.categoryId};this._directoryRequest=request;
    const params={};if(request.category&&!request.category.startsWith('local:'))params.category_id=request.category;if(more)params.after_id=this.data.directoryCursor;
    if(!more)this.clearShowcaseCovers();
    this.setData({demoStore:null,demoState:'UNKNOWN',directoryState:'LOADING',directoryError:'',...(!more?{directory:[],directoryCursor:null,directoryMore:false,demoStore:null,demoState:'UNKNOWN',demoPhotoFailed:false}:{})});
    const current=()=>this.customerReadCurrent(request)&&this._directoryRequest===request&&this.data.categoryId===request.category;
    try{const r=await request.session.customer('directory',params);if(!current())return;
      if(!r||!Array.isArray(r.records)||r.records.some(v=>!this.validPublicStore(v))||!Array.isArray(r.categories)||r.categories.some(v=>!v||typeof v.id!=='string'||typeof v.name!=='string')||typeof r.has_more!=='boolean'||(r.has_more?typeof r.next_cursor!=='string'||!r.next_cursor||r.next_cursor===params.after_id:r.next_cursor!==null))throw Error('推荐列表返回未确认');
      const demo=r.demo;
      if(demo&&(!['VISIBLE','HIDDEN_REAL_APPROVAL_OBSERVED','UNKNOWN','NOT_CURRENT_PROJECT'].includes(demo.state)||(demo.state==='VISIBLE'?!this.validDemoStore(demo.record):demo.record!==null)))throw Error('展示商家状态未确认');
      const records=more?this.data.directory.slice():[];for(const v of r.records)if(!records.some(x=>x.id===v.id))records.push(await this.cacheShowcaseCover(v,current));if(!current())return;
      const categories=[...LOCAL_CATEGORIES,...r.categories.filter(category=>!LOCAL_CATEGORIES.some(local=>local.name===category.name))],visibleRecords=records.map(v=>({...v,visible:this.directoryVisible(v,request.category)}));
      this.setData({demoStore:demo&&demo.state==='VISIBLE'?demo.record:null,demoState:demo?demo.state:'UNKNOWN',directory:visibleRecords,categories,directoryState:'READY',visibleDirectoryCount:visibleRecords.filter(v=>v.visible).length,directoryMore:r.has_more,directoryCursor:r.next_cursor});
    }catch(e){if(this.customerReadDenied(request,e))return;if(current())this.setData({directoryState:'FAILED',directoryError:e.message});}
  },
  chooseCategory(e){const id=e.currentTarget.dataset.id;if(id!==''&&!this.data.categories.some(c=>c.id===id))return;const directory=this.data.directory.map(v=>({...v,visible:this.directoryVisible(v,id)}));this.setData({categoryId:id,directory,visibleDirectoryCount:directory.filter(v=>v.visible).length});return this.loadDirectory();},
  async loadContexts(){
    if(!this.session||!this.data.sessionReady)return null;
    const request=this.customerReadToken();this._contextRequest=request;this.setData({contextsState:'LOADING',contextsError:'',contexts:[]});
    const contexts=[],seen=new Set();let cursor='';
    const current=()=>this.customerReadCurrent(request)&&this._contextRequest===request;
    try{do{const r=await request.session.customer('contexts',cursor?{after_scene:cursor}:{});if(!current())return null;
      if(!r||!Array.isArray(r.contexts)||typeof r.has_more!=='boolean'||r.contexts.some(c=>!c||typeof c.scene!=='string'||!/^[A-Za-z0-9_-]{1,32}$/.test(c.scene))||(r.has_more?typeof r.next_cursor!=='string'||!r.next_cursor||seen.has(r.next_cursor):r.next_cursor!==null))throw Error('授权服务列表返回未确认');
      for(const c of r.contexts)if(!contexts.some(x=>x.scene===c.scene))contexts.push(c);
      cursor=r.has_more?r.next_cursor:'';if(cursor)seen.add(cursor);
    }while(cursor);
    if(current()){this.setData({contexts,contextsState:'READY'});return contexts;}
    }catch(e){if(this.customerReadDenied(request,e))return null;if(current())this.setData({contexts:[],contextsState:'FAILED',contextsError:e.message});}return null;
  },
  async selectContext(e){
    const scene=e.currentTarget.dataset.scene;if(!this.data.contexts.some(c=>c.scene===scene)||this.data.pending)return;
    this.customerSessionRevoked('正在切换服务范围',false);getApp().globalData.scene=scene;
    await this.onLoad({scene,view:'services'});
  },
  async loadAllOrders(e){
    if(!this.session||!this.data.sessionReady||this._allOrdersRequest)return;
    const more=e?.currentTarget?.dataset?.more==='true';if(more&&!this.data.ordersMore)return;
    const request=this.customerReadToken();this._allOrdersRequest=request;
    this.setData({pending:true,ordersState:'LOADING',ordersError:'',...(!more?{orders:[],ordersMore:false,orderCursor:null,visibleOrderCount:0}:{})});
    const current=()=>this.customerReadCurrent(request)&&this._allOrdersRequest===request;
    try{
      if(!more){const contexts=await this.loadContexts();if(!current())return;if(!contexts)throw Error(this.data.contextsError||'授权范围读取失败');this._orderScopes=contexts.map(c=>({scene:c.scene,cursor:'',done:false,seen:[]}));}
      const records=more?this.data.orders.slice():[];
      for(const scope of this._orderScopes||[]){if(scope.done)continue;
        const r=await request.session.commerce(scope.scene,'orders',{after_id:scope.cursor});if(!current())return;
        if(!r||!Array.isArray(r.records)||typeof r.has_more!=='boolean'||r.records.some(v=>!v||typeof v.reference!=='string'||!/^[A-Za-z0-9_-]{1,64}$/.test(v.reference)||!v.order||typeof v.order.state!=='string')||(r.has_more?typeof r.next_cursor!=='string'||!r.next_cursor||r.next_cursor===scope.cursor||scope.seen.includes(r.next_cursor):r.next_cursor!==null))throw Error('订单列表返回未确认');
        for(const v of r.records){const key=scope.scene+':'+v.reference;if(!records.some(x=>x.key===key))records.push({...displayOrder(v,this.data.orderFilter),scene:scope.scene,key});}
        scope.done=!r.has_more;scope.cursor=r.next_cursor;if(scope.cursor)scope.seen.push(scope.cursor);
      }
      const hasMore=(this._orderScopes||[]).some(c=>!c.done),visibleRecords=this.withOrderVisibility(records);this.setData({orders:visibleRecords,ordersState:hasMore?'PARTIAL':'READY',ordersMore:hasMore,visibleOrderCount:visibleRecords.filter(x=>x.visible).length});
    }catch(e){if(this.customerReadDenied(request,e))return;if(current())this.setData({ordersState:'FAILED',ordersError:e.message,ordersMore:false,...(e.code==='ACCESS_DENIED'||e.accessDenied===true||e.message==='SESSION_EXPIRED'?{orders:[],visibleOrderCount:0}:{})});}
    finally{if(this._allOrdersRequest===request){this._allOrdersRequest=null;if(current()||this.customerReadCurrent(request))this.setData({pending:false});}}
  },

  async onLoad(options) {
    this._sceneStale=false;this.setData({nativeCollectionEntry:false});
    this._detailRequest=null;this.setData({sceneStorefront:null,detailState:'NOT_QUERIED',detailError:'',directoryError:''});
    if(options&&['recommendations','orders','store-detail','services'].includes(options.view)){const view=options.view;this.setData({viewMode:view,activeSection:view==='orders'?'orders':view==='services'?'profile':'recommendations',selectedRecommendation:null});}
    this._pageUnloaded=false;this._authEpoch=auth.current();this._consumerRequest=null;this._productRequest=null;this._projectMessagesContext=null;
    this.setData({projectMessages:[],projectMessagesCursor:null,projectMessagesMore:false,projectMessagesLoaded:false,projectMessagesStatus:''});
    this.setData({products:[],productCursor:null,productsMore:false,productsPending:false,productsStatus:''});
    this.resetOrderDetails();
    this._noticeContext=null;this._noticeRequest=null;
    this.setData({notices:[],noticeCursor:null,noticesMore:false,noticesLoaded:false,noticePending:false,noticeStatus:''});
    let lifecycle=this._pageGeneration=(this._pageGeneration||0)+1;
    const current=()=>!this._pageUnloaded&&this._pageGeneration===lifecycle&&auth.active(this._authEpoch);
    try {
      const config = getApp().globalData;
      if (config.mode !== 'OFFLINE') {
        if(!(options&&options.scene)&&!config.scene){
          this.scene='';
          // No scene means no current storefront. Show the real directory, never an unbound detail.
          this.setData({needsScene:true,sessionReady:false,status:'正在恢复登录信息',...(this.data.viewMode==='store-detail'?{viewMode:'recommendations',activeSection:'recommendations'}:{})});
          this.session=getSharedSession(wx,config,undefined,this);
          this._authEpoch=auth.current();lifecycle=this._pageGeneration=(this._pageGeneration||0)+1;
          await this.session.ensureLogin({automatic:true,prepared:true});if(!current())return;
          this.setData({sessionReady:true,commerceEnabled:config.commerce===true,status:''});
          if(this.data.viewMode==='orders')await this.loadOrders();
          else if(this.data.viewMode==='services')await this.loadContexts();
          else await this.loadDirectory();
          return;
        }
        this.setData({needsScene:false});
        const scene = parseScene(options&&options.scene?options:{scene:config.scene});
        this.scene=scene;config.scene=scene;
        const nativeEntry=/^wxn_[a-f0-9]{28}$/.test(scene)&&!(options&&options.view);
        if(nativeEntry)this.setData({nativeCollectionEntry:true,viewMode:'services',activeSection:'profile',serviceView:'checkout',commerceEnabled:false,paymentsEnabled:false});
        if(options&&typeof options.promotion==='string'&&/^cp_[0-9a-f]{32}$/.test(options.promotion))this.setData({promotionCode:options.promotion});
        this.session = getSharedSession(wx,config,undefined,this);
        this._authEpoch=auth.current();lifecycle=this._pageGeneration=(this._pageGeneration||0)+1;
        await this.session.ensureLogin({automatic:true,prepared:true});
        if(!current())return;
        if(config.commerce===true&&!nativeEntry){this.setData({commerceEnabled:true,status:'支付尚未开放，可浏览商品和查询订单'});await this.reloadProducts();if(!current())return;}
        this.client = makeClient(body => this.session.transport(scene,body));
        this.setData({sessionReady:!!this.session&&auth.active(this._authEpoch)});if(this.data.viewMode==='recommendations'&&typeof this.session.customer==='function')await this.loadDirectory();else if(this.data.viewMode==='orders')await this.loadOrders();if(!current())return;
        if(config.payments===true&&!nativeEntry){this.paymentFlow=createPaymentFlow(wx,(op,reference)=>this.session.payment(scene,op,reference));this.setData({paymentsEnabled:true,status:'请创建订单，或输入原订单号查询微信结果'});}
      } else {
    this.client = makeClient(body => new Promise((resolve,reject) => {
      const {baseUrl,token} = getApp().globalData;
      if (!baseUrl || !token) return reject(Error('请先配置本地开发服务'));
      wx.request({url:baseUrl+'/offline/saas', method:'POST', data:body,
        header:{'content-type':'application/json','X-Offline-Token':token}, timeout:5000,
        success:r=>r.statusCode===200?resolve(r.data):reject(Error('请求被拒绝')),
        fail:reject});
    }));
      }
    if(this.scene&&this.data.viewMode==='store-detail'){await this.loadSceneStorefront();return;}
    this.client.storefront().then(s=>{
      if(!current())return;
      if(this.data.nativeCollectionEntry&&(!s.collection_entry||s.collection_entry.scene!==this.scene||s.collection_entry.approval_verified!==true||s.collection_entry.payment_product_admitted!==false))throw Error('NATIVE_COLLECTION_ENTRY_UNCONFIRMED');
      this.setData({merchant:s.merchant.name,
        ...(this.data.nativeCollectionEntry?{status:'本商家微信申请已通过；支付产品接线待核实，暂不发起交易'}:{}),
        beforeAd:s.ads.AD_SLOT_PAYMENT_AMOUNT ? s.ads.AD_SLOT_PAYMENT_AMOUNT.title : '',
        beforeAdImage:s.ads.AD_SLOT_PAYMENT_AMOUNT ? s.ads.AD_SLOT_PAYMENT_AMOUNT.image_data||'' : ''});
    })
      .catch(e=>{if(current())this.setData({status:customerError(e)});});
    } catch(e) {if(current())this.setData({status:customerError(e)});}
  },
  onUnload() {this._receiptAdRequest=null;this.clearShowcaseCovers();this._detailRequest=null;this.setData({sessionReady:false,sceneStorefront:null,detailState:'NOT_QUERIED',detailError:''});this._consumerRequest=null;this._productRequest=null;this._pageUnloaded=true;this._pageGeneration=(this._pageGeneration||0)+1;this._projectRequest=null;this._noticeRequest=null;if(this.client)this.client.reset();if(this.paymentFlow)this.paymentFlow.reset();if(this.session&&this.session.detachPage)this.session.detachPage(this);this.session=null;},
  customerSessionRevoked(status='登录已退出，请重新登录',revokeIdentity=true){
    this._receiptAdRequest=null;
    this._directoryRequest=null;this._contextRequest=null;this._allOrdersRequest=null;this._detailRequest=null;this._orderScopes=null;this._pageGeneration=(this._pageGeneration||0)+1;this._consumerRequest=null;this._productRequest=null;this._projectRequest=null;this._noticeRequest=null;this._profileRequest=null;
    if(this.client)this.client.reset();if(this.paymentFlow)this.paymentFlow.reset();if(revokeIdentity&&this.session)this.session.clear();
    this.session=null;this.client=null;this.paymentFlow=null;
    if(!this._pageUnloaded)this.setData({sceneStorefront:null,detailState:'NOT_QUERIED',detailError:'',demoStore:null,demoState:'UNKNOWN',demoPhotoFailed:false,directory:[],categories:[],directoryState:'NOT_QUERIED',contexts:[],contextsState:'NOT_QUERIED',ordersState:'NOT_QUERIED',selectedRecommendation:null,serviceView:'home',selectedCommunity:null,communityRelation:null,orderFilter:'all',visibleOrderCount:0,sessionReady:false,commerceEnabled:false,paymentsEnabled:false,communities:[],communityCursor:null,communitiesMore:false,communityId:'',promotionCode:'',profileVersion:null,nickname:'',profileContact:'',ownReferralCode:'',referralCode:'',projectCustomerId:'',userId:'',
      notices:[],noticeCursor:null,noticesMore:false,noticesLoaded:false,noticePending:false,noticeStatus:'',
      orders:[],orderCursor:null,ordersMore:false,orderDetails:null,orderDetailsPending:false,orderDetailsStatus:'',
      reference:'',amount:'',merchant:'',beforeAd:'',beforeAdImage:'',afterAd:'',afterAdImage:'',afterAdVerified:false,
      refundCurrent:null,refundRecoveryLoaded:false,refundRecoveryPending:false,refundRecoveryStatus:'',refundApplication:'',refundAmount:'',refundReason:'',
      projectTitle:'',projectRole:'',projectChecklist:[],projectMessages:[],projectMessagesCursor:null,projectMessagesMore:false,projectMessagesLoaded:false,projectMessagesStatus:'',
      projectFeedback:'',projectReference:'',projectReferenceItem:'',projectReferenceRevision:0,projectState:'',pending:false,status});
  },
  openCustomerHome(){return auth.navigate(this,'home',wx,getApp(),typeof getCurrentPages==='function'?getCurrentPages():[]);},
  quantity(e) {const id=e.currentTarget.dataset.id;const quantity=Number(e.detail.value);if(!Number.isSafeInteger(quantity)||quantity<0||quantity>10000)return;this.setData({products:this.data.products.map(p=>p.item_id===id?{...p,quantity}:p)});},
  inputProfile(e) {const field=e.currentTarget.dataset.field;if(['nickname','profileContact','referralCode'].includes(field))this.setData({[field]:e.detail.value});},
  inputProject(e) {this.setData({projectFeedback:e.detail.value});},
  selectProjectRequirement(e) {
    if(this.data.pending)return;
    const item=e.currentTarget.dataset.item,revision=Number(e.currentTarget.dataset.revision);
    const source=this.data.projectChecklist.find(entry=>entry.id===item);
    if(!source||!Number.isSafeInteger(revision)||revision!==source.revision)return;
    if(!['SECRETREF','OAUTH','SERVER_CHALLENGE'].includes(source.submission_type)){
      this.setData({status:'此材料需要通过原客户中心私有文件上传，不允许用引用编号代替'});return;
    }
    this._projectRequest=null;
    this.setData({projectReferenceItem:item,projectReferenceRevision:revision,
      projectReferenceKind:source.submission_type,projectReference:''});
  },
  inputProjectReference(e){this.setData({projectReference:e.detail.value});},
  inputProjectReferenceKind(e){const items=['SECRETREF','OAUTH','SERVER_CHALLENGE'];const i=Number(e.detail.value);if(Number.isSafeInteger(i)&&items[i])this.setData({projectReferenceKind:items[i]});},
  beginProjectRequest() {
    const request={generation:this._pageGeneration,session:this.session,scene:this.scene,
      sessionGeneration:typeof this.session.getGeneration==='function'?this.session.getGeneration():undefined,
      customer:this.data.projectCustomerId,user:this.data.userId,item:this.data.projectReferenceItem,
      revision:this.data.projectReferenceRevision};
    this._projectRequest=request;
    this.setData({pending:true});
    return request;
  },
  projectRequestCurrent(request) {
    return !this._pageUnloaded&&this._projectRequest===request&&
      this._pageGeneration===request.generation&&this.session===request.session&&
      (typeof request.session.getGeneration!=='function'||request.session.getGeneration()===request.sessionGeneration)&&
      this.scene===request.scene&&this.data.projectCustomerId===request.customer&&this.data.userId===request.user&&
      this.data.projectReferenceItem===request.item&&this.data.projectReferenceRevision===request.revision;
  },
  async saveProjectReference() {
    if(this._pageUnloaded||this.data.pending||!this.session||!this.data.projectReferenceItem)return;
    if(typeof this.data.projectReference!=='string'||!this.data.projectReference.trim()||this.data.projectReference.length>256){this.setData({status:'材料引用编号不能为空且不得超过256字符'});return;}
    if(!['SECRETREF','OAUTH','SERVER_CHALLENGE'].includes(this.data.projectReferenceKind))return;
    const request=this.beginProjectRequest();
    try{
      const r=await request.session.commerce(request.scene,'project_save_reference',{
        item:this.data.projectReferenceItem,revision:this.data.projectReferenceRevision,
        kind:this.data.projectReferenceKind,reference:this.data.projectReference});
      if(!this.projectRequestCurrent(request))return;
      request.revision=r.revision;
      this.setData({projectReference:'',projectReferenceRevision:r.revision,status:'可信材料引用已保存，需单独提交审核'});
      const checklist=await request.session.commerce(request.scene,'project_checklist',{});
      if(!this.projectRequestCurrent(request))return;
      this.setData({projectChecklist:checklist.items.map(v=>({
        id:v.id,state:v.state,required:v.required,revision:v.revision,title:v.title,instructions:v.instructions,submission_type:v.submission_type}))});
    }catch(error){if(this.projectRequestCurrent(request))this.setData({status:error.message});}
    finally{if(this.projectRequestCurrent(request)){this._projectRequest=null;this.setData({pending:false});}}
  },

  async uploadProjectDocument(e) {
    if(this._pageUnloaded||this.data.pending||!this.session)return;
    const item=e.currentTarget.dataset.item,revision=Number(e.currentTarget.dataset.revision);
    const source=this.data.projectChecklist.find(entry=>entry.id===item);
    if(!source||source.submission_type!=='PRIVATE_DOCUMENT'||!Number.isSafeInteger(revision)||revision<0||revision!==source.revision)return;
    this.setData({projectReferenceItem:item,projectReferenceRevision:revision,
      projectReferenceKind:'PRIVATE_DOCUMENT',projectReference:''});
    const request=this.beginProjectRequest();
    let uploading=false;
    try {
      const selected=await new Promise((resolve,reject)=>wx.chooseMessageFile({
        count:1,type:'file',extension:['pdf','png','jpg','jpeg'],success:resolve,
        fail:error=>reject(Error(error&&typeof error.errMsg==='string'&&/cancel/i.test(error.errMsg)?'DOCUMENT_PICK_CANCELLED':'DOCUMENT_PICK_FAILED'))
      }));
      if(!this.projectRequestCurrent(request))return;
      const file=selected&&selected.tempFiles&&selected.tempFiles.length===1?selected.tempFiles[0]:null;
      if(!file||typeof file.name!=='string'||!file.name||file.name.length>180||
         !/\.(pdf|png|jpe?g)$/i.test(file.name)||typeof file.path!=='string'||!file.path||
         !Number.isSafeInteger(file.size)||file.size<1||file.size>5000000)throw Error('仅支持不超过5MB的PDF、PNG或JPEG文件');
      const read=await new Promise((resolve,reject)=>wx.getFileSystemManager().readFile({
        filePath:file.path,encoding:'base64',success:resolve,fail:()=>reject(Error('文件读取失败，请重新选择'))
      }));
      if(!this.projectRequestCurrent(request))return;
      uploading=true;
      const result=await request.session.projectDocument(request.scene,{
        item,revision,filename:file.name,content_base64:read.data
      },request.sessionGeneration);
      if(!this.projectRequestCurrent(request))return;
      request.revision=result.revision;
      this.setData({projectReferenceRevision:result.revision,
        projectChecklist:this.data.projectChecklist.map(entry=>entry.id===item?{...entry,revision:result.revision,state:result.state}:entry),
        status:'私有材料版本已保存，需单独提交审核'});
    } catch(error) {
      if(this.projectRequestCurrent(request))this.setData({status:error.message==='DOCUMENT_PICK_CANCELLED'?'已取消选择文件':
        error.message==='INVALID_PROJECT_DOCUMENT'?'文件名称、格式或内容无效，请重新选择PDF、PNG或JPEG文件':
        error.message==='SESSION_EXPIRED'?'登录已过期，请重新登录后重新选择文件':
        uploading?'上传结果未确认；请先刷新资料清单核对当前版本，不要重复上传':error.message});
    } finally {
      if(this.projectRequestCurrent(request)){this._projectRequest=null;this.setData({pending:false});}
    }
  },

  async submitProjectItem(e) {
    if(this._pageUnloaded||this.data.pending||!this.session)return;
    const item=e.currentTarget.dataset.item;
    const revision=Number(e.currentTarget.dataset.revision);
    if(typeof item!=='string'||!Number.isSafeInteger(revision)||revision<0)return;
    const request=this.beginProjectRequest();
    try {
      const result=await request.session.commerce(request.scene,'project_submit',{item,revision});
      if(!this.projectRequestCurrent(request))return;
      this.setData({status:'资料版本已提交审核：'+result.state});
      const checklist=await request.session.commerce(request.scene,'project_checklist',{});
      if(!this.projectRequestCurrent(request))return;
      this.setData({projectChecklist:checklist.items.map(entry=>({
        id:entry.id,state:entry.state,required:entry.required,revision:entry.revision,title:entry.title,instructions:entry.instructions,submission_type:entry.submission_type
      }))});
    } catch(error){if(this.projectRequestCurrent(request))this.setData({status:error.message});}
    finally {if(this.projectRequestCurrent(request)){this._projectRequest=null;this.setData({pending:false});}}
  },

  async projectAction(e) {
    if(this._pageUnloaded||this.data.pending||!this.session)return;
    const op=e.currentTarget.dataset.operation;
    if(!['project_summary','project_checklist','project_feedback','project_messages'].includes(op))return;
    const more=op==='project_messages'&&e.currentTarget.dataset.more==='true';
    if(op==='project_messages'){
      this.prepareProjectMessagesContext();
      if(more&&(!this.data.projectMessagesLoaded||!this.data.projectMessagesMore||!this.data.projectMessagesCursor))return;
    }
    const after=more?this.data.projectMessagesCursor:'';
    const request=this.beginProjectRequest();
    try {
      const params=op==='project_feedback'?{message:this.data.projectFeedback}:
        op==='project_messages'?{after_id:after}:{};
      const r=await request.session.commerce(request.scene,op,params);
      if(!this.projectRequestCurrent(request))return;
      if(op==='project_summary')request.customer=r.customer_id;
      if(op==='project_summary')this.setData({projectTitle:r.title,projectRole:r.role,
        projectCustomerId:r.customer_id,projectState:r.checklist_overall});
      else if(op==='project_checklist')this.setData({projectChecklist:r.items.map(item=>({
        id:item.id,state:item.state,required:item.required,revision:item.revision,title:item.title,instructions:item.instructions,submission_type:item.submission_type}))});
      else if(op==='project_messages'){
        const records=this.projectMessagePage(r,after);
        const merged=new Map((more?this.data.projectMessages:[]).map(record=>[record.id,record]));
        for(const record of records)merged.set(record.id,record);
        this.setData({projectMessages:Array.from(merged.values()),projectMessagesCursor:r.next_cursor,
          projectMessagesMore:r.has_more,projectMessagesLoaded:true,status:'读取原项目归档记录；不代表已获得人工回复',projectMessagesStatus:'读取原项目归档记录；不代表已获得人工回复'});
      }
      else this.setData({projectFeedback:'',status:'项目反馈已归档，尚未确认人工回复：'+r.id});
      if(op==='project_summary'&&this._noticeContext)this.prepareNoticeContext();
      if(op==='project_summary'&&this._projectMessagesContext)this.prepareProjectMessagesContext();
    } catch(error) {if(this.projectRequestCurrent(request))this.setData(op==='project_messages'?{projectMessagesStatus:error.message}:{status:error.message});}
    finally {if(this.projectRequestCurrent(request)){this._projectRequest=null;this.setData({pending:false});}}
  },
  prepareProjectMessagesContext() {
    if(!this.noticeContextCurrent(this._projectMessagesContext)){
      this._projectMessagesContext={generation:this._pageGeneration,session:this.session,scene:this.scene,
        user:this.data.userId,customer:this.data.projectCustomerId,
        sessionGeneration:typeof this.session.getGeneration==='function'?this.session.getGeneration():undefined};
      this.setData({projectMessages:[],projectMessagesCursor:null,projectMessagesMore:false,
        projectMessagesLoaded:false,projectMessagesStatus:''});
    }
    return this._projectMessagesContext;
  },
  projectMessagePage(result,after) {
    const invalid=()=>{throw Error('项目反馈列表返回无效，请重试');};
    const key=record=>[record.created,record.id];
    const greater=(a,b)=>a[0]>b[0]||(a[0]===b[0]&&a[1]>b[1]);
    if(!result||result.source!=='ORIGINAL_CENTER_ARCHIVE'||result.provider_reply_verified!==false||
      !Array.isArray(result.records)||result.records.length>50||typeof result.has_more!=='boolean')invalid();
    let previous=null;
    if(after){
      try{previous=JSON.parse(after);}catch(_){invalid();}
      if(!Array.isArray(previous)||previous.length!==2||!Number.isSafeInteger(previous[0])||
        typeof previous[1]!=='string'||!/^[A-Za-z0-9_-]{1,64}$/.test(previous[1]))invalid();
    }
    const ids=new Set(),records=[];
    for(const record of result.records){
      if(!record||typeof record.id!=='string'||!/^[A-Za-z0-9_-]{1,64}$/.test(record.id)||ids.has(record.id)||
        !Number.isSafeInteger(record.created)||typeof record.channel!=='string'||typeof record.body!=='string'||
        typeof record.status!=='string'||(previous&&!greater(key(record),previous)))invalid();
      ids.add(record.id);previous=key(record);
      // Keep precisely the original customer projection, never evidence/raw fields.
      records.push({id:record.id,channel:record.channel,body:record.body,status:record.status,created:record.created});
    }
    if(result.has_more){
      if(records.length!==50||typeof result.next_cursor!=='string'||result.next_cursor!==JSON.stringify(previous))invalid();
    }else if(result.next_cursor!==null)invalid();
    return records;
  },
  noticeContextCurrent(context) {
    return !!context&&!this._pageUnloaded&&auth.active(this._authEpoch)&&context.generation===this._pageGeneration&&
      context.session===this.session&&context.scene===this.scene&&
      context.user===this.data.userId&&context.customer===this.data.projectCustomerId&&
      (typeof context.session.getGeneration!=='function'||context.session.getGeneration()===context.sessionGeneration);
  },
  prepareNoticeContext() {
    if(!this.noticeContextCurrent(this._noticeContext)){
      this._noticeRequest=null;
      this._noticeContext={generation:this._pageGeneration,session:this.session,scene:this.scene,
        user:this.data.userId,customer:this.data.projectCustomerId,
        sessionGeneration:typeof this.session.getGeneration==='function'?this.session.getGeneration():undefined};
      this.setData({notices:[],noticeCursor:null,noticesMore:false,noticesLoaded:false,noticePending:false,noticeStatus:''});
    }
    return this._noticeContext;
  },
  noticeRequestCurrent(request) {
    return this._noticeRequest===request&&this.noticeContextCurrent(request.context);
  },
  noticeRequestFailed(request,error) {
    if(!this.noticeRequestCurrent(request))return;
    const denied=error&&(error.code==='ACCESS_DENIED'||error.message==='SESSION_EXPIRED');
    this.setData({...(denied?{notices:[],noticeCursor:null,noticesMore:false,noticesLoaded:false}:{}),
      noticeStatus:denied?'通知访问已被拒绝或会话已过期，请重新确认授权后读取':error.message});
  },
  async loadNotices(e) {
    if(this._pageUnloaded||!this.session||this.data.pending)return;
    const context=this.prepareNoticeContext();
    if(this.data.noticePending)return;
    const more=e&&e.currentTarget&&e.currentTarget.dataset.more==='true';
    if(more&&(!this.data.noticesLoaded||!this.data.noticesMore||!this.data.noticeCursor))return;
    const after=more?this.data.noticeCursor:'';
    const request={context};this._noticeRequest=request;this.setData({noticePending:true,noticeStatus:''});
    try {
      const r=await context.session.commerce(context.scene,'notices',{after_id:after});
      if(!this.noticeRequestCurrent(request))return;
      if(!r||!Array.isArray(r.records)||r.records.length>50||typeof r.has_more!=='boolean'||
         r.records.some(record=>!record||typeof record.id!=='string'||!/^[0-9a-f]{64}$/.test(record.id)||
           typeof record.message!=='string'||typeof record.read!=='boolean')||
         (r.has_more?(!r.records.length||typeof r.next_cursor!=='string'||!/^[0-9a-f]{64}$/.test(r.next_cursor)||r.next_cursor<=after):r.next_cursor!==null))
        throw Error('通知列表返回无效，请重试');
      const records=new Map((more?this.data.notices:[]).map(record=>[record.id,record]));
      for(const record of r.records){const prior=records.get(record.id);records.set(record.id,{...record,read:record.read||!!(prior&&prior.read)});}
      this.setData({notices:Array.from(records.values()),noticeCursor:r.next_cursor,
        noticesMore:r.has_more,noticesLoaded:true});
    } catch(error) {this.noticeRequestFailed(request,error);}
    finally {if(this.noticeRequestCurrent(request)){this._noticeRequest=null;this.setData({noticePending:false});}}
  },
  async markNoticeRead(e) {
    if(this._pageUnloaded||!this.session||this.data.pending)return;
    const context=this.prepareNoticeContext();
    if(this.data.noticePending)return;
    const id=e.currentTarget.dataset.id;
    const record=this.data.notices.find(notice=>notice.id===id);
    if(typeof id!=='string'||!/^[0-9a-f]{64}$/.test(id)||!record||record.read)return;
    const request={context};this._noticeRequest=request;this.setData({noticePending:true,noticeStatus:''});
    try {
      const r=await context.session.commerce(context.scene,'notice_read',{notice_id:id});
      if(!this.noticeRequestCurrent(request))return;
      if(!r||r.id!==id||r.read!==true)throw Error('通知已读状态未确认，请重试或刷新通知');
      this.setData({notices:this.data.notices.map(notice=>notice.id===id?{...notice,read:true}:notice)});
    } catch(error) {this.noticeRequestFailed(request,error);}
    finally {if(this.noticeRequestCurrent(request)){this._noticeRequest=null;this.setData({noticePending:false});}}
  },
  async profileAction(e) {
    if(e.currentTarget.dataset.operation==='notices')return this.loadNotices(e);
    if(this._pageUnloaded||this.data.pending||!this.session)return;
    const context={...this.prepareNoticeContext()};this._profileRequest=context;
    const current=()=>this._profileRequest===context&&this.noticeContextCurrent(context);
    this.setData({pending:true});
    try{const op=e.currentTarget.dataset.operation;let params={};
      if(op==='profile_update'){if(this.data.profileVersion===null)throw Error('先读取个人资料');params={nickname:this.data.nickname,contact:this.data.profileContact,expected_version:this.data.profileVersion};}
      else if(op==='referral_bind')params={code:this.data.referralCode};
      if(!['profile_read','profile_update','referral_code','referral_bind'].includes(op))throw Error('无效操作');
      if(op==='referral_code')this.setData({ownReferralCode:''});
      const r=await context.session.commerce(context.scene,op,params);
      if(!current())return;
      if(op==='profile_read'||op==='profile_update'){
        context.user=r.user_id;context.customer=r.project_customer_id;
        this.setData({profileVersion:r.version,nickname:r.nickname,profileContact:r.contact,userId:r.user_id,projectCustomerId:r.project_customer_id});
        this.prepareNoticeContext();
        if(this._projectMessagesContext)this.prepareProjectMessagesContext();
      }
      else if(op==='referral_code'){if(!r||typeof r.code!=='string'||!r.code)throw Error('本人推荐码返回未确认');this.setData({ownReferralCode:r.code});}
      this.setData({status:op==='referral_bind'?'推荐关系已绑定':'个人中心已更新'});
    }catch(error){if(current())this.setData({status:error.message});}
    finally{if(this._profileRequest===context&&!this._pageUnloaded&&this._pageGeneration===context.generation){this._profileRequest=null;this.setData({pending:false});}}
  },
  cancelConsumerRead(kind) {
    const request=this._consumerRequest;
    if(!request||request.mutating||request.kind!==kind)return false;
    this._consumerRequest=null;this.setData({pending:false});return true;
  },
  prepareConsumerRead() {
    const request=this._consumerRequest;
    if(request&&!request.mutating&&!this.consumerRequestCurrent(request))this.cancelConsumerRead(request.kind);
  },
  beginConsumerRequest(kind,mutating=false) {
    const request={...this.orderReadContext(),kind,mutating,
      refundGeneration:this._refundInputGeneration,communityGeneration:this._communityInputGeneration,
      application:this.data.refundApplication,amount:this.data.refundAmount,reason:this.data.refundReason,
      community:this.data.communityId,promotion:this.data.promotionCode};
    this._consumerRequest=request;this.setData({pending:true});return request;
  },
  consumerRequestCurrent(request) {
    return this._consumerRequest===request&&this.noticeContextCurrent(request)&&
      (request.kind!=='refund'||this.orderReadCurrent(request)&&request.refundGeneration===this._refundInputGeneration&&
        request.application===this.data.refundApplication&&request.amount===this.data.refundAmount&&request.reason===this.data.refundReason)&&
      (request.kind!=='community'||request.communityGeneration===this._communityInputGeneration&&
        request.community===this.data.communityId&&request.promotion===this.data.promotionCode);
  },
  finishConsumerRequest(request) {
    if(this.consumerRequestCurrent(request)){this._consumerRequest=null;this.setData({pending:false});}
  },
  inputCommunity(e) {
    if(this.data.pending&&!this.cancelConsumerRead('community'))return;
    const field=e.currentTarget.dataset.field;
    if(['communityId','promotionCode'].includes(field)){
      this._communityInputGeneration=(this._communityInputGeneration||0)+1;
      this.setData({[field]:e.detail.value});
    }
  },
  async communityAction(e) {
    if(this._pageUnloaded||!this.session)return;this.prepareConsumerRead();if(this.data.pending)return;
    const op=e.currentTarget.dataset.operation,more=e.currentTarget.dataset.more==='true';
    if(!['communities','community_mine','community_join','community_leave','promotion_redeem'].includes(op))return;
    if(op==='communities'&&more&&(!this.data.communitiesMore||!this.data.communityCursor))return;
    const request=this.beginConsumerRequest('community',!['communities','community_mine'].includes(op));
    if(op==='communities')this.setData({selectedCommunity:null});else this.setData({communityRelation:null});
    try{let params={};
      if(op==='communities')params={after_id:more?this.data.communityCursor:''};
      else if(op==='community_join'||op==='community_leave')params={community_id:e.currentTarget.dataset.id||request.community};
      else if(op==='promotion_redeem')params={code:request.promotion};
      const r=await request.session.commerce(request.scene,op,params);
      if(!this.consumerRequestCurrent(request))return;
      if(op==='communities'){
        if(!r||!Array.isArray(r.records)||typeof r.has_more!=='boolean'||
          (r.has_more?(typeof r.next_cursor!=='string'||!r.next_cursor||r.next_cursor===params.after_id):r.next_cursor!==null))throw Error('社区列表返回未确认');
        this.setData({selectedCommunity:null,communities:r.records,communityCursor:r.next_cursor,communitiesMore:r.has_more});
      }else{
        if(!r||typeof r.active!=='boolean'||r.active&&typeof r.community_id!=='string'||
          ['community_join','community_leave'].includes(op)&&r.community_id!==params.community_id)throw Error('社区关系返回未确认');
        request.community=r.active?r.community_id:'';
        this.setData({communityRelation:{active:r.active,community_id:r.active?r.community_id:''},communityId:request.community,status:r.active?'社区关系已确认':'当前未加入社区'});
      }
    }catch(error){if(this.consumerRequestCurrent(request)){const denied=error.code==='ACCESS_DENIED'||error.message==='SESSION_EXPIRED'||error.accessDenied===true;this.setData({...(denied?{selectedCommunity:null,communityRelation:null,communities:[],communityCursor:null,communitiesMore:false}:{}),status:error.message});}}
    finally{this.finishConsumerRequest(request);}
  },
  async reloadProducts(e) {
    if(this._pageUnloaded||this.data.pending||!this.session)return;
    if(this._productRequest&&this.noticeContextCurrent(this._productRequest.context))return;
    const more=e?.currentTarget?.dataset?.more==='true';
    if(more&&(!this.data.productsMore||!this.data.productCursor))return;
    const context={generation:this._pageGeneration,session:this.session,scene:this.scene,user:this.data.userId,
      customer:this.data.projectCustomerId,sessionGeneration:typeof this.session.getGeneration==='function'?this.session.getGeneration():undefined};
    const request={context,after:more?this.data.productCursor:''};this._productRequest=request;
    if(!more)this.setData({products:[],productCursor:null,productsMore:false});
    this.setData({productsPending:true,productsStatus:''});
    const current=()=>this._productRequest===request&&this.noticeContextCurrent(context);
    try {
      const r=await context.session.commerce(context.scene,'products',request.after?{after_id:request.after}:{});
      if(!current())return;
      if(!r||!Array.isArray(r.products)||r.products.some(p=>!p||typeof p.item_id!=='string'||!/^[A-Za-z0-9_-]{1,64}$/.test(p.item_id)||typeof p.name!=='string'||!Number.isSafeInteger(p.unit_minor)||p.unit_minor<1||!Number.isSafeInteger(p.revision)||p.revision<1||typeof p.available!=='boolean')||
        (r.has_more!==undefined&&typeof r.has_more!=='boolean')||(r.has_more&&(typeof r.next_cursor!=='string'||!r.next_cursor||r.next_cursor===request.after)))throw Error('商品分页结果无效，请刷新重试');
      const products=more?[...this.data.products]:[],known=new Set(products.map(p=>p.item_id));
      for(const product of r.products)if(!known.has(product.item_id)){known.add(product.item_id);products.push({...product,price_yuan:(product.unit_minor/100).toFixed(2),quantity:0});}
      this.setData({products,productCursor:r.has_more?r.next_cursor:null,productsMore:r.has_more===true,
        productsStatus:r.has_more?(r.products.length?'本页商品已加载，可继续加载更多':'本页没有可售商品，后续仍有商品待查'):products.length?'当前商品已全部加载':'当前没有可售商品'});
    } catch(error){if(current())this.setData({productsStatus:error.message+'；已有订单可继续查询和申请售后'});}
    finally {if(this._productRequest===request){this._productRequest=null;if(!this._pageUnloaded&&this._pageGeneration===context.generation)this.setData({productsPending:false});}}
  },
  async loadOrders(e) {
    if(!this.scene||this.session&&typeof this.session.customer==='function')return this.loadAllOrders(e);
    if(this._pageUnloaded||!this.session)return;this.prepareConsumerRead();if(this.data.pending)return;
    const more=e?.currentTarget?.dataset?.more==='true';
    if(more&&(!this.data.ordersMore||!this.data.orderCursor))return;
    const request=this.beginConsumerRequest('orders');this.setData({ordersState:'LOADING',ordersError:''});
    try{
      const r=await request.session.commerce(request.scene,'orders',{after_id:more?this.data.orderCursor:''});
      if(!this.consumerRequestCurrent(request))return;
      if(!r||!Array.isArray(r.records)||typeof r.has_more!=='boolean'||
        (r.has_more?(typeof r.next_cursor!=='string'||!r.next_cursor):r.next_cursor!==null))throw Error('订单列表返回未确认');
      const orders=this.withOrderVisibility(r.records.map(r=>({...displayOrder(r,this.data.orderFilter),scene:request.scene,key:request.scene+':'+r.reference})));
      this.setData({ordersState:r.has_more?'PARTIAL':'READY',visibleOrderCount:orders.filter(x=>x.visible).length,orders,orderCursor:r.next_cursor,ordersMore:r.has_more});
    }catch(error){if(this.consumerRequestCurrent(request))this.setData({ordersState:'FAILED',ordersError:error.message,status:error.message});}
    finally{this.finishConsumerRequest(request);}
  },
  resetOrderDetails() {
    this._orderSelectionGeneration=(this._orderSelectionGeneration||0)+1;
    this._orderDetailsRequest=null;this._refundRecoveryRequest=null;
    if(this._purchaseRecoveryRequest)this.setData({pending:false});
    this._purchaseRecoveryRequest=null;
    this.setData({orderDetails:null,detailsCollapsed:false,orderDetailsPending:false,orderDetailsStatus:'',
      refundCurrent:null,refundRecoveryLoaded:false,refundRecoveryPending:false,refundRecoveryStatus:'',
      refundApplication:'',refundAmount:'',refundReason:''});
  },
  orderReadContext() {
    return {generation:this._pageGeneration,session:this.session,scene:this.scene,
      user:this.data.userId,customer:this.data.projectCustomerId,
      sessionGeneration:typeof this.session.getGeneration==='function'?this.session.getGeneration():undefined,
      reference:this.data.reference,selection:this._orderSelectionGeneration};
  },
  orderReadCurrent(context) {
    return this.noticeContextCurrent(context)&&context.reference===this.data.reference&&context.selection===this._orderSelectionGeneration;
  },
  async recoverPurchase() {
    if(this._pageUnloaded||!this.session||this.data.pending||!this.data.commerceEnabled||
      typeof this.data.reference!=='string'||!/^[A-Za-z0-9_-]{1,64}$/.test(this.data.reference))return;
    const request=this.orderReadContext();this._purchaseRecoveryRequest=request;
    this.setData({pending:true,afterAd:'',afterAdVerified:false,status:'正在恢复原商品订单；保留原订单编号'});
    const current=()=>this._purchaseRecoveryRequest===request&&this.orderReadCurrent(request);
    try {
      const r=await request.session.commerce(request.scene,'purchase_recover',{reference:request.reference});
      if(!current())return;
      if(!r||r.reference!==request.reference||(request.user&&r.user_id!==request.user)||
        !Number.isSafeInteger(r.amount_minor)||r.amount_minor<1||r.currency!=='CNY'||
        !r.order||!['PENDING','SUCCESS','FAILED','CANCELLED','REFUNDED'].includes(r.order.state)||
        r.order.amount_minor!==r.amount_minor||r.order.currency!==r.currency||
        !Array.isArray(r.lines)||r.lines.length<1||r.lines.length>50||
        r.lines.some(line=>!line||typeof line.item_id!=='string'||typeof line.name!=='string'||
          !Number.isSafeInteger(line.revision)||line.revision<1||!Number.isSafeInteger(line.quantity)||line.quantity<1||
          !Number.isSafeInteger(line.unit_minor)||line.unit_minor<1||!Number.isSafeInteger(line.subtotal_minor)||
          line.subtotal_minor!==line.quantity*line.unit_minor)||
        new Set(r.lines.map(line=>line.item_id)).size!==r.lines.length||
        r.lines.reduce((total,line)=>total+line.subtotal_minor,0)!==r.amount_minor)
        throw Error('原订单恢复结果未确认');
      this.setData({amount:yuanAmount(r.amount_minor),status:'原商品订单：'+r.order.state+'；未发起支付，金额来自原商品快照',
        orders:this.withOrderVisibility(this.data.orders.map(order=>order.scene===request.scene&&order.reference===request.reference?{...order,order:{...r.order,state_label:orderStateLabel(r.order.state),amount_yuan:yuanAmount(r.order.amount_minor)},lines:r.lines.map(line=>({...line,unit_yuan:yuanAmount(line.unit_minor),subtotal_yuan:yuanAmount(line.subtotal_minor)}))}:order))});
      this.setData({visibleOrderCount:this.data.orders.filter(x=>x.visible).length});
    } catch(error) {if(current())this.setData({status:error.message+'；保留原订单编号，可再次显式恢复，勿重新下单'});}
    finally {if(current()){this._purchaseRecoveryRequest=null;this.setData({pending:false});}}
  },
  async loadOrderDetails() {
    if(this._pageUnloaded||!this.session||this.data.pending||!this.data.commerceEnabled||
      typeof this.data.reference!=='string'||!/^[A-Za-z0-9_-]{1,64}$/.test(this.data.reference))return;
    if(this._orderDetailsRequest&&this.orderReadCurrent(this._orderDetailsRequest))return;
    const request=this.orderReadContext();this._orderDetailsRequest=request;
    this.setData({orderDetails:null,detailsCollapsed:false,orderDetailsPending:true,orderDetailsStatus:''});
    try {
      const r=await request.session.commerce(request.scene,'purchase_read',{reference:request.reference});
      if(this._orderDetailsRequest!==request||!this.orderReadCurrent(request))return;
      if(!r||r.reference!==request.reference||(request.user&&r.user_id!==request.user)||
        !Array.isArray(r.lines)||r.lines.length<1||r.lines.length>50||
        !Number.isSafeInteger(r.amount_minor)||r.amount_minor<1||r.currency!=='CNY'||
        !r.order||typeof r.order.state!=='string'||r.order.amount_minor!==r.amount_minor||r.order.currency!==r.currency||
        r.lines.some(line=>!line||typeof line.item_id!=='string'||typeof line.name!=='string'||
          !Number.isSafeInteger(line.revision)||line.revision<1||!Number.isSafeInteger(line.quantity)||line.quantity<1||
          !Number.isSafeInteger(line.unit_minor)||line.unit_minor<1||!Number.isSafeInteger(line.subtotal_minor)||
          line.subtotal_minor!==line.quantity*line.unit_minor)||
        new Set(r.lines.map(line=>line.item_id)).size!==r.lines.length||
        r.lines.reduce((total,line)=>total+line.subtotal_minor,0)!==r.amount_minor)
        throw Error('原订单商品快照未确认，请重新读取当前订单');
      this.setData({orderDetails:{reference:r.reference,amount_minor:r.amount_minor,amount_yuan:yuanAmount(r.amount_minor),currency:r.currency,state_label:orderStateLabel(r.order.state),
        lines:r.lines.map(line=>({item_id:line.item_id,name:line.name,revision:line.revision,
          quantity:line.quantity,unit_minor:line.unit_minor,unit_yuan:yuanAmount(line.unit_minor),subtotal_minor:line.subtotal_minor,subtotal_yuan:yuanAmount(line.subtotal_minor)})),
        order_state:r.order.state,fulfillment_state:typeof r.fulfillment_state==='string'?r.fulfillment_state:'',
        fulfillment_revision:Number.isSafeInteger(r.fulfillment_revision)?r.fulfillment_revision:null,
        completion_note:typeof r.completion_note==='string'?r.completion_note:'',
        completed_at:Number.isSafeInteger(r.completed_at)?r.completed_at:null}});
    } catch(error) {if(this._orderDetailsRequest===request&&this.orderReadCurrent(request))this.setData({orderDetailsStatus:error.message});}
    finally {if(this._orderDetailsRequest===request&&!this._pageUnloaded&&this._pageGeneration===request.generation){this._orderDetailsRequest=null;this.setData({orderDetailsPending:false});}}
  },
  async recoverRefundApplication() {
    if(this._pageUnloaded||!this.session||this.data.pending||!this.data.commerceEnabled||
      typeof this.data.reference!=='string'||!/^[A-Za-z0-9_-]{1,64}$/.test(this.data.reference))return;
    if(this._refundRecoveryRequest&&this.orderReadCurrent(this._refundRecoveryRequest))return;
    const request=this.orderReadContext();request.inputGeneration=this._refundInputGeneration;
    request.form={application:this.data.refundApplication,amount:this.data.refundAmount,reason:this.data.refundReason,status:this.data.status};
    this._refundRecoveryRequest=request;
    this.setData({refundCurrent:null,refundRecoveryLoaded:false,refundRecoveryPending:true,refundRecoveryStatus:''});
    const current=()=>this._refundRecoveryRequest===request&&this.orderReadCurrent(request)&&request.inputGeneration===this._refundInputGeneration&&
      !this.data.pending&&this.data.status===request.form.status&&this.data.refundApplication===request.form.application&&
      this.data.refundAmount===request.form.amount&&this.data.refundReason===request.form.reason;
    try {
      const r=await request.session.commerce(request.scene,'refund_current',{reference:request.reference});
      if(!current())return;
      if(!r||r.reference!==request.reference||!Object.prototype.hasOwnProperty.call(r,'application'))throw Error('原售后申请尚未确认，请重试');
      const a=r.application;
      if(a===null){this.setData({refundCurrent:null,refundRecoveryLoaded:true,refundApplication:'',refundAmount:'',refundReason:''});return;}
      if(!a||a.reference!==request.reference||(request.user&&a.user_id!==request.user)||
        typeof a.application_id!=='string'||!/^[A-Za-z0-9_-]{1,64}$/.test(a.application_id)||
        !Number.isSafeInteger(a.revision)||a.revision<1||!Number.isSafeInteger(a.amount_minor)||a.amount_minor<1||
        typeof a.reason!=='string'||typeof a.status!=='string'||!a.status||typeof a.opinion!=='string')
        throw Error('原售后申请绑定或版本未确认，请重试');
      this.setData({refundCurrent:{reference:a.reference,application_id:a.application_id,revision:a.revision,
        amount_minor:a.amount_minor,amount_yuan:yuanAmount(a.amount_minor),reason:a.reason,status:a.status,opinion:a.opinion},
        refundRecoveryLoaded:true,refundApplication:a.application_id,refundAmount:yuanAmount(a.amount_minor),refundReason:a.reason});
    } catch(error) {if(current())this.setData({refundRecoveryStatus:error.message});}
    finally {if(this._refundRecoveryRequest===request&&!this._pageUnloaded&&this._pageGeneration===request.generation){this._refundRecoveryRequest=null;this.setData({refundRecoveryPending:false});}}
  },
  async selectOrder(e) {
    if(this.data.pending)return;
    const reference=e.currentTarget.dataset.reference,chosenScene=e.currentTarget.dataset.scene;
    if(typeof reference!=='string'||!/^[A-Za-z0-9_-]{1,64}$/.test(reference))return;
    if(chosenScene){
      const found=this.data.orders.find(r=>r.scene===chosenScene&&r.reference===reference);if(!found)return;
      if(this.scene!==chosenScene||!this.client){
        const identity=this.customerReadToken();
        this.customerSessionRevoked('正在打开订单详情',false);getApp().globalData.scene=chosenScene;
        await this.onLoad({scene:chosenScene,view:'services'});
        if(this._pageUnloaded||!auth.active(identity.epoch)||this.session!==identity.session||identity.session.getGeneration&&identity.session.getGeneration()!==identity.sessionGeneration||!this.data.sessionReady)return;
      }
    }
    this.resetOrderDetails();if(this.paymentFlow)this.paymentFlow.reset();if(this.client)this.client.reset();
    this.setData({viewMode:'orders',activeSection:'orders',reference,refundApplication:'',afterAd:'',afterAdVerified:false},()=>this.loadOrderDetails());
  },
  backToOrderList(){this.resetOrderDetails();this.setData({reference:'',refundApplication:'',refundAmount:'',refundReason:'',status:'已返回本人订单列表'});if(this.session&&typeof this.session.customer==='function')return this.loadOrders();},
  inputRefund(e) {
    if(this.data.pending&&!this.cancelConsumerRead('refund'))return;
    const field=e.currentTarget.dataset.field;
    if(['refundAmount','refundReason','refundApplication'].includes(field)){
      this._refundInputGeneration=(this._refundInputGeneration||0)+1;this.setData({[field]:e.detail.value});
    }
  },
  async refundAction(submit) {
    if(this._pageUnloaded||!this.session||submit&&!this.data.commerceEnabled)return;
    this.prepareConsumerRead();if(this.data.pending)return;
    if(submit&&!this.data.refundApplication)this.setData({refundApplication:'ra_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,14)});
    const request=this.beginConsumerRequest('refund',submit);
    try{
      const params={reference:request.reference,application_id:request.application};
      if(submit){const amount=minorAmount(request.amount);if(amount===null)throw Error('退款金额请输入最多两位小数的元金额');Object.assign(params,{amount_minor:amount,reason:request.reason});}
      const r=await request.session.commerce(request.scene,submit?'refund_apply':'refund_application',params);
      if(!this.consumerRequestCurrent(request))return;
      if(!r||r.reference!==request.reference||r.application_id!==request.application||
        request.user&&r.user_id!==request.user||typeof r.status!=='string'||!r.status||typeof r.opinion!=='string'||
        !Number.isSafeInteger(r.revision)||r.revision<1)throw Error('原退款申请绑定或版本未确认');
      this.setData({status:'退款申请：'+r.status+(submit?'；编号 '+r.application_id:' '+r.opinion)});
    }catch(error){if(this.consumerRequestCurrent(request))this.setData({status:error.message+(submit?'；保留原申请编号查询':'')});}
    finally{this.finishConsumerRequest(request);}
  },
  async requestRefund() {return this.refundAction(true);},
  async refundStatus() {return this.refundAction(false);},
  inputAmount(e) {if(this.paymentFlow)this.paymentFlow.reset();if(this.client)this.client.reset();this.clearReceiptAd(true);this.setData({amount:e.detail.value});},
  inputReference(e) {if(this.data.pending&&!this._purchaseRecoveryRequest&&!this.cancelConsumerRead('refund'))return;this.resetOrderDetails();if(this.paymentFlow)this.paymentFlow.reset();if(this.client)this.client.reset();this.clearReceiptAd(true);this.setData({reference:e.detail.value});},
  async checkout() {
    if (this.data.pending||this.data.productsPending) return;
    if (!this.client) return this.setData({status:'请先完成登录与门店绑定'});
    this.clearReceiptAd(true);
    this.setData({pending:true,afterAd:'',afterAdVerified:false,status:this.data.commerceEnabled?'正在创建订单':'正在创建模拟订单'});
    try {if(this.data.commerceEnabled){const lines=this.data.products.filter(p=>p.quantity>0).map(p=>({item_id:p.item_id,revision:p.revision,quantity:p.quantity}));const r=await this.session.commerce(this.scene,'purchase',{reference:this.data.reference,lines});this.setData({amount:yuanAmount(r.amount_minor)});}else{const amount=minorAmount(this.data.amount);if(amount===null)throw Error('金额请输入最多两位小数的元金额');await this.client.checkout(String(amount),this.data.reference);}this.setData({status:this.data.paymentsEnabled?'订单已建立，请点击微信支付':(this.data.commerceEnabled?'订单已建立，支付尚未开放；未发生扣款':'模拟待支付；不发起微信扣款')});}
    catch(e) {this.setData({status:e.message});}
    finally {this.setData({pending:false});}
  },
  async cancelOrder() {
    if(this.data.pending||!this.session)return;this.clearReceiptAd(true);this.setData({pending:true,afterAd:'',afterAdVerified:false});
    try{const r=await this.session.payment(this.scene,'cancel',this.data.reference);if(this.paymentFlow)this.paymentFlow.reset();this.setData({status:r.order_state==='CANCELLED'?'订单已取消，库存已恢复或可按原订单恢复处理':r.order_state+'；以服务端确认状态为准'});}
    catch(e){this.setData({status:e.message+'；请查询原订单，不要重新提交资金操作'});}finally{this.setData({pending:false});}
  },
  async pay() {return this.runPayment(false);},
  async recoverPayment() {return this.runPayment(true);},
  checkoutReadToken(){return {...this.customerReadToken(),scene:this.scene,reference:this.data.reference,checkoutGeneration:this._checkoutReadGeneration||0};},
  checkoutReadCurrent(request){return request.checkoutGeneration===(this._checkoutReadGeneration||0)&&!this._sceneStale&&this.scene===request.scene&&this.data.reference===request.reference&&
    (request.session?this.customerReadCurrent(request)&&(!request.session.isAuthenticated||request.session.isAuthenticated()):!this.session&&!this._pageUnloaded&&this._pageGeneration===request.generation);},
  clearReceiptAd(cancelRead=false){if(cancelRead)this._checkoutReadGeneration=(this._checkoutReadGeneration||0)+1;this._receiptAdRequest=null;this.setData({afterAd:'',afterAdImage:'',afterAdVerified:false});},
  async loadReceiptAd(request){
    if(!this.checkoutReadCurrent(request)||!this.data.commerceEnabled||!request.session)return false;
    this.clearReceiptAd();this._receiptAdRequest=request;
    const current=()=>this._receiptAdRequest===request&&this.checkoutReadCurrent(request);
    try{
      const reply=await request.session.commerce(request.scene,'receipt_ad',{reference:request.reference});
      if(!current()||!reply||reply.payment_success_verified!==true)return false;
      const ad=reply.creative;
      if(ad&&ad.slot==='AD_SLOT_PAYMENT_SUCCESS'&&typeof ad.title==='string'&&ad.title.trim())
        this.setData({afterAd:ad.title,afterAdImage:typeof ad.image_data==='string'?ad.image_data:'',afterAdVerified:true});
      return true;
    }catch(_){return false;} // Optional advertising never changes the payment result.
    finally{if(this._receiptAdRequest===request)this._receiptAdRequest=null;}
  },
  async runPayment(recover) {
    if(this.data.pending||!this.paymentFlow)return;
    this.clearReceiptAd(true);
    const request=this.checkoutReadToken(),flow=this.paymentFlow;
    const current=()=>this.checkoutReadCurrent(request)&&this.paymentFlow===flow;
    this.setData({pending:true,status:recover?'正在恢复原支付单':'正在准备微信支付'});
    try {const r=await flow.pay(request.reference,recover);if(current())await this.showPayment(r,request);}
    catch(e){if(current())this.setData({status:e.message+'；请查询原订单，勿重新创建支付单'});}
    finally{if(this.customerReadCurrent(request)&&this.scene===request.scene&&this.paymentFlow===flow)this.setData({pending:false});}
  },
  async showPayment(r,request=this.checkoutReadToken()) {
    if(!this.checkoutReadCurrent(request))return;
    this.clearReceiptAd();
    if(!r||r.reference!==request.reference||r.provider_signature_verified!==true)throw Error('UNTRUSTED_PAYMENT_QUERY');
    this.setData({amount:yuanAmount(r.amount_minor),status:r.provider_state==='SUCCESS'?'微信查单已支付；财务尚未核销':r.provider_state+'；财务尚未核销'});
    if(r.provider_state==='SUCCESS')await this.loadReceiptAd(request);
  },
  async queryPayment() {
    if(this.data.pending||!this.paymentFlow)return;
    this.clearReceiptAd(true);
    const request=this.checkoutReadToken(),flow=this.paymentFlow;
    const current=()=>this.checkoutReadCurrent(request)&&this.paymentFlow===flow;
    this.setData({pending:true});
    try{const result=await flow.query(request.reference);if(current())await this.showPayment(result,request);}
    catch(e){if(current())this.setData({status:e.message+'；支付结果未知'});}
    finally{if(this.customerReadCurrent(request)&&this.scene===request.scene&&this.paymentFlow===flow)this.setData({pending:false});}
  },
  async refresh() {
    if (!this.client) return this.setData({status:'请先完成登录与门店绑定'});
    this.clearReceiptAd(true);
    const request=this.checkoutReadToken(),client=this.client;
    const current=()=>this.checkoutReadCurrent(request)&&this.client===client;
    try {
      if(this.data.commerceEnabled){
        const result=await request.session.commerce(request.scene,'purchase_read',{reference:request.reference});
        if(!current())return;
        if(!result||result.reference!==request.reference||!result.order||!Number.isSafeInteger(result.amount_minor)||result.amount_minor<1||result.amount_minor!==result.order.amount_minor||result.order.currency!=='CNY')throw Error('UNTRUSTED_ORDER_READ');
        this.setData({amount:yuanAmount(result.amount_minor),status:result.order.state+'；金额来自服务端商品快照'});
        if(result.order.state==='SUCCESS'&&await this.loadReceiptAd(request)&&current())
          this.setData({status:'服务端核验已支付；财务尚未核销'});
        return;
      }
      const result=await client.resume(request.reference);if(!current())return;
      const verified=result.simulation_only===false&&result.provider_order_verified===true&&
        result.provider_payment_verified===true&&result.order.state==='SUCCESS';
      const creative=verified&&result.ads.AD_SLOT_PAYMENT_SUCCESS;
      const ad=creative&&creative.slot==='AD_SLOT_PAYMENT_SUCCESS'&&typeof creative.title==='string'?creative:null;
      this.setData({amount:yuanAmount(result.order.amount_minor),
        status:verified?'服务端核验已支付；财务尚未核销':result.payment_state+(result.simulation_only?'（模拟，非收款凭证）':'；财务尚未核销'),
        afterAd:ad?ad.title:'',afterAdImage:ad&&typeof ad.image_data==='string'?ad.image_data:'',afterAdVerified:!!ad});
    }catch(e){if(current())this.setData({status:e.message});}
  }
});
