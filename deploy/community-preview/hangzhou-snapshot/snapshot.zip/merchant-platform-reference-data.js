module.exports={"appid":"wx1d5f8873eaea5392","source":"original project.config.json","source_sha256":"f4c54ebb7008745a7b358ef68d27c43b63a64c2ea74684bd5c1d6589bc9514dc"};
