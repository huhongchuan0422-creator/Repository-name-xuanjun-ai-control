"""Local staged delivery ledger."""
