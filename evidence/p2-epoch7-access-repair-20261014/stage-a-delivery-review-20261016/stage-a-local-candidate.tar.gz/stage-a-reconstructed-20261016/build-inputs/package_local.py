"""Deterministic local source handoff. No publication or network action.

Run only after final pins and successful validation receipts exist. All inputs
are read-only; only ci-candidate/handoff output files are created or replaced.
"""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile
import types

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
PREFIX='stage-a-reconstructed-20261016'


def digest(raw):return hashlib.sha256(raw).hexdigest()

def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')+b'\n'

def load_gate():
    path=HERE/'tests/test_p2_stage_a_saved_reporter.py'
    value=types.ModuleType('local_package_gate');value.__file__=str(path)
    exec(compile(path.read_bytes(),str(path),'exec'),value.__dict__)
    value.publication_pins()
    return value


def main():
    gate=load_gate();files={};roles={};source_paths={}
    def include(name,path,role,expected=None):
        if name in files or name.startswith('/') or '\\' in name or any(x in ('','.','..') for x in name.split('/')):
            raise ValueError('PACKAGE_PATH')
        path=Path(path)
        if path.is_symlink() or not path.is_file():raise ValueError('PACKAGE_REGULAR_SOURCE_REQUIRED')
        raw=path.read_bytes()
        if expected is not None and (len(raw),digest(raw))!=expected:raise ValueError('PACKAGE_FROZEN_SOURCE_CHANGED')
        files[name]=raw;roles[name]=role;source_paths[name]=path
    pub_prefix='evidence/p2-epoch7-access-repair-20261014/'
    for source,(size,pin,target) in sorted(gate.PINS.items()):
        if source.startswith(pub_prefix+'stage-a-saved-reporter/'):
            include('publication/'+source,ROOT/'reporter-candidate'/source.rsplit('/',1)[1],'new_publication_source',(size,pin))
        elif source.startswith(pub_prefix+'stage-a-saved-coverage/'):
            include('publication/'+source,ROOT/'coverage-candidate'/source.rsplit('/',1)[1],'new_publication_source',(size,pin))
        else:
            include('dependencies/'+source,ROOT/'baseline'/source,'exact_published_public_dependency',(size,pin))
    include('dependencies/'+gate.ARCHIVE_PATH,ROOT/'baseline'/gate.ARCHIVE_PATH,'exact_published_r7_archive',(gate.ARCHIVE_SIZE,gate.ARCHIVE_SHA))
    for source in (gate.GATE_PATH,gate.CONTRACT_PATH,gate.WORKFLOW_PATH,gate.REGISTRY_PATH):
        include('publication/'+source,HERE/source,'new_publication_source')
    for name in ('OWNER_COMMAND_NOT_READY.txt','test_owner_bootstrap.py'):
        include('bootstrap/'+name,ROOT/'bootstrap-candidate'/name,'local_only_bootstrap')
    for name in ('build_reporter.py','reporter_body.py.inc'):
        include('build-inputs/reporter-candidate/'+name,ROOT/'reporter-candidate'/name,'local_only_reproducible_build_input')
    include('build-inputs/BUILD_LAYOUT.md',HERE/'BUILD_LAYOUT.md','local_only_build_layout')
    include('build-inputs/package_local.py',HERE/'package_local.py','local_only_package_builder')
    receipt=json.loads((HERE/'final-validation.json').read_text())
    if receipt.get('state')!='PASS' or receipt.get('publication_commit')!='UNBOUND' or receipt.get('hosted_ci')!='NOT_RUN':
        raise ValueError('FINAL_LOCAL_VALIDATION_REQUIRED')
    if receipt.get('suite_counts')!=dict(gate.SUITES):raise ValueError('FINAL_SUITE_COUNTS_CHANGED')
    for path in (gate.WORKFLOW_PATH,gate.REGISTRY_PATH):
        expected=(gate.WORKFLOW_SIZE,gate.WORKFLOW_SHA) if path==gate.WORKFLOW_PATH else (gate.REGISTRY_SIZE,gate.REGISTRY_SHA)
        raw=files['publication/'+path]
        if (len(raw),digest(raw))!=expected:raise ValueError('FINAL_METADATA_CHANGED')
    for name,row in receipt['frozen_source_files'].items():
        raw=files['publication/'+name]
        if (len(raw),digest(raw))!=(row['bytes'],row['sha256']):raise ValueError('FINAL_VALIDATED_SOURCE_CHANGED')
    for name,row in receipt['frozen_bootstrap_files'].items():
        raw=files['bootstrap/'+name]
        if (len(raw),digest(raw))!=(row['bytes'],row['sha256']):raise ValueError('FINAL_BOOTSTRAP_CHANGED')
    for name,row in receipt['frozen_build_inputs'].items():
        raw=files['build-inputs/reporter-candidate/'+name]
        if (len(raw),digest(raw))!=(row['bytes'],row['sha256']):raise ValueError('FINAL_BUILD_INPUT_CHANGED')
    for name,row in receipt['passing_logs'].items():
        include('verification/'+name,HERE/name,'passing_local_validation_log',(row['bytes'],row['sha256']))
    for name,row in receipt['parent_passing_logs'].items():
        include('verification/'+name,ROOT/'evidence'/name,'passing_parent_local_validation_log',(row['bytes'],row['sha256']))
    include('verification/final-validation.json',HERE/'final-validation.json','local_validation_receipt')
    include('README.md',ROOT/'reporter-candidate/README.md','deliverable_scope_and_reproduction_notes')
    if len([name for name in files if name.startswith('publication/')])!=9:raise ValueError('EXACT_NINE_PUBLICATION_FILES')
    inventory={name:{'bytes':len(raw),'sha256':digest(raw),'role':roles[name]} for name,raw in sorted(files.items())}
    manifest={'schema':1,'kind':'STAGE_A_RECONSTRUCTED_LOCAL_SOURCE_HANDOFF','state':'LOCAL_VALIDATED_PUBLICATION_UNBOUND',
        'baseline_commit':'609407afa118c527299f33885d82b6acc1c020fb','publication_commit':'UNBOUND',
        'source_maps':gate.SOURCE_TARGETS,'suite_counts':dict(gate.SUITES),'hosted_ci':'NOT_RUN','host':'NOT_RUN',
        'network':'NOT_RUN','new_probe':'NOT_RUN','private_plan':'NOT_READ','production_resume':'NOT_EXECUTED',
        'bootstrap_commit_binding':'LOCAL_ONLY_AFTER_SINGLE_VERIFIED_PUBLICATION_COMMIT','files':inventory}
    files['MANIFEST.json']=canonical(manifest)
    # A read-only source check after collecting all entries prevents mixed snapshots.
    for name,path in source_paths.items():
        if path.read_bytes()!=files[name]:raise ValueError('PACKAGE_SOURCE_CHANGED')
    output=io.BytesIO()
    with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0,compresslevel=9) as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as archive:
            for name,raw in sorted(files.items()):
                info=tarfile.TarInfo(PREFIX+'/'+name);info.size=len(raw);info.mode=0o644;info.mtime=0
                info.uid=info.gid=0;info.uname=info.gname=''
                archive.addfile(info,io.BytesIO(raw))
    raw=output.getvalue()
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
        members=archive.getmembers()
        if [row.name for row in members]!=[PREFIX+'/'+name for name in sorted(files)]:raise ValueError('PACKAGE_INVENTORY')
        for row in members:
            if not row.isreg() or archive.extractfile(row).read()!=files[row.name[len(PREFIX)+1:]]:raise ValueError('PACKAGE_READBACK')
    dest=HERE/'handoff';dest.mkdir(exist_ok=True)
    target=dest/'stage-a-local-candidate.tar.gz';target.write_bytes(raw)
    external_manifest=dict(manifest)
    external_manifest['kind']='STAGE_A_RECOVERY_ARCHIVE_MANIFEST'
    external_manifest['archive']={'file':target.name,'bytes':len(raw),'sha256':digest(raw),'members':len(files)}
    external_manifest['files']={name:{'bytes':len(body),'sha256':digest(body),'role':roles.get(name,'embedded_inventory_manifest')} for name,body in sorted(files.items())}
    external_raw=canonical(external_manifest)
    (dest/'MANIFEST.json').write_bytes(external_raw)
    receipt={'schema':1,'archive_file':target.name,'archive_bytes':len(raw),'archive_sha256':digest(raw),
        'manifest_bytes':len(external_raw),'manifest_sha256':digest(external_raw),
        'archive_members':len(files),'publication_files':9,'publication_commit':'UNBOUND','verified_roundtrip':True}
    (dest/'ARCHIVE_RECEIPT.json').write_bytes(canonical(receipt))
    print(json.dumps(receipt,sort_keys=True))


if __name__=='__main__':main()
