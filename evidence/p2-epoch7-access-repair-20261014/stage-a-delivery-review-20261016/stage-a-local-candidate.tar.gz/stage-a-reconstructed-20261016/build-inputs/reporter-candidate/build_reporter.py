"""Local deterministic generator; never used on the target host."""
import base64,hashlib,json,pathlib,zlib
root=pathlib.Path(__file__).resolve().parent.parent
here=root/'reporter-candidate';base=root/'baseline/evidence/p2-epoch7-access-repair-20261014'
exporter=(base/'saved-evidence-r7/export_saved_evidence.py').read_bytes()
assert hashlib.sha256(exporter).hexdigest()=='a436d97072bf0062a94f9ccbd030aef1a08214f12f74645efd12d89d9f464815'
mapper=(root/'coverage-candidate/saved_authority_coverage.py').read_bytes()
packet_raw=(base/'saved-evidence-r7-actual-20261015/packet.json').read_bytes()
assert hashlib.sha256(packet_raw).hexdigest()=='45b832dce9577b49e6ee718f1637862eebd775c6c10f87d9150ed0a87476fdf7'
packet=json.loads(packet_raw);body_raw=packet_raw[292914:292914+1928]
assert hashlib.sha256(body_raw).hexdigest()=='37ee583dfda581361caf38e8cccf5ffb9b25f28c8f732e17e0cbf6e72982c9b7'
assert json.loads(body_raw)==packet['unsigned_expected_review_body']
def pack(raw):return {'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'zlib_base64':base64.b64encode(zlib.compress(raw,9)).decode('ascii')}
names=('epoch7_snapshot.py','observe_epoch7.py','snapshot_io.py','unit_metadata.py','probe_driver.py','probe_helpers.py','epoch7_host_factory.py','epoch7_acceptance_rows.py','node_sqlite_probe.py')
pins={name:hashlib.sha256((root/'kit/epoch7-recovery-candidate-r7/helpers'/name).read_bytes()).hexdigest() for name in names}
body=(here/'reporter_body.py.inc').read_bytes()
seven={key:packet[key] if key in ('topology_sha256','expected_review_body_sha256') else packet['bindings'][key] for key in ('probe_policy_sha256','probe_input_sha256','probe_receipt_sha256','evidence_records_sha256','saved_unit_dropins_sha256','topology_sha256','expected_review_body_sha256')}
constants={'EMBEDDED_EXPORTER':pack(exporter),'EMBEDDED_MAPPER':pack(mapper),'ORIGINAL_BODY_BASE64':base64.b64encode(body_raw).decode('ascii'),'EXPECTED_BINDINGS':packet['bindings'],'EXPECTED_SEVEN':seven,'OBSERVER_SOURCES':pins,'REPORTER_BODY_BYTES':body}
lines=['# Generated locally from independently pinned published dependencies; no approval.']+[key+'='+repr(value) for key,value in constants.items()]
raw=('\n'.join(lines)+'\n').encode()+body
compile(raw,str(here/'report_saved_stage_a.py'),'exec');(here/'report_saved_stage_a.py').write_bytes(raw)
print(len(raw),hashlib.sha256(raw).hexdigest())
