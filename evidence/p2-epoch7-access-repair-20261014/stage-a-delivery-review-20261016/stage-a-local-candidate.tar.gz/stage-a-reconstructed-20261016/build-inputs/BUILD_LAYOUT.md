# Reproduce this local candidate

This archive contains a new reconstruction. No vanished candidate hash or historical PASS establishes these bytes. Publication remains unbound; all hosted, retained-host, new-probe, private-plan, install and resume actions remain unexecuted.

## Integrity and member scope

The external MANIFEST.json pins every archive member, including the embedded inventory manifest. ARCHIVE_RECEIPT.json pins the complete archive and external manifest. Verify both before reading source. Tar members are only regular files, with fixed ownership, mode and timestamp. Working notes, consent drafts, failed/intermediate logs, credentials, bytecode and Git directories are excluded.

publication/ contains exactly the nine proposed publication files. dependencies/ contains the nine exact previously published fixture modules, actual public packet, and R7 archive. bootstrap/ is local-only. build-inputs/ contains the generator/body and packaging/reproduction tools. verification/ contains successful local logs and a combined receipt that also discloses earlier nonpassing invocations without including their raw logs.

## Reproduce the exact-checkout gate

In a new disposable directory, combine publication/ and dependencies/ while retaining their relative paths. There must be no conflicting paths. Create a local synthetic Git commit of those 20 files; no remote, original repository or published ref is needed. Use an existing Python interpreter and run these commands from that disposable checkout:

    mkdir -m 700 ../local-ci-temp
    export TMPDIR="$(cd ../local-ci-temp && pwd)" RUNNER_TEMP="$(cd ../local-ci-temp && pwd)"
    export PYTHONDONTWRITEBYTECODE=1 GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null
    python -I -B -S tests/test_p2_stage_a_saved_reporter_contract.py -v
    python -I -B -S tests/test_p2_stage_a_saved_reporter.py -v

The gate authenticates and materializes its full fixture closure itself. It runs reporter43 and coverage66 only, for an aggregate109; contract37 and two outer gate tests are separate. Existing runtime/preparation suite classes are fixture imports, not additional executed suites. Successful local runs used Python3.6.8 and3.12.14 with a private TMPDIR/RUNNER_TEMP matching the workflow's staging approach. An earlier3.6 invocation using ambient /tmp crashed in ctypes during import before tests; its cause is not conclusively resolved, and that invocation was not a PASS. No safety mechanics were changed to obtain the successful runs.

## Regenerate the reporter

Create another disposable workspace with this layout:

- baseline/evidence/... copied from dependencies/evidence/...
- coverage-candidate/saved_authority_coverage.py copied from the corresponding publication path
- reporter-candidate/build_reporter.py and reporter_body.py.inc copied from build-inputs/reporter-candidate/
- kit/epoch7-recovery-candidate-r7/ containing the authenticated R7 archive's files

Authenticate the archive before extraction using archive_files() from the pinned gate, then write only the returned finite relative files into the new exclusive kit directory. Do not use an unauthenticated extraction. Run python -I -B -S reporter-candidate/build_reporter.py. The generated report_saved_stage_a.py must be93,912bytes with SHA-2568ebd1ae2d572818677e5e404647f2d53ddae40f3aafa32320dcaf36d7384bde0. This exact regeneration passed using both local interpreters.

## Bootstrap tests and future binding

Set STAGE_A_REPORTER_SOURCE to the verified reporter source path and run python -I -B -S bootstrap/test_owner_bootstrap.py -v. All23 cases are local compile/mocked-download tests; they never run the shell command or contact a host. The NOT_READY template retains WRAPPER_COMMIT='UNBOUND'. After one future publication commit is independently verified, a delivery copy may bind only that commit while retaining the frozen source size/hash. There is no second pin commit. Execution and approval remain separate from this local source handoff.
