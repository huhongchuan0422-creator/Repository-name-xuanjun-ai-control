# Reconstructed Stage A saved-evidence reporter

This candidate is newly reconstructed from the independently authenticated published commit `609407afa118c527299f33885d82b6acc1c020fb`. The unavailable earlier unpublished reporter and its test receipts are not treated as this candidate. All final hashes and test results must come from these new bytes.

## Purpose and fixed scope

The single-file reporter authenticates the existing R7 kit and fixed successful saved observation `8df3b22b3762070f`, its normal diagnostic receipt, and the one nonce-bound created probe receipt. It runs the unchanged published pure validators/projector and the new pure saved-authority coverage mapper in memory. It repeats the protected input and source checks before reporting. It does not collect current process/system facts, run a probe, fetch approval, stage files, prepare a plan, install, resume, or change application data.

The full private observation remains on the UK host and in memory. The main raw observation SHA-256 is `a3f7042a1b3099c5699aaef547b22c8f744f0bdc514043a2a91a9847639f4f68`; its independently pinned canonical SHA-256 is `f03fed248eaed766cce97eaa691aaf0f2132269d17bcbe8a7969464a2eb82fea`. The underlying R7 kit source is `dc18f73e67818dc59f5acea247dbf05443bde10d`, manifest `7b926fda92065d9ff981bfeaad490d5568dd5901d2b1089d1f1dfac94eae8bb4`. No old R6 input is relabeled as R7.

## Evidence interpretation

- A1: binds exact input bytes, canonical bytes, nonce/observation references, fixed host, isolated root executor and authenticated source identities. An exact observation wall-clock was not retained. File timestamps are not substituted. The reporter's own immutable source identity must come from the separately authenticated future bootstrap transcript.
- A2: checks all 11 units and 33 root records, selected saved policy/boot authority and file metadata. It separates SAVED_VALUE, SOURCE_ENFORCED_ONLY, and NOT_RETAINED. Source-enforced evidence is conditional on the genuine complete-observation validator and exact successful collector chain. Per-call descriptor/inode transcripts and cross-scan descriptor joins are not fabricated.
- A3: independently recomputes full raw/canonical input bindings and the seven published projection/body hashes. All ancillary sections receive a bounded recursive status/closure/unresolved inventory. Truncation or unknown records remain visible.
- A4: validates eight cases, nine server records, 129 receipt events, 35 resources, 34 removed-file cleanup rows and six stopped/empty-unit rows. The prior failed attempt remains a separate fixed historical reference and is not reinterpreted.
- A5: compares against the exact 1,928 retained serialized body bytes at offset 292,914 in the published packet. Their SHA-256 is `37ee583dfda581361caf38e8cccf5ffb9b25f28c8f732e17e0cbf6e72982c9b7`. No separate original host body file is asserted.
- A6: output contains only bounded hashes, counts, finite indexes, booleans and static statuses. No absolute paths, raw authority stamps, configuration bodies, environment, argv, private error text or source buffers are emitted. Existing readers may cause filesystem access-time updates; atime effects are possible and not measured.

Reporting completion is not approval. The envelope always retains Stage A HOLD and Stage B/C NOT_AUTHORIZED; process exit remains nonzero. The reviewing authority decides how the disclosed evidence limitations affect acceptance.

## Bounds and failure behavior

A recurring 60-second timer covers dependency loading, all protected reads, verification and projection. Output has a separate 60-second timer. The compact future network bootstrap has a 30-second recurring overall download alarm and a 10-second socket timeout. The reporter's canonical public output is limited to 262,144 bytes. Only static authenticated error categories and hashed source references are emitted. A pre-emission failure receives one bounded redacted report; output is never retried after emission may have started. Primary exceptions and descriptor/timer cleanup uncertainty remain explicit.

## Local verification and fixture limitations

The focused reconstruction suites use authenticated public inputs plus clearly synthetic complete-observation fixtures. The actual published packet only proves exported-subset behavior; it is never treated as the missing full private observation. The end-to-end synthetic fixture invokes the genuine full validator, pure projector, strict export schema and mapper without replacing their predicates. Historic failures and intermediate fixture corrections remain local evidence, separate from the final test receipt.

Only the new reporter and mapper suites and dedicated CI boundary/bootstrap tests are scheduled. The unchanged 313-test preparation/runtime suites are not rerun. Publication, Hosted execution, UK execution and Task5 Stage A acceptance remain pending. Root owns those external actions and delivery consent.
