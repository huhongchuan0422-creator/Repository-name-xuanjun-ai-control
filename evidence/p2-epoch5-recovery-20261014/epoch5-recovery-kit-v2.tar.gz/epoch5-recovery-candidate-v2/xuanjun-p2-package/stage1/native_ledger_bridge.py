#!/usr/bin/env python3
"""Synchronous client of the EXISTING ledger socket; no direct DB access."""
import argparse
import json
import os
import socket
import stat
import struct
import sys
from native_ledger_operations import execute


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    args = parser.parse_args()
    fd = os.open(args.config, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022 or info.st_size > 65536:
            raise ValueError('protected socket client config required')
        config = json.loads(os.read(fd, 65537).decode('utf-8'))
    finally:
        os.close(fd)
    if set(config) != {'socket_path', 'server_uid'} or type(config['server_uid']) is not int or config['server_uid'] < 1:
        raise ValueError('socket client config mismatch')
    path = config['socket_path']
    if not os.path.isabs(path) or os.path.realpath(path) != path:
        raise ValueError('canonical ledger socket required')
    raw = sys.stdin.buffer.read(1048577)
    if len(raw) > 1048576:
        raise ValueError('native request limit')
    payload = json.loads(raw.decode('utf-8'))
    if isinstance(payload,dict) and payload.get('operation')=='owner_delivery_cycle':
        if set(payload)!={'operation','request'} or payload['request'] is not None:
            raise ValueError('owner cycle params rejected')
        from owner_feishu_bridge_cycle import run_cycle
        from owner_feishu_https import installed_binding,OwnerFeishuHTTPS
        binding=installed_binding()
        api=OwnerFeishuHTTPS(binding)
        result=run_cycle(lambda request: socket_call(config,{'operation':'owner_delivery','request':request}),api,binding)
    else:
        result=socket_call(config,payload)
    sys.stdout.write(json.dumps(result,sort_keys=True,separators=(',', ':'),allow_nan=False))


def socket_call(config,payload):
    path=config['socket_path']
    packed = (json.dumps({'operation':'NATIVE_GATEWAY', 'payload':payload},
                        sort_keys=True,separators=(',', ':'),allow_nan=False)+'\n').encode('utf-8')
    if len(packed) >= 1048576:
        raise ValueError('native wire limit')
    connection = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        connection.settimeout(10)
        connection.connect(path)
        credentials = connection.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED,struct.calcsize('3i'))
        if struct.unpack('3i',credentials)[1] != config['server_uid']:
            raise ValueError('ledger socket server UID mismatch')
        connection.sendall(packed)
        response=bytearray()
        while b'\n' not in response:
            chunk=connection.recv(1048576-len(response))
            if not chunk or len(response)+len(chunk)>=1048576:raise ValueError('native response unconfirmed')
            response.extend(chunk)
        line,remainder=bytes(response).split(b'\n',1)
        if remainder:raise ValueError('multiple native responses')
        value=json.loads(line.decode('utf-8'))
        if set(value)!={'accepted','result'} or value['accepted'] is not True:
            raise ValueError('native operation unconfirmed')
        return value['result']
    finally:
        connection.close()


if __name__ == '__main__':
    try:main()
    except Exception:
        sys.stderr.write('HOLD_CANONICAL_SOCKET\n')
        sys.exit(2)
