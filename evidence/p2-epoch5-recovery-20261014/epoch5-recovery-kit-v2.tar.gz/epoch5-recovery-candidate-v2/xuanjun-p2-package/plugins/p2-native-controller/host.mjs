import {CanonicalLedgerStore} from './ledger.mjs';
import {ContainerObserver} from './workspace.mjs';
import {digest} from './canonical.mjs';
import {sandboxLayout} from './sdk-layout.mjs';

const hold=reason=>{throw new Error('HOLD_'+reason);};
/** Concrete adapters using Gateway's injected SDK and pinned context resolver. */
export function createHostBindings(api,settings,resolveSandboxContext) {
  if(typeof resolveSandboxContext!=='function')hold('SANDBOX_CONTEXT_EXPORT');
  const preparedSandboxes=new Map();
  const store=new CanonicalLedgerStore(settings.ledger);
  const boundary=new ContainerObserver(settings.engine);
  const agentIds=settings.agentIds;
  if(!agentIds||Object.keys(agentIds).sort().join(',')!=='read-only,workspace-write'
    ||agentIds['workspace-write']!=='developer'||agentIds['read-only']!=='platform-engineer')hold('AGENT_POLICY');
  const selectAgent=request=>agentIds[request?.sandbox];
  const config=()=>{if(typeof api.runtime.config?.current!=='function')hold('LIVE_CONFIG_API');return api.runtime.config.current();};
  const eligibility=(runtime,request)=>{
    const cfg=config(),agentId=selectAgent(request);
    if(!cfg||!agentId||typeof runtime.agent?.resolveCliBackendDispatchEligibility!=='function')hold('DISPATCH_ELIGIBILITY_UNAVAILABLE');
    return runtime.agent.resolveCliBackendDispatchEligibility({config:cfg,agentId,
      agentDir:runtime.agent.resolveAgentDir(cfg,agentId),workspaceDir:request.workdir,
      provider:request.provider,model:request.model});
  };
  const prepare=async(runtime,{request,sessionKey})=>{
    const cfg=config(),agentId=selectAgent(request);
    if(!agentId)hold('AGENT_POLICY');
    const authority=runtime.sandbox.resolveWorkspaceAuthority({config:cfg,agentId,sessionKey,
      workspaceDir:request.workdir,modelProvider:request.provider,modelId:request.model});
    if(authority?.sandboxed!==true||authority.confinementError)hold('SANDBOX_AUTHORITY');
    if(typeof runtime.sandbox?.prepareWorkspaceAuthority!=='function')hold('SANDBOX_PREPARE_API');
    const preparedAuthority=await runtime.sandbox.prepareWorkspaceAuthority({config:cfg,agentId,sessionKey,
      workspaceDir:request.workdir,modelProvider:request.provider,modelId:request.model});
    if(preparedAuthority?.sandboxed!==true||preparedAuthority.confinementError
      ||preparedAuthority.workspaceAccess!==(request.sandbox==='read-only'?'ro':'rw'))hold('SANDBOX_AUTHORITY');
    const context=await resolveSandboxContext({config:cfg,agentId,sessionKey,
      workspaceDir:request.workdir,requireCurrentConfig:true,
      assertCurrent:()=>{if(!store.guard(request))hold('PREPARE_LEASE');}});
    const layout=sandboxLayout(context,request,sessionKey,settings.engine.backend);
    preparedSandboxes.set(sessionKey,layout);
    return {backend:context.backendId,name:context.runtimeId,sdk_layout:layout};
  };
  const collectResult=async(runtime,record)=>{
    if(record.phase!=='TERMINAL'||record.observation?.state!=='completed')hold('RUN_NOT_COMPLETED');
    const entry=await runtime.agent.session.getSessionEntry({sessionKey:record.session_key,agentId:record.agent_id,readConsistency:'latest'});
    if(entry?.sessionId!==record.receipt.session_id)hold('RESULT_SESSION');
    if(record.runtime?.provider!=='openai'||record.runtime.model!=='gpt-5.6-sol')hold('RESULT_RUNTIME_MODEL');
    const response=await runtime.subagent.getSessionMessages({sessionKey:record.session_key,limit:200});
    if(!Array.isArray(response?.messages))hold('TRANSCRIPT_UNAVAILABLE');
    const messages=response.messages.filter(m=>m?.role==='assistant');
    const final=messages.at(-1);
    // Model identity is transport metadata, never text authored by the model.
    if(!final||messages.some(m=>m.provider!=='openai'||m.model!=='gpt-5.6-sol')
      ||!['stop','end_turn'].includes(final.stopReason)||!Array.isArray(final.content))hold('TRANSCRIPT_MODEL_OR_COMPLETION');
    const output=final.content.filter(c=>c.type==='text'&&typeof c.text==='string').map(c=>c.text).join('\n');
    if(Buffer.byteLength(output)>65536)hold('RESULT_LIMIT');
    return {status:'COMPLETED',turn_completed:true,provider:final.provider,model:final.model,
      requested_model:record.request.model,model_verified:true,real_execution:true,
      simulated:false,output};
  };
  const preflight=async runtime=>{
    // Physical provision and active canonical claim are checked at admission.
    // Preflight cannot manufacture an active task to obtain a green flag.
    if(!runtime.subagent?.run||!runtime.subagent.waitForRun||!runtime.sandbox?.resolveWorkspaceAuthority
      ||typeof runtime.sandbox.prepareWorkspaceAuthority!=='function'
      ||!runtime.agent?.session?.getSessionEntry)hold('GATEWAY_SDK');
    const observed=store.call('preflight',null);
    const cfg=config(),selected=cfg?.agents?.defaults?.model;
    if(selected?.primary!=='openai/gpt-5.6-sol'||!Array.isArray(selected.fallbacks)
      ||selected.fallbacks.length)hold('MODEL_POLICY');
    const auth=runtime.modelAuth;
    if(!auth?.ensureAuthProfileStore||!auth.resolveAuthProfileOrder)hold('AUTH_METADATA_API');
    const agentDir=runtime.agent.resolveAgentDir(cfg,'developer');
    const authStore=auth.ensureAuthProfileStore(agentDir,{config:cfg,allowKeychainPrompt:false});
    const order=auth.resolveAuthProfileOrder({cfg,store:authStore,provider:'openai'});
    const profile=authStore?.profiles?.[order?.[0]];
    if(profile?.type!=='oauth'||profile.provider!=='openai')hold('EXISTING_OAUTH_PROFILE');
    const request={workdir:settings.workspaceRoot,sandbox:'workspace-write',provider:'openai',model:'gpt-5.6-sol'};
    if(eligibility(runtime,request))hold('OAUTH_CLI_DISPATCH_BYPASS');
    for(const sandbox of ['workspace-write','read-only']) {
      const agentId=selectAgent({sandbox});
      const authority=runtime.sandbox.resolveWorkspaceAuthority({config:cfg,agentId,
        sessionKey:'agent:'+agentId+':xuanjun-p2:verify-only',workspaceDir:settings.workspaceRoot,
        modelProvider:'openai',modelId:'gpt-5.6-sol'});
      if(authority?.sandboxed!==true||authority.confinementError
        ||authority.workspaceAccess!==(sandbox==='read-only'?'ro':'rw'))hold('SANDBOX_AUTHORITY');
    }
    const version=(await boundary.command(['version','--format','{{.Server.Version}}'])).trim();
    if(!version||version.length>64)hold('ENGINE_UNAVAILABLE');
    if(observed.canonical_existing!==true||observed.outbox_existing!==true)hold('CANONICAL_PREFLIGHT');
    return {ready:true,canonical_existing:true,outbox_existing:true,isolation_enforced:true};
  };
  const beforeToolCall=async(event,ctx)=>{
    if(typeof ctx?.sessionKey!=='string'||!/^agent:(developer|platform-engineer):xuanjun-p2:[0-9a-f]{64}$/.test(ctx.sessionKey))return;
    try {
      const saved=store.call('tool_guard',{session_key:ctx.sessionKey}).native_execution;
      if(!saved?.receipt||event.runId!==saved.receipt.run_id||(ctx.runId!==undefined&&ctx.runId!==event.runId))hold('TOOL_RUN_BINDING');
      if(!saved.placement||saved.receipt.placement_digest!==digest(saved.placement)
        ||saved.placement.sandbox_runtime_id!==saved.unit?.name)hold('TOOL_PLACEMENT_RECEIPT');
      const allowed=saved.request?.sandbox==='read-only'?['read']:['read','write','edit','apply_patch','exec'];
      if(!allowed.includes(event.toolName)
        ||event.params?.elevated===true||['gateway','node'].includes(event.params?.host))hold('TOOL_POLICY');
      const cfg=config(),agentId=saved.agent_id;
      if(agentId!==selectAgent(saved.request))hold('TOOL_AGENT_BINDING');
      const sandbox=await resolveSandboxContext({config:cfg,agentId,sessionKey:ctx.sessionKey,
        workspaceDir:saved.request.workdir,requireCurrentConfig:true,
        assertCurrent:()=>{if(!store.guard(saved.request))hold('TOOL_LEASE');}});
      const layout=sandboxLayout(sandbox,saved.request,ctx.sessionKey,settings.engine.backend);
      if(layout.runtime_id!==saved.unit.name||layout.backend!==saved.unit.backend
        ||!saved.unit.sdk_layout||digest(layout)!==digest(saved.unit.sdk_layout))hold('TOOL_SANDBOX_BINDING');
      const identity=digest({phase:saved.phase,idempotency_key:saved.idempotency_key,
        session_key:saved.session_key,agent_id:saved.agent_id,request:saved.request,
        unit:saved.unit,placement:saved.placement,receipt:saved.receipt});
      const unit=await boundary.inspect(saved.unit);
      if(!unit.active||!unit.process_alive)hold('TOOL_UNIT_INACTIVE');
      const current=store.call('tool_guard',{session_key:ctx.sessionKey}).native_execution;
      if(!current||digest({phase:current.phase,idempotency_key:current.idempotency_key,
        session_key:current.session_key,agent_id:current.agent_id,request:current.request,
        unit:current.unit,placement:current.placement,receipt:current.receipt})!==identity
        ||store.guard(saved.request)!==true)hold('TOOL_CANONICAL_CHANGED_AFTER_INSPECT');
      return;
    } catch {return {block:true,blockReason:'P2 canonical lease/run/unit admission unavailable'};}
  };
  return {store,boundary,eligibility,prepare,collectResult,preflight,beforeToolCall,selectAgent,
    ownerDelivery:()=>store.call('owner_delivery_cycle',null),
    verifyWorkerPlacement:async(runtime,{request,unit,sessionKey,source})=>{
      const expected=preparedSandboxes.get(sessionKey);
      if(!expected||expected.runtime_id!==unit.name||expected.backend!==unit.backend
        ||!unit.sdk_layout||digest(expected)!==digest(unit.sdk_layout)||!store.guard(request))return null;
      const cfg=config(),agentId=selectAgent(request);
      if(!agentId)return null;
      const current=await resolveSandboxContext({config:cfg,agentId,sessionKey,
        workspaceDir:request.workdir,requireCurrentConfig:true,
        assertCurrent:()=>{if(!store.guard(request))hold('PLACEMENT_LEASE');}});
      const layout=sandboxLayout(current,request,sessionKey,settings.engine.backend);
      if(digest(layout)!==digest(expected))return null;
      const observed=await boundary.inspect(unit);
      if(!observed.active||!observed.process_alive)return null;
      const namespace=await boundary.attestSnapshot(unit,source);
      return {verified:true,session_key:sessionKey,unit_backend:unit.backend,unit_id:unit.id,cgroup:unit.cgroup,
        source_manifest_sha256:source.manifest_sha256,namespace_sha256:namespace.namespace_sha256,
        request_sha256:digest(request),sandbox_runtime_id:current.runtimeId};
    },
    releaseWorkerPlacement:sessionKey=>{preparedSandboxes.delete(sessionKey);return true;},
    verifyLease:(task,request,now)=>task.state==='RUNNING'&&Number.isFinite(task.lease_until)&&task.lease_until*1000>now,
    commitGuard:request=>store.guard(request)};
}
